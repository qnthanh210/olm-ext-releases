// ============================================================
// OLM Remote Config — schema, validation, versioning, integrity
// ------------------------------------------------------------
// MODULE DỰNG (ground truth) cho cả 3 nơi:
//   1. Extension (service worker) — extension/remote-config/manager.js
//   2. Node scripts (build / validate / publish) — scripts/*.mjs
//   3. Test suite — tests/*.test.mjs
//
// Nguyên tắc bất di bất dịch:
//   • KHÔNG có eval / new Function / import() động.
//   • KHÔNG có HTML, CSS, JavaScript, URL tùy ý trong config.
//   • Config là DỮ LIỆU thuần (selector, số, nhãn, cờ).
//   • Mọi thứ từ xa đều phải qua validateConfig() trước khi dùng.
//
// Module này chạy được cả trong Service Worker lẫn Node (>=18):
// chỉ dùng WebCrypto/TextEncoder — không chạm chrome.*, document, window.
// ============================================================

/** Phiên bản schema mà extension này hiểu. */
export const SCHEMA_VERSION = 1;

/** Phiên bản định dạng bundle (vỏ bọc integrity). */
export const BUNDLE_FORMAT_VERSION = 1;

/** Hard limit. Config vượt ngưỡng này bị reject, không phải truncate. */
export const LIMITS = {
  MAX_CONFIG_BYTES: 262144,      // 256 KB — config là dữ liệu nhỏ, không phải payload
  MAX_BUNDLE_BYTES: 393216,      // 384 KB — bundle = config + metadata
  MAX_SELECTOR_LEN: 500,
  MAX_SELECTOR_LIST: 240,        // số phần tử của một selector-list
  MAX_LIST_TOTAL_LEN: 24000,     // tổng độ dài mọi selector-list
  MAX_PATTERN_LEN: 200,
  MAX_LABEL_LEN: 40,
  MAX_CLASS_LEN: 40,
  MAX_NOTES_LEN: 500,
  MAX_DOMAINS: 10,
  MAX_CHIP_TEXT: 500,
  MIN_CHIP_TEXT: 8,
  MAX_MATCH_CYCLES: 10,
  MIN_MATCH_CYCLES: 1,
  MAX_FUTURE_SKEW_MS: 2 * 24 * 60 * 60 * 1000,   // generatedAt được phép lệch tối đa 2 ngày
  MAX_VALIDITY_MS: 400 * 24 * 60 * 60 * 1000,   // expiresAt không xa quá 400 ngày
};

/** Domain mà extension thực sự chạy. Config KHÔNG được mở rộng danh sách này. */
export const LOCAL_ALLOWED_DOMAINS = Object.freeze(['olm.vn']);

/** Top-level keys hợp lệ. Key lạ = lỗi (chặn smuggle payload trong key). */
const ALLOWED_TOP_KEYS = new Set([
  'schemaVersion', 'configVersion', 'minimumExtensionVersion',
  'generatedAt', 'expiresAt', 'channel',
  'features', 'selectors', 'matching', 'ui', 'compatibility', 'notes',
]);

const ALLOWED_FEATURE_KEYS = new Set([
  'remoteTunables', 'answerDomSelectors', 'panelUiLabels', 'compatibilityMap',
]);

const ALLOWED_SELECTOR_KEYS = new Set([
  'quizHost', 'quizHostFallbackPattern', 'mcOption', 'tfRow',
  'mcBlock', 'tfBlock', 'legacyBlock', 'legacyRoot', 'legacyOption',
  'answerDom', 'stripDisplay',
]);

const ALLOWED_MATCHING_KEYS = new Set([
  'chipMaxText', 'rearmCyclesMax', 'tfListNamePattern',
]);

/** Nhãn qtype: khoá phải đúng tập đã biết (khớp QTYPE_LABEL trong content.js). */
const ALLOWED_QTYPE_KEYS = new Set([
  'mc', 'tf', 'fill', 'match', 'order', 'essay', 'unknown',
]);

const VERSION_RE = /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)$/;
const ISO_RE = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d{1,3})?Z$/;
const CLASS_RE = /^[a-z0-9_-]{1,40}$/;

// Ký tự được phép trong CSS selector. Chặn { } ; < > / & @ (ngoài ngoặc)
// và mọi ký tự điều khiển → không thể dựng CSS để exfiltrate/lấy tài nguyên ngoài.
const SELECTOR_CHARS_RE = /^[A-Za-z0-9_\-#.\[\]=\s>:~()'",>+*|^!\\%@$]+$/;
const SELECTOR_FORBIDDEN_RE = /(javascript\s*:|vbscript\s*:|data\s*:|expression\s*\(|url\s*\(|@import|-moz-binding|behaviou?r\s*:|\/\*|\*\/)/i;
// Tag không được phép chọn từ xa: có thể chèn/đọc nội dung thực thi hoặc gắn
// nguồn ngoài. `input`/`textarea` VẪN được phép (answerDom cần chúng).
const SELECTOR_FORBIDDEN_TAG_RE =
  /(^|[\s,>+~])(script|style|iframe|object|embed|link|meta|base|noscript|frame|frameset|applet|template)\b/i;

// Regex do remote cung cấp: literal không flag. Chặn backreference, lookaround,
// unicode property escape và nested-quantifier (ReDoS). Cho phép \d \w \s \b \s- ...
const PATTERN_BACKREF_RE = /\\(?:[1-9]\d*|k<)/;
const PATTERN_LOOKAROUND_RE = /\(\?(?:[=!]|<[=!])/;
const PATTERN_PROP_RE = /\\[pP]\{/;
const PATTERN_NESTED_QUANT_RE = /\((?:[^()\\]|\\.)*[+*](?:[^()\\]|\\.)*\)\s*(?:[+*]|\{\d+,?\d*\})/;

export function isPlainObject(v) {
  return !!v && typeof v === 'object' && !Array.isArray(v);
}

export function isVersionString(v) {
  return typeof v === 'string' && VERSION_RE.test(v);
}

/** So sánh version semver 3 số: trả -1 | 0 | 1. */
export function compareVersions(a, b) {
  const pa = String(a).split('.').map(Number);
  const pb = String(b).split('.').map(Number);
  for (let i = 0; i < 3; i++) {
    if (pa[i] > pb[i]) return 1;
    if (pa[i] < pb[i]) return -1;
  }
  return 0;
}

/**
 * Canonical JSON: object key sort tăng dần, array giữ thứ tự, không whitespace.
 * Dùng để hash SHA-256 một cách xác định (không phụ thuộc key order của publisher).
 */
export function canonicalize(value) {
  if (value === null) return 'null';
  const t = typeof value;
  if (t === 'number') {
    if (!Number.isFinite(value)) throw new Error('non-finite number in config');
    return JSON.stringify(value);
  }
  if (t === 'boolean' || t === 'string') return JSON.stringify(value);
  if (Array.isArray(value)) return '[' + value.map(canonicalize).join(',') + ']';
  if (isPlainObject(value)) {
    const keys = Object.keys(value).filter(k => value[k] !== undefined).sort();
    return '{' + keys.map(k => JSON.stringify(k) + ':' + canonicalize(value[k])).join(',') + '}';
  }
  throw new Error('unsupported value type in config: ' + t);
}

const utf8 = new TextEncoder();

export function utf8Bytes(str) {
  return utf8.encode(str);
}

/** SHA-256 hex của một chuỗi UTF-8 (dùng được cả Node lẫn Service Worker). */
export async function sha256Hex(str) {
  const digest = await crypto.subtle.digest('SHA-256', utf8.encode(str));
  const bytes = new Uint8Array(digest);
  let out = '';
  for (let i = 0; i < bytes.length; i++) out += bytes[i].toString(16).padStart(2, '0');
  return out;
}

/** Tách selector-list ("a, b , c") thành mảng phần tử đã trim, bỏ rỗng. */
export function splitSelectorList(list) {
  return String(list).split(',').map(s => s.trim()).filter(Boolean);
}

// ─── Validator con ─────────────────────────────────────────────

function validateSelectorString(sel, errors, path) {
  if (typeof sel !== 'string') { errors.push(`${path}: must be string`); return false; }
  const s = sel.trim();
  if (!s) { errors.push(`${path}: empty selector`); return false; }
  if (s.length > LIMITS.MAX_SELECTOR_LEN) { errors.push(`${path}: too long (>${LIMITS.MAX_SELECTOR_LEN})`); return false; }
  if (!SELECTOR_CHARS_RE.test(s)) { errors.push(`${path}: illegal characters in selector`); return false; }
  if (SELECTOR_FORBIDDEN_RE.test(s)) { errors.push(`${path}: forbidden token in selector`); return false; }
  if (SELECTOR_FORBIDDEN_TAG_RE.test(s)) { errors.push(`${path}: forbidden tag in selector`); return false; }
  return true;
}

function validateSelectorList(list, errors, path) {
  if (typeof list !== 'string') { errors.push(`${path}: must be string`); return false; }
  if (list.length > LIMITS.MAX_SELECTOR_LEN * LIMITS.MAX_SELECTOR_LIST) {
    errors.push(`${path}: selector list too long`); return false;
  }
  const parts = splitSelectorList(list);
  if (!parts.length) { errors.push(`${path}: empty selector list`); return false; }
  if (parts.length > LIMITS.MAX_SELECTOR_LIST) { errors.push(`${path}: too many selectors (>${LIMITS.MAX_SELECTOR_LIST})`); return false; }
  let ok = true;
  for (const p of parts) {
    // Kiểm tra từng phần tử bằng chính bộ luật chuỗi, trừ giới hạn độ dài tổng.
    if (typeof p !== 'string' || !p || p.length > LIMITS.MAX_SELECTOR_LEN) { errors.push(`${path}: bad selector element`); ok = false; }
    else if (!SELECTOR_CHARS_RE.test(p) || SELECTOR_FORBIDDEN_RE.test(p)) { errors.push(`${path}: illegal selector element "${p.slice(0, 40)}"`); ok = false; }
    else if (SELECTOR_FORBIDDEN_TAG_RE.test(p)) { errors.push(`${path}: forbidden tag in selector element "${p.slice(0, 40)}"`); ok = false; }
  }
  return ok;
}

function validatePattern(str, errors, path) {
  if (typeof str !== 'string') { errors.push(`${path}: must be string`); return false; }
  const s = str.trim();
  if (!s) { errors.push(`${path}: empty pattern`); return false; }
  if (s.length > LIMITS.MAX_PATTERN_LEN) { errors.push(`${path}: pattern too long`); return false; }
  if (PATTERN_BACKREF_RE.test(s)) { errors.push(`${path}: backreference not allowed in pattern`); return false; }
  if (PATTERN_LOOKAROUND_RE.test(s)) { errors.push(`${path}: lookaround not allowed in pattern`); return false; }
  if (PATTERN_PROP_RE.test(s)) { errors.push(`${path}: unicode property escape not allowed in pattern`); return false; }
  if (PATTERN_NESTED_QUANT_RE.test(s)) { errors.push(`${path}: nested quantifier not allowed in pattern (ReDoS)`); return false; }
  try { new RegExp(s); } catch (_) { errors.push(`${path}: invalid regex`); return false; }
  return true;
}

function validateInt(v, min, max, errors, path) {
  if (typeof v !== 'number' || !Number.isInteger(v)) { errors.push(`${path}: must be integer`); return false; }
  if (v < min || v > max) { errors.push(`${path}: out of range [${min}, ${max}]`); return false; }
  return true;
}

function validateIsoDate(v, errors, path) {
  if (typeof v !== 'string' || !ISO_RE.test(v)) { errors.push(`${path}: must be ISO-8601 UTC (YYYY-MM-DDTHH:MM:SSZ)`); return NaN; }
  const t = Date.parse(v);
  if (!Number.isFinite(t)) { errors.push(`${path}: unparsable date`); return NaN; }
  return t;
}

// ─── Validator chính ───────────────────────────────────────────

/**
 * Validate toàn bộ config.
 * @returns {{ok:boolean, errors:string[], warnings:string[], config:object|null}}
 */
export function validateConfig(raw, opts = {}) {
  const errors = [];
  const warnings = [];
  const fail = (m) => errors.push(m);

  if (!isPlainObject(raw)) {
    return { ok: false, errors: ['config: root must be a JSON object'], warnings, config: null };
  }

  // 0) Kích thước (canonical) — chặn config khổng lồ trước khi parse sâu.
  let canon;
  try { canon = canonicalize(raw); }
  catch (e) { fail('config: cannot canonicalize — ' + e.message); }
  const byteLen = canon ? utf8.encode(canon).length : Infinity;
  if (byteLen > LIMITS.MAX_CONFIG_BYTES) fail(`config: too large (${byteLen} > ${LIMITS.MAX_CONFIG_BYTES} bytes)`);

  // 1) Key lạ ở top-level → lỗi (chặn payload gắn nhãn lạ).
  for (const k of Object.keys(raw)) {
    if (!ALLOWED_TOP_KEYS.has(k)) fail(`config.${k}: unknown top-level key`);
  }

  // 2) Trường bắt buộc.
  const schemaVersion = raw.schemaVersion;
  if (typeof schemaVersion !== 'number' || !Number.isInteger(schemaVersion)) fail('config.schemaVersion: must be integer');
  else if (schemaVersion !== SCHEMA_VERSION) fail(`config.schemaVersion: unsupported (expected ${SCHEMA_VERSION}, got ${schemaVersion})`);

  if (!isVersionString(raw.configVersion)) fail('config.configVersion: must be MAJOR.MINOR.PATCH');
  if (!isVersionString(raw.minimumExtensionVersion)) fail('config.minimumExtensionVersion: must be MAJOR.MINOR.PATCH');

  const generatedAt = validateIsoDate(raw.generatedAt, errors, 'config.generatedAt');
  const expiresAt = validateIsoDate(raw.expiresAt, errors, 'config.expiresAt');

const now = typeof opts.now === 'number' ? opts.now : Date.now();
  // origin='local' dành cho config ĐI KÈM GÓI EXTENSION (immutable, tin cậy):
  // bỏ các kiểm tra phụ thuộc thời gian, vì mốc generatedAt/expiresAt của nó là
  // hằng số lịch sử chứ không phải cam kết còn hiệu lực. Mọi kiểm tra cấu trúc,
  // kiểu dữ liệu và giới hạn vẫn áp dụng như thường.
  const origin = opts.origin === 'local' ? 'local' : 'remote';
  if (origin === 'remote') {
    if (Number.isFinite(generatedAt) && generatedAt - now > LIMITS.MAX_FUTURE_SKEW_MS) fail('config.generatedAt: too far in the future');
    if (Number.isFinite(expiresAt) && expiresAt - now > LIMITS.MAX_VALIDITY_MS) warnings.push('config.expiresAt: longer than 400 days');
  }
  if (Number.isFinite(generatedAt) && Number.isFinite(expiresAt) && expiresAt <= generatedAt) fail('config.expiresAt: must be after generatedAt');

  if (raw.channel !== undefined && !['stable', 'beta'].includes(raw.channel)) fail('config.channel: must be "stable" or "beta"');
  if (raw.notes !== undefined && (typeof raw.notes !== 'string' || raw.notes.length > LIMITS.MAX_NOTES_LEN)) fail('config.notes: string too long');

  // 3) Tương thích extension (chặn config mới hơn mức extension chạy được).
  if (isVersionString(raw.configVersion) && typeof opts.extensionVersion === 'string' && isVersionString(opts.extensionVersion)) {
    if (compareVersions(raw.minimumExtensionVersion, opts.extensionVersion) > 0) {
      fail(`config requires extension >= ${raw.minimumExtensionVersion} (this is ${opts.extensionVersion})`);
    }
  }

  // 4) features — chỉ boolean.
  if (raw.features !== undefined) {
    if (!isPlainObject(raw.features)) fail('config.features: must be object');
    else for (const [k, v] of Object.entries(raw.features)) {
      if (!ALLOWED_FEATURE_KEYS.has(k)) { warnings.push(`features.${k}: unknown key ignored`); continue; }
      if (typeof v !== 'boolean') fail(`features.${k}: must be boolean`);
    }
  }

  // 5) selectors — chỉ selector/pattern hợp lệ.
  if (raw.selectors !== undefined) {
    if (!isPlainObject(raw.selectors)) fail('config.selectors: must be object');
    else {
      let listChars = 0;
      for (const [k, v] of Object.entries(raw.selectors)) {
        if (!ALLOWED_SELECTOR_KEYS.has(k)) { warnings.push(`selectors.${k}: unknown key ignored`); continue; }
        const path = `selectors.${k}`;
        if (k.endsWith('Pattern')) {
          if (validatePattern(v, errors, path)) listChars += String(v).length;
        } else if (k === 'answerDom' || k === 'stripDisplay') {
          if (validateSelectorList(v, errors, path)) listChars += String(v).length;
        } else {
          if (validateSelectorString(v, errors, path)) listChars += String(v).length;
        }
      }
      if (listChars > LIMITS.MAX_LIST_TOTAL_LEN) fail('config.selectors: total selector payload too large');
    }
  }

  // 6) matching — số nguyên có giới hạn + pattern.
  if (raw.matching !== undefined) {
    if (!isPlainObject(raw.matching)) fail('config.matching: must be object');
    else for (const [k, v] of Object.entries(raw.matching)) {
      if (!ALLOWED_MATCHING_KEYS.has(k)) { warnings.push(`matching.${k}: unknown key ignored`); continue; }
      const path = `matching.${k}`;
      if (k === 'chipMaxText') validateInt(v, LIMITS.MIN_CHIP_TEXT, LIMITS.MAX_CHIP_TEXT, errors, path);
      else if (k === 'rearmCyclesMax') validateInt(v, LIMITS.MIN_MATCH_CYCLES, LIMITS.MAX_MATCH_CYCLES, errors, path);
      else if (k === 'tfListNamePattern') validatePattern(v, errors, path);
    }
  }

  // 7) ui — nhãn qtype.
  if (raw.ui !== undefined) {
    if (!isPlainObject(raw.ui)) fail('config.ui: must be object');
    else if (raw.ui.qtypeLabels !== undefined) {
      const labels = raw.ui.qtypeLabels;
      if (!isPlainObject(labels)) fail('ui.qtypeLabels: must be object');
      else for (const [k, v] of Object.entries(labels)) {
        if (!ALLOWED_QTYPE_KEYS.has(k)) { warnings.push(`ui.qtypeLabels.${k}: unknown key ignored`); continue; }
        if (!isPlainObject(v)) { fail(`ui.qtypeLabels.${k}: must be object`); continue; }
        if (typeof v.text !== 'string' || !v.text || v.text.length > LIMITS.MAX_LABEL_LEN) fail(`ui.qtypeLabels.${k}.text: invalid`);
        if (typeof v.cls !== 'string' || !CLASS_RE.test(v.cls)) fail(`ui.qtypeLabels.${k}.cls: must match ${CLASS_RE}`);
      }
    }
  }

  // 8) compatibility — domain phải nằm trong allowlist LOCAL.
  if (raw.compatibility !== undefined) {
    if (!isPlainObject(raw.compatibility)) fail('config.compatibility: must be object');
    else {
      if (raw.compatibility.olmDomains !== undefined) {
        const d = raw.compatibility.olmDomains;
        if (!Array.isArray(d) || d.length > LIMITS.MAX_DOMAINS) fail('compatibility.olmDomains: must be array(<=10)');
        else for (const dom of d) {
          if (typeof dom !== 'string') { fail('compatibility.olmDomains: non-string'); continue; }
          if (!LOCAL_ALLOWED_DOMAINS.includes(dom.toLowerCase())) {
            fail(`compatibility.olmDomains: "${dom}" not in local allowlist`);
          }
        }
      }
      const ui = raw.compatibility.knownUiVariants;
      if (ui !== undefined) {
        if (!Array.isArray(ui) || ui.length > 20) fail('compatibility.knownUiVariants: must be array(<=20)');
        else for (const v of ui) {
          if (typeof v !== 'string' || v.length > 80) fail('compatibility.knownUiVariants: invalid entry');
        }
      }
    }
  }

  return { ok: errors.length === 0, errors, warnings, config: errors.length === 0 ? raw : null };
}

// ─── Bundle (vỏ integrity) ─────────────────────────────────────

/** Dựng bundle từ một config đã hợp lệ. Dùng bởi scripts/build-config.mjs. */
export async function buildBundle(config, meta = {}) {
  const canon = canonicalize(config);
  const check = validateConfig(config, meta.validateOpts);
  if (!check.ok) throw new Error('buildBundle: config invalid — ' + check.errors.join('; '));
  return {
    bundleFormatVersion: BUNDLE_FORMAT_VERSION,
    schemaVersion: config.schemaVersion,
    configVersion: config.configVersion,
    publishedAt: meta.publishedAt || new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'),
    configBytes: utf8.encode(canon).length,
    configSha256: await sha256Hex(canon),
    config,
  };
}

/**
 * Validate bundle: format + integrity (bytes + sha256) + schema của config bên trong.
 * @returns {{ok:boolean, errors:string[], warnings:string[], config:object|null, bundle:object|null}}
 */
export async function validateBundle(raw, opts = {}) {
  const errors = [];
  const warnings = [];
  const fail = (m) => errors.push(m);

  if (!isPlainObject(raw)) {
    return { ok: false, errors: ['bundle: root must be a JSON object'], warnings, config: null, bundle: null };
  }
  if (raw.bundleFormatVersion !== BUNDLE_FORMAT_VERSION) fail(`bundle.bundleFormatVersion: expected ${BUNDLE_FORMAT_VERSION}`);
  if (!isVersionString(raw.configVersion)) fail('bundle.configVersion: must be MAJOR.MINOR.PATCH');
  if (typeof raw.publishedAt !== 'string' || !ISO_RE.test(raw.publishedAt)) fail('bundle.publishedAt: invalid ISO-8601 UTC');
  if (typeof raw.configBytes !== 'number' || !Number.isInteger(raw.configBytes) || raw.configBytes < 0) fail('bundle.configBytes: must be non-negative integer');
  if (typeof raw.configSha256 !== 'string' || !/^[0-9a-f]{64}$/.test(raw.configSha256)) fail('bundle.configSha256: must be 64 hex chars');

  if (raw.config === undefined) {
    fail('bundle.config: missing');
    return { ok: false, errors, warnings, config: null, bundle: null };
  }

  if (!errors.length) {
    let canon;
    try { canon = canonicalize(raw.config); }
    catch (e) { fail('bundle.config: cannot canonicalize — ' + e.message); }
    if (canon !== undefined) {
      const bytes = utf8.encode(canon).length;
      if (bytes !== raw.configBytes) fail(`bundle.configBytes: mismatch (declared ${raw.configBytes}, actual ${bytes})`);
      if (bytes > LIMITS.MAX_CONFIG_BYTES) fail(`bundle.config: too large (${bytes} bytes)`);
      const hash = await sha256Hex(canon);
      if (hash !== raw.configSha256) fail(`bundle.configSha256: mismatch (declared ${raw.configSha256}, actual ${hash})`);
    }
  }

  const inner = validateConfig(raw.config, opts);
  errors.push(...inner.errors);
  warnings.push(...inner.warnings);

  if (!errors.length && inner.config && isVersionString(raw.configVersion) && raw.config.configVersion !== raw.configVersion) {
    errors.push('bundle.configVersion does not match bundle.config.configVersion');
  }

  return {
    ok: errors.length === 0,
    errors,
    warnings,
    config: errors.length === 0 ? inner.config : null,
    bundle: errors.length === 0 ? raw : null,
  };
}

/** Trạng thái so với config đang active (chống downgrade). */
export function evaluateFreshness(candidateVersion, activeVersion) {
  if (!activeVersion) return 'new';
  const cmp = compareVersions(candidateVersion, activeVersion);
  if (cmp > 0) return 'newer';
  if (cmp === 0) return 'same';
  return 'older';
}
