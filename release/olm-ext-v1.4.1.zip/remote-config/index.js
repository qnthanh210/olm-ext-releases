// ============================================================
// OLM Remote Config — Service Worker wiring
// ------------------------------------------------------------
// Được import bởi background.js (type: "module"). Không sửa logic License:
// file này chỉ:
//   • dựng storage adapter trên chrome.storage.local
//   • đặt lịch kiểm tra bằng chrome.alarms
//   • lắng nghe message OLM_RC_* (có kiểm tra sender)
//   • phục vụ omnibox "olm ..." và trang trạng thái
//
// URL nguồn config là HẰNG SỨ CỨNG + allowlist. Config từ xa KHÔNG BAO GIỜ
// có quyền quyết định URL được fetch.
// ============================================================

import { createRemoteConfigManager, RC_KEYS } from './manager.js';
import { BUILTIN_CONFIG } from './default-config.js';
import { SCHEMA_VERSION } from './schema.js';

const RC_LOG = (...a) => console.log('[OLM-RC]', ...a);

// ── Nguồn config: allowlist cứng ──────────────────────────────
const RC_SOURCE = Object.freeze({
  owner: 'qnthanh210',
  repo: 'olm-ext-remote-config',
  ref: 'main',
  file: 'bundle.json',
});
const ALLOWED_FETCH_HOSTS = Object.freeze(['raw.githubusercontent.com']);

const CONFIG_CHECK_ALARM = 'olm_config_check';
const CONFIG_CHECK_MINUTES = 360;            // 6h
const ENABLE_KEY = 'olm_enabled';             // kill switch cho "olm on/off"

// ── Storage adapter ───────────────────────────────────────────
const storage = {
  async get(keys) { return chrome.storage.local.get(keys); },
  async set(obj) { return chrome.storage.local.set(obj); },
  async remove(keys) { return chrome.storage.local.remove(keys); },
};

function buildBundleUrl() {
  const u = `https://raw.githubusercontent.com/${RC_SOURCE.owner}/${RC_SOURCE.repo}/${RC_SOURCE.ref}/${RC_SOURCE.file}`;
  let parsed;
  try { parsed = new URL(u); } catch (_) { throw new Error('bad bundle url'); }
  if (!ALLOWED_FETCH_HOSTS.includes(parsed.hostname)) throw new Error('host not allowlisted');
  if (parsed.protocol !== 'https:') throw new Error('https required');
  return u;
}

let BUNDLE_URL;
try { BUNDLE_URL = buildBundleUrl(); }
catch (e) { RC_LOG('bundle url rejected:', e.message); BUNDLE_URL = ''; }

const manager = createRemoteConfigManager({
  storage,
  fetchImpl: (url, init) => fetch(url, init),
  bundleUrl: BUNDLE_URL || 'https://raw.githubusercontent.com/__disabled__/__disabled__/main/bundle.json',
  extensionVersion: chrome.runtime.getManifest().version,
  log: RC_LOG,
});

// ── Badge ─────────────────────────────────────────────────────
function paintBadge() {
  try {
    chrome.action.setBadgeText({ text: '' }).catch(() => {});
    chrome.action.setBadgeBackgroundColor({ color: '#2b2b2b' }).catch(() => {});
  } catch (_) {}
}
function badge(text, color) {
  try {
    chrome.action.setBadgeText({ text }).catch(() => {});
    chrome.action.setBadgeBackgroundColor({ color }).catch(() => {});
  } catch (_) {}
}

manager.onChange((type, detail) => {
  RC_LOG('event', type, detail && detail.reason ? detail.reason : (detail && detail.version) || '');
  if (type === 'activated') { badge('NEW', '#1f7a3f'); setTimeout(paintBadge, 60000); }
  else if (type === 'failed') { badge('!', '#a32020'); }
  else if (type === 'rolledback') { badge('RB', '#8a6d00'); setTimeout(paintBadge, 30000); }
});

// ── Alarm ─────────────────────────────────────────────────────
async function ensureConfigAlarm() {
  try {
    const a = await chrome.alarms.get(CONFIG_CHECK_ALARM);
    if (!a) chrome.alarms.create(CONFIG_CHECK_ALARM, { delayInMinutes: CONFIG_CHECK_MINUTES, periodInMinutes: CONFIG_CHECK_MINUTES });
  } catch (e) { RC_LOG('alarm setup error:', e.message); }
}

async function scheduleFromManager() {
  try {
    const delay = await manager.getNextCheckIn();
    chrome.alarms.create(CONFIG_CHECK_ALARM, {
      delayInMinutes: Math.max(1, Math.ceil((delay || CONFIG_CHECK_MINUTES * 60000) / 60000)),
    });
  } catch (e) { RC_LOG('reschedule error:', e.message); }
}

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name !== CONFIG_CHECK_ALARM) return;
  manager.check({ forced: false }).then(scheduleFromManager).catch(e => RC_LOG('check error:', e.message));
});

// ── Message API ───────────────────────────────────────────────
const EXT_ORIGIN = 'chrome-extension://' + chrome.runtime.id;

function isTrustedSender(sender) {
  if (!sender) return false;
  if (sender.id !== chrome.runtime.id) return false;
  // Lệnh đột biến (update / rollback) chỉ nhận từ trang của chính extension.
  if (typeof sender.url === 'string' && !sender.url.startsWith(EXT_ORIGIN)) return false;
  if (!sender.url && sender.tab) return false;   // không rõ nguồn → từ chối
  return true;
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || typeof msg !== 'object') return false;
  if (sender.id !== chrome.runtime.id) return false;

  switch (msg.type) {
    case 'OLM_RC_GET':
      manager.getSnapshot()
        .then(sendResponse)
        .catch(e => sendResponse({ error: 'snapshot_failed' }));
      return true;

    case 'OLM_RC_STATUS':
      manager.getStatus()
        .then(sendResponse)
        .catch(e => sendResponse({ error: 'status_failed' }));
      return true;

    case 'OLM_RC_UPDATE':
      if (!isTrustedSender(sender)) { sendResponse({ ok: false, reason: 'untrusted_sender' }); return false; }
      manager.check({ forced: true })
        .then(async (r) => { await scheduleFromManager(); sendResponse(r); })
        .catch(() => sendResponse({ ok: false, reason: 'internal' }));
      return true;

    case 'OLM_RC_ROLLBACK':
      if (!isTrustedSender(sender)) { sendResponse({ ok: false, reason: 'untrusted_sender' }); return false; }
      manager.rollback()
        .then(async (r) => { await scheduleFromManager(); sendResponse(r); })
        .catch(() => sendResponse({ ok: false, reason: 'internal' }));
      return true;

    case 'OLM_RC_LICENSE_INFO': {
      // Chỉ đọc + CHE. KHÔNG BAO GIỜ trả về license key đầy đủ.
      if (!isTrustedSender(sender)) { sendResponse({ error: 'untrusted_sender' }); return false; }
      chrome.storage.local.get(['license_key', 'license_status', 'olm_device_id', 'license_verified_at'])
        .then((d) => {
          const key = String(d.license_key || '').trim();
          sendResponse({
            hasKey: !!key,
            maskedKey: key ? ('•'.repeat(Math.max(0, key.length - 4)) + key.slice(-4)) : '',
            status: d.license_status || 'not_activated',
            deviceId: d.olm_device_id ? String(d.olm_device_id).slice(0, 8) + '…' : '',
            verifiedAt: Number(d.license_verified_at) || 0,
          });
        })
        .catch(() => sendResponse({ error: 'read_failed' }));
      return true;
    }

    default:
      return false;
  }
});

// ── Omnibox: "olm ..." ────────────────────────────────────────
const OLM_SUGGESTIONS = [
  { content: 'olm status',     description: 'Trạng thái license + remote config' },
  { content: 'olm update',     description: 'Kiểm tra cập nhật remote config ngay' },
  { content: 'olm menu',       description: 'Mở bảng điều khiển OLM' },
  { content: 'olm on',         description: 'Bật extension' },
  { content: 'olm off',        description: 'Tắt extension (giữ nguyên license)' },
  { content: 'olm rollback',   description: 'Quay lại phiên bản config trước' },
];

function renderStatusText(s) {
  const t = (v) => v ? new Date(v).toLocaleString() : '—';
  const lines = [
    `Extension : ${s.extensionVersion}  (schema ${s.schemaVersion})`,
    `Config    : ${s.activeVersion}  [${s.source}]`,
    `Latest    : ${s.lastKnownVersion}`,
    s.previousVersion ? `Previous  : ${s.previousVersion}` : null,
    `Checked   : ${t(s.lastCheckedAt)}`,
    `Success   : ${t(s.lastSuccessAt)}`,
    `State     : ${s.state}${s.stale ? ' (expired, vẫn dùng)' : ''}`,
    s.lastError ? `Last error: ${s.lastError}` : null,
  ].filter(Boolean);
  return lines.join('\n');
}

chrome.omnibox?.onInputChanged.addListener((text, suggest) => {
  const q = String(text || '').trim().toLowerCase();
  if (!q.startsWith('olm')) { suggest([]); return; }
  const arg = q.slice(3).trim();
  const list = !arg ? OLM_SUGGESTIONS : OLM_SUGGESTIONS.filter(s => s.content.includes(arg));
  suggest(list.map(s => ({ content: s.content, description: s.description })));
});

async function setEnabled(on) {
  await chrome.storage.local.set({ [ENABLE_KEY]: !!on });
  RC_LOG('enabled =', !!on);
  return { ok: true, enabled: !!on };
}

chrome.omnibox?.onInputEntered.addListener((text) => {
  const arg = String(text || '').trim().toLowerCase().replace(/^olm\s*/, '').trim();
  const openUi = (hash) => {
    const url = chrome.runtime.getURL('olm-ui.html') + (hash || '');
    chrome.tabs.create({ url }).catch(() => {});
  };
  if (arg === 'update') {
    manager.check({ forced: true }).then(r => openUi('#result=' + encodeURIComponent(JSON.stringify(r))));
    return;
  }
  if (arg === 'rollback') {
    manager.rollback().then(r => openUi('#result=' + encodeURIComponent(JSON.stringify(r))));
    return;
  }
  if (arg === 'on')  { setEnabled(true).then(() => openUi() ); return; }
  if (arg === 'off') { setEnabled(false).then(() => openUi()); return; }
  if (arg === 'status' || arg === 'menu' || arg === '') { openUi(); return; }
  openUi();
});

// ── Bootstrap ─────────────────────────────────────────────────
ensureConfigAlarm();
manager.init().then((i) => {
  RC_LOG('init', i.source, i.version);
  return scheduleFromManager();
}).catch((e) => RC_LOG('init error:', e.message));

chrome.runtime.onInstalled.addListener(() => {
  ensureConfigAlarm();
  // Hoãn nhẹ để không tranh tài nguyên với recheck license lúc cài đặt.
  setTimeout(() => { manager.check({ forced: false }).then(scheduleFromManager).catch(() => {}); }, 5000);
});
chrome.runtime.onStartup.addListener(() => { ensureConfigAlarm(); });

export { manager, RC_KEYS, BUILTIN_CONFIG, SCHEMA_VERSION };
