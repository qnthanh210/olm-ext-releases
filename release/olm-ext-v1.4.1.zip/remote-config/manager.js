// ============================================================
// OLM Remote Config — Update Manager
// ------------------------------------------------------------
// LOCAL ENGINE. Không bao giờ thực thi code từ xa; chỉ nhận DỮ LIỆU đã
// validate. Chạy trong Service Worker (extension/remote-config/index.js) và
// chạy được trong Node test nhờ dependency injection — không tham chiếu
// chrome.* ở module scope.
//
// Đảm bảo cứng:
//   • Một lần check tại một thời điểm (serialize bằng promise chain).
//   • Config active KHÔNG BAO GIỜ bị ghi đè bởi config chưa validate.
//   • Mọi lỗi → FAILED, giữ nguyên config cũ, có backoff.
//   • Luôn có effective config: active → previous → built-in.
// ============================================================

import {
  SCHEMA_VERSION, LIMITS, canonicalize, utf8Bytes,
  validateBundle, validateConfig, evaluateFreshness, isPlainObject,
} from './schema.js';
import { BUILTIN_CONFIG } from './default-config.js';

/** Key storage của hệ thống này — CỐ Ý không trùng key của License Manager. */
export const RC_KEYS = Object.freeze({
  meta:     'olm_rc_meta',
  active:   'olm_rc_active',
  previous: 'olm_rc_previous',
  staged:   'olm_rc_staged',
});

/** State machine. */
export const RC_STATE = Object.freeze({
  IDLE: 'IDLE',
  CHECKING: 'CHECKING',
  DOWNLOADING: 'DOWNLOADING',
  VALIDATING: 'VALIDATING',
  STAGED: 'STAGED',
  ACTIVATED: 'ACTIVATED',
  FAILED: 'FAILED',
  ROLLBACK: 'ROLLBACK',
});

const DEFAULT_INTERVAL_MS   = 6 * 60 * 60 * 1000;   // 6h — kiểm tra định kỳ
const MIN_INTERVAL_MS       = 30 * 60 * 1000;       // không fetch dày hơn 30 phút/lần
const BACKOFF_BASE_MS       = 30 * 60 * 1000;
const BACKOFF_MAX_MS        = 24 * 60 * 60 * 1000;
const FETCH_TIMEOUT_MS      = 8000;
const MAX_BACKOFF_EXPONENT  = 8;

/** meta khởi tạo — không phá dữ liệu cũ nếu đã tồn tại. */
function freshMeta() {
  return {
    schemaVersion: SCHEMA_VERSION,
    state: RC_STATE.IDLE,
    lastCheckedAt: 0,
    lastSuccessAt: 0,
    lastFailureAt: 0,
    lastError: '',
    etag: '',
    lastSeenVersion: '',
    activeVersion: '',
    previousVersion: '',
    consecutiveFailures: 0,
    nextCheckAt: 0,
    lastSource: 'builtin',
  };
}

/**
 * Chốt chặn cuối: nếu cả config built-in đi kèm gói extension cũng lỗi (không
 * xảy ra với bản build hợp lệ, nhưng đây là bất biến "extension không được
 * chết"), trả về cấu hình rỗng — content.js khi đó tự dùng hằng số hardcode.
 */
const LAST_RESORT = Object.freeze({
  schemaVersion: SCHEMA_VERSION,
  configVersion: '0.0.0',
  minimumExtensionVersion: '0.0.0',
  generatedAt: '1970-01-01T00:00:00Z',
  expiresAt: '2099-12-31T00:00:00Z',
  notes: 'last-resort: built-in config failed structural validation',
});

function isRecord(v) {
  return isPlainObject(v) && typeof v.configVersion === 'string' && isPlainObject(v.config);
}

/**
 * Tạo manager.
 * @param {object} deps
 * @param {{get:(keys:string[])=>Promise<object>, set:(obj:object)=>Promise<void>, remove:(keys:string[])=>Promise<void>}} deps.storage
 * @param {(url:string, init:object)=>Promise<any>} deps.fetchImpl
 * @param {string} deps.bundleUrl          URL allowlist cứng (không do config quyết định)
 * @param {number} [deps.extensionVersion]
 * @param {()=>number} [deps.now]
 * @param {(...a:any[])=>void} [deps.log]
 * @param {object} [deps.builtIn]
 */
export function createRemoteConfigManager(deps) {
  const {
    storage, fetchImpl, bundleUrl,
    extensionVersion = '0.0.0',
    now = () => Date.now(),
    log = () => {},
    builtIn = BUILTIN_CONFIG,
    intervalMs = DEFAULT_INTERVAL_MS,
  } = deps;

  if (typeof bundleUrl !== 'string' || !bundleUrl) throw new Error('bundleUrl is required');
  if (typeof storage?.get !== 'function' || typeof storage?.set !== 'function') {
    throw new Error('storage adapter with get/set is required');
  }
  if (typeof fetchImpl !== 'function') throw new Error('fetchImpl is required');

  const listeners = new Set();
  let pending = null;              // promise của check đang chạy (coalesce)

/** Transient state cũ hơn ngần này = coi như kẹt do SW bị kill → IDLE. */
const STALE_STATE_MS = 60 * 1000;
const TRANSIENT_STATES = new Set([
  RC_STATE.CHECKING, RC_STATE.DOWNLOADING, RC_STATE.VALIDATING, RC_STATE.STAGED,
]);

async function readMeta() {
  try {
    const r = await storage.get([RC_KEYS.meta]);
    const m = isPlainObject(r?.[RC_KEYS.meta]) ? r[RC_KEYS.meta] : {};
    return { ...freshMeta(), ...m };
  } catch (_) {
    return freshMeta();
  }
}

  async function writeMeta(patch) {
    const m = { ...(await readMeta()), ...patch };
    await storage.set({ [RC_KEYS.meta]: m });
    return m;
  }

  /**
   * Ghi meta nhưng KHÔNG để lỗi storage làm sập update flow.
   * Storage hỏng vẫn phải trả về config đang dùng (fail-safe).
   */
  async function tryWriteMeta(patch) {
    try { await writeMeta(patch); return true; }
    catch (e) { log('rc: write meta failed —', e?.message); return false; }
  }

  async function readEntry(key) {
    try {
      const r = await storage.get([key]);
      const v = r?.[key];
      return isRecord(v) ? v : null;
    } catch (_) { return null; }
  }

  async function writeEntry(key, entry) {
    await storage.set({ [key]: entry });
  }

  function makeEntry(config, source) {
    return {
      schemaVersion: config.schemaVersion,
      configVersion: config.configVersion,
      installedAt: now(),
      source,
      config,
    };
  }

  /** Re-validate một entry đã đọc từ storage (cold-read guard). */
  async function revalidateEntry(entry) {
    if (!entry) return null;
    const res = validateConfig(entry.config, { extensionVersion, now: now() });
    if (!res.ok) {
      log('rc: cached entry rejected on re-read —', res.errors[0]);
      return null;
    }
    return entry;
  }

  // ── Public: lấy config đang dùng (không bao giờ null, không bao giờ throw) ──
  async function getEffective() {
    const active = await revalidateEntry(await readEntry(RC_KEYS.active));
    if (active) return { config: active.config, source: 'active', entry: active };

    const previous = await revalidateEntry(await readEntry(RC_KEYS.previous));
    if (previous) return { config: previous.config, source: 'previous', entry: previous };

    // Built-in: origin 'local' → bỏ kiểm tra thời gian, giữ kiểm tra cấu trúc.
    let local = null;
    try {
      const res = validateConfig(builtIn, { extensionVersion, origin: 'local' });
      if (res.ok) local = res.config;
      else log('rc: built-in config invalid —', res.errors.slice(0, 3).join('; '));
    } catch (e) { log('rc: built-in validate threw —', e?.message); }
    const cfg = local || LAST_RESORT;
    return { config: cfg, source: local ? 'builtin' : 'builtin', entry: makeEntry(cfg, 'builtin') };
  }

  /** Effective config + metadata, dùng cho content.js. */
  async function getSnapshot() {
    const eff = await getEffective();
    const meta = await readMeta();
    return {
      config: eff.config,
      source: eff.source,
      configVersion: eff.config.configVersion,
      schemaVersion: eff.config.schemaVersion,
      installedAt: eff.entry?.installedAt || 0,
      expiresAt: eff.config.expiresAt || '',
      stale: !!(eff.config.expiresAt && Date.parse(eff.config.expiresAt) < now()),
      state: meta.state,
    };
  }

  async function getStatus() {
    const meta = await readMeta();
    const eff = await getEffective();
    // SW có thể bị kill giữa chừng → state kẹt CHECKING/VALIDATING không có
    // nghĩa là đang chạy. Quá 60s không đổi → coi như IDLE.
    let state = meta.state;
    if (TRANSIENT_STATES.has(state) && (!meta.lastCheckedAt || now() - meta.lastCheckedAt > STALE_STATE_MS)) {
      state = RC_STATE.IDLE;
    }
    return {
      extensionVersion,
      schemaVersion: SCHEMA_VERSION,
      source: eff.source,
      activeVersion: eff.config.configVersion,
      lastKnownVersion: meta.lastSeenVersion || eff.config.configVersion,
      previousVersion: meta.previousVersion || '',
      state,
      lastCheckedAt: meta.lastCheckedAt || 0,
      lastSuccessAt: meta.lastSuccessAt || 0,
      lastError: meta.lastError || '',
      consecutiveFailures: meta.consecutiveFailures || 0,
      nextCheckAt: meta.nextCheckAt || 0,
      expiresAt: eff.config.expiresAt || '',
      stale: !!(eff.config.expiresAt && Date.parse(eff.config.expiresAt) < now()),
    };
  }

  function emit(type, detail) {
    for (const cb of listeners) {
      try { cb(type, detail); } catch (e) { log('rc: listener error —', e?.message); }
    }
  }

  function onChange(cb) {
    listeners.add(cb);
    return () => listeners.delete(cb);
  }

  // ── Backoff ─────────────────────────────────────────────────
  function backoffMs(failures) {
    const exp = Math.min(Math.max(failures - 1, 0), MAX_BACKOFF_EXPONENT);
    return Math.min(BACKOFF_BASE_MS * (2 ** exp), BACKOFF_MAX_MS);
  }

  function nextCheckDelay(meta, forced) {
    if (forced) return 0;
    if (meta.nextCheckAt > now()) return meta.nextCheckAt - now();
    if (!meta.lastCheckedAt) return 0;
    // Sàn chống fetch dày: tối thiểu max(interval, MIN_INTERVAL) kể từ lần check gần nhất.
    const target = Math.max(intervalMs, MIN_INTERVAL_MS);
    return Math.max(0, target - (now() - meta.lastCheckedAt));
  }

  // ── Fetch có timeout + cấp chữa ────────────────────────────
  async function fetchBundle(etag) {
    const headers = { 'Accept': 'application/json' };
    if (etag) headers['If-None-Match'] = etag;

    const ctrl = typeof AbortController === 'function' ? new AbortController() : null;
    const timer = ctrl ? setTimeout(() => ctrl.abort(), FETCH_TIMEOUT_MS) : null;
    try {
      const res = await fetchImpl(bundleUrl, { method: 'GET', headers, signal: ctrl?.signal, cache: 'no-store' });
      if (!res) throw new Error('no_response');
      if (res.status === 304) return { notModified: true, etag };
      if (!res.ok) {
        const err = new Error('http_' + res.status);
        err.httpStatus = res.status;
        throw err;
      }
      // Chặn payload khổng lồ trước khi đọc hết vào RAM.
      const declared = Number(res.headers?.get?.('content-length') || 0);
      if (declared && declared > LIMITS.MAX_BUNDLE_BYTES) throw new Error('too_large');
      const text = await res.text();
      if (typeof text !== 'string') throw new Error('no_body');
      if (utf8Bytes(text).length > LIMITS.MAX_BUNDLE_BYTES) throw new Error('too_large');
      return { notModified: false, text, etag: res.headers?.get?.('etag') || '' };
    } finally {
      if (timer) clearTimeout(timer);
    }
  }

  // ── Failure path ────────────────────────────────────────────
  async function fail(reason, extra = {}) {
    const meta = await readMeta();
    const failures = (meta.consecutiveFailures || 0) + 1;
    const delay = backoffMs(failures);
    await tryWriteMeta({
      state: RC_STATE.FAILED,
      lastCheckedAt: now(),
      lastFailureAt: now(),
      lastError: String(reason).slice(0, 200),
      consecutiveFailures: failures,
      nextCheckAt: now() + delay,
      ...extra,
    });
    emit('failed', { reason: String(reason), retryInMs: delay });
    return { ok: false, reason: String(reason), retryInMs: delay };
  }

  // ── Update flow ─────────────────────────────────────────────
  async function runCheck({ forced = false } = {}) {
    const meta = await readMeta();

    const wait = nextCheckDelay(meta, forced);
    if (wait > 0) {
      return { ok: true, skipped: 'too_soon', retryInMs: wait, version: meta.activeVersion };
    }

    await tryWriteMeta({ state: RC_STATE.CHECKING, nextCheckAt: 0 });

    // 1) Metadata + body
    let fetched;
    try {
      fetched = await fetchBundle(meta.etag);
    } catch (e) {
      log('rc: fetch failed —', e?.message);
      return fail(e?.message || 'fetch_failed');
    }

    if (fetched.notModified) {
      await tryWriteMeta({
        state: RC_STATE.IDLE, lastCheckedAt: now(), lastError: '', consecutiveFailures: 0,
      });
      emit('checked', { notModified: true });
      return { ok: true, skipped: 'not_modified', version: meta.activeVersion };
    }

    // 2) Parse
    await tryWriteMeta({ state: RC_STATE.DOWNLOADING });
    let bundle;
    try {
      bundle = JSON.parse(fetched.text);
    } catch (e) {
      return fail('invalid_json');
    }

    // 3) Integrity + schema
    await tryWriteMeta({ state: RC_STATE.VALIDATING });
    const v = await validateBundle(bundle, { extensionVersion, now: now() });
    if (!v.ok) {
      log('rc: bundle rejected —', v.errors.slice(0, 3).join('; '));
      return fail('invalid_bundle', { lastError: v.errors.slice(0, 3).join('; ').slice(0, 200) });
    }
    const incoming = v.config;

    // 4) Freshness — chống downgrade.
    const current = await revalidateEntry(await readEntry(RC_KEYS.active));
    const currentVersion = current?.configVersion || '';
    const freshness = evaluateFreshness(incoming.configVersion, currentVersion);

    // 'new' = chưa có config active nào (cài lần đầu) → vẫn phải promote được.
    // 'same' / 'older' = không có gì mới → giữ nguyên, KHÔNG downgrade.
    if (freshness !== 'newer' && freshness !== 'new') {
      // Không có gì mới (hoặc config xuống cấp) → giữ nguyên active.
      await tryWriteMeta({
        state: RC_STATE.IDLE,
        lastCheckedAt: now(),
        lastSuccessAt: now(),
        lastError: '',
        consecutiveFailures: 0,
        etag: fetched.etag || meta.etag,
        lastSeenVersion: incoming.configVersion,
      });
      emit('checked', { notModified: false, version: incoming.configVersion, freshness });
      return { ok: true, skipped: freshness, version: incoming.configVersion, activated: false };
    }

    // 5) Stage — ghi ra vùng tạm, CHƯA đụng active.
    await tryWriteMeta({ state: RC_STATE.STAGED });
    const staged = makeEntry(incoming, 'remote');
    try {
      await writeEntry(RC_KEYS.staged, staged);
    } catch (e) {
      return fail('stage_write_failed');
    }

    // 6) Test staged như lần đọc lạnh (mô phỏng SW bị kill giữa chừng).
    let cold = null;
    try { cold = await revalidateEntry(await readEntry(RC_KEYS.staged)); } catch (_) {}
    if (!cold) {
      await storage.remove([RC_KEYS.staged]).catch(() => {});
      return fail('staged_invalid');
    }

    // 7) Promote — active chỉ bị ghi sau khi mọi thứ đã pass.
    let prevVersion = '';
    try {
      const prevActive = await readEntry(RC_KEYS.active);
      const patch = { [RC_KEYS.active]: makeEntry(cold.config, 'remote') };
      if (isRecord(prevActive)) {
        prevVersion = prevActive.configVersion || '';
        patch[RC_KEYS.previous] = { ...prevActive, promotedAt: now() };
      }
      await storage.set(patch);
      await storage.remove([RC_KEYS.staged]).catch(() => {});
    } catch (e) {
      log('rc: promote failed —', e?.message);
      await storage.remove([RC_KEYS.staged]).catch(() => {});
      return fail('promote_failed');
    }

    await tryWriteMeta({
      state: RC_STATE.ACTIVATED,
      lastCheckedAt: now(),
      lastSuccessAt: now(),
      lastError: '',
      consecutiveFailures: 0,
      etag: fetched.etag || '',
      lastSeenVersion: incoming.configVersion,
      activeVersion: incoming.configVersion,
      previousVersion: prevVersion,
      lastSource: 'remote',
      nextCheckAt: 0,
    });

    emit('activated', { version: incoming.configVersion, source: 'remote' });
    return { ok: true, activated: true, version: incoming.configVersion, previousVersion: prevVersion };
  }

  /**
   * Serialize + COALESCE: nếu đang có một check chạy dở thì các lời gọi
   * check() khác nhận lại ĐÚNG promise đó. Nhờ vậy 4 request cùng lúc chỉ
   * fetch đúng 1 lần, không có hai update chạy song song (mục 32/33).
   */
  function check(opts = {}) {
    if (pending) return pending;
    const p = (async () => {
      try { return await runCheck(opts); }
      catch (e) {
        log('rc: unexpected error —', e?.message);
        return fail('internal_error');
      }
    })();
    pending = p;
    const clear = () => { if (pending === p) pending = null; };
    p.then(clear, clear);
    return p;
  }

  /**
   * Rollback thủ công: đưa PREVIOUS trở lại ACTIVE.
   * Chỉ dùng khi config hiện tại gây lỗi; vẫn qua validate trước khi ghi.
   */
  async function rollback() {
    const prev = await revalidateEntry(await readEntry(RC_KEYS.previous));
    if (!prev) return { ok: false, reason: 'no_previous' };

    await tryWriteMeta({ state: RC_STATE.ROLLBACK });
    try {
      const cur = await readEntry(RC_KEYS.active);
      const patch = { [RC_KEYS.active]: { ...prev, installedAt: now(), source: 'rollback' } };
      // previous <- chính entry vừa bị gỡ để có thể rollback hai lần.
      if (isRecord(cur)) patch[RC_KEYS.previous] = { ...cur, promotedAt: now() };
      await storage.set(patch);
    } catch (e) {
      log('rc: rollback failed —', e?.message);
      await tryWriteMeta({ state: RC_STATE.FAILED, lastError: 'rollback_failed' });
      return { ok: false, reason: 'rollback_failed' };
    }
    const meta = await readMeta();
    await tryWriteMeta({
      state: RC_STATE.IDLE,
      activeVersion: prev.configVersion,
      lastSource: 'rollback',
    });
    emit('rolledback', { version: prev.configVersion });
    return { ok: true, version: prev.configVersion };
  }

  /** Khởi tạo: nạp cache, không chặn, không gọi mạng. */
  async function init() {
    const meta = await readMeta();
    await tryWriteMeta({ state: RC_STATE.IDLE });
    const eff = await getEffective();
    return { source: eff.source, version: eff.config.configVersion, meta };
  }

  /** Kế hoạch lần kiểm tra kế tiếp (ms từ `now`). */
  async function getNextCheckIn() {
    const meta = await readMeta();
    return nextCheckDelay(meta, false);
  }

  return {
    init, check, rollback, getEffective, getSnapshot, getStatus,
    onChange, getNextCheckIn,
    RC_KEYS, RC_STATE,
    _internals: { backoffMs, nextCheckDelay, readMeta, readEntry, writeEntry, canonicalize },
  };
}
