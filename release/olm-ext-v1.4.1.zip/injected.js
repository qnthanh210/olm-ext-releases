// ============================================================
// OLM Panel — injected.js
// CHẠY TRONG MAIN WORLD qua manifest content_scripts world:"MAIN"
// run_at: document_start — chạy TRƯỚC KHI trang tải bất kỳ JS nào
//
// CÓ THỂ TRUY CẬP: window thật, fetch thật, XHR thật,
//   window.CATE_UI, window.LZString, Vue __vueParentComponent
//
// GIAO TIẾP với content.js (isolated world) qua window.postMessage
// ============================================================
(function olmInjectedRuntime() {
  'use strict';

  // ── Singleton guard ──────────────────────────────────────
  if (window.__OLM_INJECTED__) {
    console.log('[OLM-INJ] Already running, skip.');
    return;
  }
  window.__OLM_INJECTED__ = true;
  window.__OLM_INJ_VERSION__ = '5.4.5';

  const DEBUG = false;
  const L = {
    log:  (...a) => console.log('[OLM-INJ]', ...a),
    warn: (...a) => console.warn('[OLM-INJ]', ...a),
    err:  (...a) => console.error('[OLM-INJ]', ...a),
    dbg:  (...a) => DEBUG && console.debug('[OLM-INJ-DBG]', ...a),
  };

  // ── Bridge token (lớp filtering postMessage — KHÔNG phải auth tuyệt đối) ───
  // Token được tạo tại đây và share sang content.js qua postMessage đầu tiên.
  // postMessage trong MAIN world không thể coi là trusted channel tuyệt đối:
  // bất kỳ script nào trên trang cũng có thể postMessage. Bảo mật thực sự dựa vào
  // message schema + type allowlist + reqId khớp pending + payload validation +
  // timeout + size limit (xem validation layer bên dưới), không dựa vào token.
  const BRIDGE_TOKEN = 'olm_' + Math.random().toString(36).slice(2) + Date.now().toString(36);
  let contentScriptReady = false;

  // SECURITY (v1.3.5): giới hạn kích thước để 1 message bất thường không treo bridge.
  const SEC_INJ = {
    MAX_MESSAGE_BYTES: 2000000,   // 2MB cho 1 postMessage JSON
    MAX_B64_BYTES: 500000,        // 500KB cho 1 decode request
    MAX_RESULT_BYTES: 1000000,    // 1MB cho decode result
    MAX_VUE_ITEMS: 100,
  };
  const SEC_ALLOWED_FROM_CONTENT = new Set([
    'OLM_CONTENT_READY', 'OLM_GET_GLOBALS', 'OLM_PAGE_DECODE', 'OLM_DECODE_VUE', 'OLM_RENDER_MATH',
    'OLM_PAGE_CONTEXT',
  ]);
  function secSize(v) {
    try { return typeof v === 'string' ? v.length : (JSON.stringify(v)?.length || 0); }
    catch (_) { return 0; }
  }

  // ── Endpoint tracking ────────────────────────────────────
  // Đã xác minh trên olm.vn (2026-10): endpoint là
  //   POST https://olm.vn/course/question/get-question-of-ids
  //   body: qlib_list[]=<id>&id_subject=..&id_skill=..&cv_q=1&encodeXORBase64=true
  //   resp: JSON **array thuần** (không bọc {list:..}), phần tử có
  //         id (số), _id (hex), content + json_content (XOR+base64).
  //
  // FIX: trước đây learnEndpoint() lấy segment CUỐI của pathname rồi ghi đè
  // TARGET_URL_KEYWORD — bất kỳ API nào trả về mảng object nào cũng bị "học"
  // thành endpoint câu hỏi, khiến isTrackedUrl() khớp nhầm và bỏ sót response
  // thật của get-question-of-ids. Nay chỉ chấp nhận endpoint khớp mẫu rõ ràng.
  const TARGET_URL_KEYWORD = 'get-question-of-ids';
  const DETECTED_ENDPOINTS = new Set([TARGET_URL_KEYWORD]);
  // Mẫu dương để nhận endpoint câu hỏi (không dựa vào tên segment tùy ý).
  const QUESTION_URL_HINTS = [
    /get[-_]?question[-_]?of[-_]?ids/i,
    /question[-_]?of[-_]?ids/i,
    /questions?[-_]?of[-_]?ids/i,
    /\/(api|course)\/.*question.*ids/i,
  ];

  function isTrackedUrl(url) {
    if (!url || typeof url !== 'string') return false;
    return url.includes(TARGET_URL_KEYWORD);
  }

  // Chỉ "học" endpoint khi URL khớp mẫu câu hỏi VÀ payload giống hệt shape
  // của OLM (id số + content/json_content). Trả về keyword để thêm vào set.
  function learnEndpoint(url) {
    if (!url || typeof url !== 'string') return null;
    if (isTrackedUrl(url)) return TARGET_URL_KEYWORD;
    if (!QUESTION_URL_HINTS.some(re => re.test(url))) return null;
    try {
      const u = new URL(url, location.href);
      const segments = u.pathname.split('/').filter(s => s && !/^\d+$/.test(s));
      const keyword = segments[segments.length - 1] || '';
      if (!keyword || keyword.length <= 4) return null;
      DETECTED_ENDPOINTS.add(keyword);
      L.log('Learned question endpoint:', keyword, '<-', url.slice(0, 120));
      return keyword;
    } catch (_) { return null; }
  }

  // Shape thật của 1 câu hỏi OLM: id số + content/json_content (XOR+base64).
  // Siết chặt để không nuốt nhầm API khác (bài viết, nhóm, thông báo...).
  function looksLikeQuestionList(data) {
    let list = data;
    if (!Array.isArray(list)) {
      list = (data && (data.list || data.data || data.questions || data.items)) || null;
    }
    if (!Array.isArray(list) || list.length === 0) return false;
    // Xác minh trên cả mẫu đầu VÀ giữa danh sách: OLM không trộn lẫn loại.
    const samples = [list[0], list[Math.floor(list.length / 2)]].filter(Boolean);
    return samples.every((sample) => {
      if (!sample || typeof sample !== 'object') return false;
      const hasNumericId = typeof sample.id === 'number' || /^\d{6,}$/.test(String(sample.id ?? ''));
      const hasMongoId = typeof sample._id === 'string' && /^[a-f0-9]{24}$/i.test(sample._id);
      const hasEncoded = typeof sample.content === 'string' && sample.content.length > 40;
      const hasJson = typeof sample.json_content === 'string' && sample.json_content.length > 40;
      return (hasNumericId || hasMongoId) && (hasEncoded || hasJson);
    });
  }

  // ── XOR Key ──────────────────────────────────────────────
  let OLM_XOR_KEY = '1047823200';
  let xorKeyLearned = false;

  function tryExtractXorKey(text) {
    if (!text || typeof text !== 'string') return null;
    const patterns = [
      /xor[A-Za-z_]*\s*[=:]\s*['"](\d{6,14})['"]/i,
      /encode[A-Za-z_]*Key\s*[=:]\s*['"](\d{6,14})['"]/i,
      /OlmEncode[\s\S]{0,300}['"](\d{8,14})['"]/,
      /charCodeAt\s*\(\s*\w+\s*%\s*\w+\.length\s*\)[\s\S]{0,200}['"](\d{8,14})['"]/,
      /['"](\d{8,14})['"]\s*;?\s*\/\/[^\n]*(key|xor|mã|khóa)/i,
    ];
    for (const re of patterns) {
      const m = text.match(re);
      if (m) {
        const key = m[m.length - 1];
        if (/^\d{6,14}$/.test(key)) return key;
      }
    }
    return null;
  }

  function setXorKey(key) {
    if (!key || OLM_XOR_KEY === key) return;
    OLM_XOR_KEY = key;
    xorKeyLearned = true;
    L.log('XOR key set:', key);
    // Thông báo cho content.js
    postToContent({ type: 'OLM_XOR_KEY', key });
  }

  function scanInlineScripts() {
    if (xorKeyLearned) return;
    document.querySelectorAll('script:not([src])').forEach(s => {
      if (xorKeyLearned) return;
      const found = tryExtractXorKey(s.textContent || '');
      if (found) setXorKey(found);
    });
  }

  function scanBundleScripts() {
    if (xorKeyLearned) return;
    const candidates = Array.from(document.querySelectorAll('script[src]'))
      .filter(s => /olm|app|chunk|main|bundle/i.test(s.src))
      .slice(0, 2);

    const fetchNext = (i) => {
      if (i >= candidates.length || xorKeyLearned) return;
      fetch(candidates[i].src, { cache: 'force-cache' })
        .then(r => r.text())
        .then(text => {
          if (!xorKeyLearned) {
            const found = tryExtractXorKey(text);
            if (found) setXorKey(found);
          }
          fetchNext(i + 1);
        })
        .catch(() => fetchNext(i + 1));
    };
    fetchNext(0);
  }

  // Scan ngay (document_start — inline scripts có thể chưa có)
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      scanInlineScripts();
      scanBundleScripts();
    }, { once: true });
  } else {
    scanInlineScripts();
    scanBundleScripts();
  }
  setTimeout(scanBundleScripts, 3000);
  setTimeout(scanBundleScripts, 8000);

  // ── XOR decode (local, không cần CATE_UI) ────────────────
  function normalizeBase64(s) {
    if (s == null || typeof s !== 'string') return '';
    let t = s.trim().replace(/\s/g, '');
    t = t.replace(/-/g, '+').replace(/_/g, '/');
    const pad = t.length % 4;
    if (pad) t += '='.repeat(4 - pad);
    return t;
  }

  function olmXorDecodeBase64(b64) {
    if (!b64) return null;
    const normalized = normalizeBase64(b64);
    if (!normalized || !/^[A-Za-z0-9+/=]+$/.test(normalized)) return null;
    try {
      const raw = atob(normalized);
      const kl = OLM_XOR_KEY.length;
      const xored = new Uint8Array(raw.length);
      for (let i = 0; i < raw.length; i++) {
        xored[i] = raw.charCodeAt(i) ^ OLM_XOR_KEY.charCodeAt(i % kl);
      }
      try {
        return new TextDecoder('utf-8', { fatal: true }).decode(xored);
      } catch (_) {
        return new TextDecoder('iso-8859-1').decode(xored);
      }
    } catch (_) { return null; }
  }

  // ── CATE_UI / OlmEncode access ───────────────────────────
  function getPageDecodeFn() {
    try {
      if (window.CATE_UI?.OlmEncode?.xorDecodeBase64)
        return window.CATE_UI.OlmEncode.xorDecodeBase64.bind(window.CATE_UI.OlmEncode);
      if (window.OlmEncode?.xorDecodeBase64)
        return window.OlmEncode.xorDecodeBase64.bind(window.OlmEncode);
    } catch (_) {}
    return null;
  }

  // ── Vue 3 drag-drop extractor ────────────────────────────
  // CHỈ hoạt động được trong main world — __vueParentComponent không visible từ isolated world
  function extractDragDropFromVue(question) {
    try {
      const qid = question.id != null ? String(question.id) : '';
      if (!qid) return [];
      const block = document.querySelector(
        `[data-id="${qid}"],[data-idquestion="${qid}"],[data-question-id="${qid}"],` +
        `[data-question="${qid}"],[data-qid="${qid}"],[data-questionid="${qid}"],` +
        `[data-id-quiz="${qid}"],[data-id_quiz="${qid}"],[data-idquiz="${qid}"],` +
        `#question-${qid},#q-${qid},#cauhoi-${qid}`
      );
      if (!block) return [];

      const findVue = (el, depth = 0) => {
        if (!el || depth > 8) return null;
        const vk = Object.keys(el).find(k =>
          k.startsWith('__vueParentComponent') || k === '__vue_app__' || k.startsWith('__vue__')
        );
        if (vk) return el[vk];
        for (const child of (el.children || [])) {
          const found = findVue(child, depth + 1);
          if (found) return found;
        }
        return null;
      };

      const vueInst = findVue(block);
      if (!vueInst) return [];

      const results = [];
      const seen = new Set();
      const checkObj = (obj, depth = 0) => {
        if (!obj || typeof obj !== 'object' || depth > 6) return;
        for (const key of Object.keys(obj)) {
          const v = obj[key];
          if (/answer|correct|blank|slot|result/i.test(key)) {
            if (typeof v === 'string' && v.trim() && !seen.has(v)) {
              seen.add(v);
              results.push({ slot: results.length + 1, answer: v.trim() });
            } else if (Array.isArray(v)) {
              v.forEach((item, i) => {
                const t = typeof item === 'string' ? item
                  : (item && (item.answer || item.text || item.value || item.content));
                if (t && typeof t === 'string' && t.trim() && !seen.has(t)) {
                  seen.add(t);
                  results.push({ slot: i + 1, answer: t.trim() });
                }
              });
            }
          }
          if (v && typeof v === 'object' && !Array.isArray(v)) checkObj(v, depth + 1);
        }
      };

      const inst = vueInst.exposed || vueInst.setupState || vueInst.props || vueInst.data;
      if (inst) checkObj(inst);
      return results;
    } catch (_) { return []; }
  }

  // ── LZString (trang OLM có thể tự load, hoặc ta tự decode) ─
  function getLZ() {
    try {
      if (typeof window.LZString !== 'undefined') return window.LZString;
    } catch (_) {}
    return null;
  }

  // ── tryDecodeViaOlmRuntime: thử dùng hàm decode của trang ─
  let cachedOlmDecoder = null;
  function isGarbageText(str) {
    if (str == null || str === '') return true;
    const bad = (str.match(/\uFFFD/g) || []).length;
    if (str.length > 0 && bad / str.length > 0.02) return true;
    if (str.length > 40 && !str.includes('<') && /[\u0000-\u0008\u000b\u000c\u000e-\u001f]/.test(str)) return true;
    return false;
  }

  function tryDecodeViaOlmRuntime(b64) {
    if (!b64) return null;
    try {
      const localXor = olmXorDecodeBase64(b64);
      if (typeof localXor === 'string' && localXor.length > 0 && !isGarbageText(localXor)
          && (localXor.includes('<') || localXor.trim().startsWith('{') || localXor.length > 20)) {
        return localXor;
      }
      const xorFn = getPageDecodeFn();
      if (xorFn) {
        try {
          const r = xorFn(b64);
          if (typeof r === 'string' && !isGarbageText(r) && (r.includes('<') || r.length > 20)) {
            cachedOlmDecoder = xorFn;
            return r;
          }
        } catch (_) {}
      }
      if (cachedOlmDecoder) {
        try {
          const r = cachedOlmDecoder(b64);
          if (typeof r === 'string' && !isGarbageText(r) && (r.includes('<') || r.length > 20)) return r;
        } catch (_) { cachedOlmDecoder = null; }
      }
      // Scan named decode functions on window (main world only)
      const named = [
        'decodeQuestionContent','decodeHtmlContent','decodeContent','decodeQuizContent',
        'unpackQuestionContent','b64DecodeHtml','decodeBase64Content','decodeQuestionHtml'
      ];
      for (const name of named) {
        if (typeof window[name] === 'function') {
          try {
            const r = window[name](b64);
            if (typeof r === 'string' && !isGarbageText(r) && (r.includes('<') || r.trim().startsWith('{'))) {
              cachedOlmDecoder = window[name];
              return r;
            }
          } catch (_) {}
        }
      }
      // Scan window keys
      for (const k of Object.keys(window)) {
        if (k.length > 80) continue;
        if (!/decode|unpack|decompress|parse.*content|question.*html/i.test(k)) continue;
        if (typeof window[k] !== 'function') continue;
        try {
          const r = window[k](b64);
          if (typeof r === 'string' && !isGarbageText(r) && (r.includes('<') || (r.trim().startsWith('{') && r.length < 500000))) {
            cachedOlmDecoder = window[k];
            return r;
          }
        } catch (_) {}
      }
    } catch (_) {}
    return null;
  }

  // ── Đọc identity của câu hỏi ĐANG HIỂN THỊ (MAIN world) ─────
  // GIAO DIỆN MỚI olm.vn (đã kiểm chứng):
  //   <default-root>                     ← Lit host, shadowRoot MỞ
  //     ├ jsonQuestion.id                ← id câu đang hiện (khớp API `id`)
  //     └ shadowRoot
  //         └ <type-quiz-x>              ← trắc nghiệm, shadowRoot MỞ
  //             #quiz-list > .answer-container.quiz-list > div.qselect[ind]
  //         └ <type-true-fasle>           ← đúng/sai (typo của OLM), shadowRoot MỞ
  //             #true-false > table > tr.tf-row > td.tf-box > span.qiradio.xcorrect[ind]
  //
  // `ind` = chỉ số option GỐC (trang shuffle thứ tự hiển thị). Đây là đường
  // đáng tin cậy nhất để tô đáp án: miễn nhiễm hoàn toàn với chênh lệch text
  // do KaTeX render (ví dụ API "y=\cos x" vs DOM "y=cosx").
  const PAGE_CTX_MAX_HOSTS = 8;
  const PAGE_CTX_MAX_OPTIONS = 60;

  function _pcText(el) {
    if (!el) return '';
    return String(el.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 300);
  }

  function _pcWalkShadowRoots(root, depth, out, maxDepth) {
    if (!root || depth > (maxDepth || 3) || out.length > 40) return out;
    let els = [];
    try { els = root.querySelectorAll('*'); } catch (_) { return out; }
    for (const el of els) {
      if (el.shadowRoot && out.indexOf(el.shadowRoot) < 0) out.push(el.shadowRoot);
    }
    return out;
  }

  function readPageQuestionHosts() {
    const hosts = [];
    try {
      // 1) UI mới: <default-root> và các host tương tự
      const litHosts = [];
      try {
        document.querySelectorAll('default-root').forEach(el => litHosts.push(el));
      } catch (_) {}
      if (!litHosts.length) {
        try {
          document.querySelectorAll('*').forEach(el => {
            const t = (el.tagName || '').toLowerCase();
            if (t.includes('-') && el.shadowRoot && (t.includes('quiz') || t.includes('question') || t.includes('true-fasle') || t.includes('true-false'))) {
              litHosts.push(el);
            }
          });
        } catch (_) {}
      }
      for (const host of litHosts.slice(0, PAGE_CTX_MAX_HOSTS)) {
        if (!host || !host.isConnected || host.hidden) continue;
        const qid = host.jsonQuestion && host.jsonQuestion.id != null ? String(host.jsonQuestion.id) : '';
        const sr0 = host.shadowRoot;
        if (!sr0) continue;
        const roots = _pcWalkShadowRoots(sr0, 0, [sr0], 3);
        let kind = '', stem = '', options = [];

        for (const r of roots) {
          // ── Trắc nghiệm: div.qselect ──
          let opts = [];
          try { opts = Array.from(r.querySelectorAll('.qselect')); } catch (_) {}
          if (opts.length) {
            kind = 'mc';
            stem = _pcText(r.querySelector('.question-content'));
            options = opts.slice(0, PAGE_CTX_MAX_OPTIONS).map(o => {
              const cls = String(o.className || '');
              return {
                tag: (o.tagName || '').toLowerCase(),
                ind: o.getAttribute('ind') != null ? String(o.getAttribute('ind')) : null,
                correct: /correctq|qcorrect|is-correct|answer-correct|correctanswer/i.test(cls),
                text: _pcText(o.querySelector('.qsign') || o),
                cls: cls.trim().slice(0, 60),
              };
            });
            break;
          }
          // ── Đúng / Sai: tr.tf-row ── (kiểm TRƯỚC mục [ind] chung, vì
          // span.qiradio của ĐS cũng có [ind] và sẽ bị nhận nhầm là option MC)
          let rows = [];
          try { rows = Array.from(r.querySelectorAll('tr.tf-row,.tf-row')); } catch (_) {}
          if (rows.length) {
            kind = 'tf';
            stem = _pcText(r.querySelector('.question-content'));
            options = rows.slice(0, PAGE_CTX_MAX_OPTIONS).map(row => {
              const box = row.querySelector('.tf-box,td:last-child');
              const trueBox = box ? box.querySelector('.qiradio.xcorrect,.xcorrect,[class*="xcorrect"]') : null;
              const ind = trueBox ? trueBox.getAttribute('ind') : (box ? box.querySelector('[ind]')?.getAttribute('ind') : null);
              return {
                tag: 'tr',
                ind: ind != null ? String(ind) : null,
                correct: trueBox != null,
                text: _pcText(row.querySelector('td:first-child') || row),
                cls: String(row.className || '').trim().slice(0, 60),
              };
            });
            break;
          }
          // ── UI cũ: option có [ind] ──
          try { opts = Array.from(r.querySelectorAll('[ind]')); } catch (_) {}
          if (opts.length) {
            kind = 'legacy-mc';
            stem = _pcText(r.querySelector('.question-content'));
            options = opts.slice(0, PAGE_CTX_MAX_OPTIONS).map(o => ({
              tag: (o.tagName || '').toLowerCase(),
              ind: o.getAttribute('ind'),
              correct: /correctq|qcorrect|is-correct|answer-correct/i.test(String(o.className || '')),
              text: _pcText(o),
              cls: String(o.className || '').trim().slice(0, 60),
            }));
            break;
          }
        }
        if (!kind) continue;
        hosts.push({ qid, kind, stem, options, scope: 'default-root' });
      }

      // 2) UI cũ: dùng attribute id trực tiếp trên DOM (nếu có)
      if (!hosts.length) {
        try {
          const blocks = document.querySelectorAll('[data-id-quiz],[data-id_quiz],[data-question-id],[data-id]');
          let n = 0;
          for (const b of blocks) {
            if (n >= PAGE_CTX_MAX_HOSTS) break;
            if (!b.isConnected) continue;
            const r = b.getBoundingClientRect();
            if (r.width < 40 || r.height < 20) continue;
            const qid = b.getAttribute('data-id-quiz') || b.getAttribute('data-id_quiz')
              || b.getAttribute('data-question-id') || b.getAttribute('data-id') || '';
            const opts = Array.from(b.querySelectorAll('.qselect,[ind],li,[class*="option"],[class*="choice"]'))
              .slice(0, PAGE_CTX_MAX_OPTIONS);
            if (!opts.length) continue;
            hosts.push({
              qid, kind: 'legacy', stem: _pcText(b.querySelector('.question-content')),
              options: opts.map(o => ({
                tag: (o.tagName || '').toLowerCase(),
                ind: o.getAttribute('ind') != null ? String(o.getAttribute('ind')) : null,
                correct: /correctq|correctanswer|is-correct|answer-correct|\bcorrect\b/i.test(String(o.className || '')),
                text: _pcText(o), cls: String(o.className || '').trim().slice(0, 60),
              })),
              scope: 'legacy',
            });
            n++;
          }
        } catch (_) {}
      }
    } catch (_) {}
    return hosts;
  }

  // ── postMessage to content.js ────────────────────────────
  function postToContent(payload) {
    try {
      if (!payload || typeof payload !== 'object') return;
      // SECURITY: giới hạn size trước khi post để không treo panel.
      if (secSize(payload) > SEC_INJ.MAX_MESSAGE_BYTES) {
        L.warn('postToContent: payload vượt giới hạn, bỏ qua:', payload.type);
        return;
      }
      // SECURITY: validate result size cho decode responses.
      if ((payload.type === 'OLM_PAGE_DECODE_RESULT') && typeof payload.result === 'string'
          && payload.result.length > SEC_INJ.MAX_RESULT_BYTES) {
        payload = { ...payload, result: null };
      }
      window.postMessage(
        { __olmBridge: true, token: BRIDGE_TOKEN, ...payload },
        location.origin || '*'
      );
    } catch (e) { L.err('postToContent failed:', e); }
  }

  // ── Rate limiter ─────────────────────────────────────────
  const SEND_QUEUE = [];
  let SEND_BUSY = false;
  let LAST_SEND = 0;
  const MIN_SEND_INTERVAL = 800;

  function enqueueSend(data) {
    // SECURITY: chặn queue phình bởi payload lạ; giới hạn 20 items chờ.
    if (SEND_QUEUE.length > 20) SEND_QUEUE.shift();
    SEND_QUEUE.push(data);
    if (!SEND_BUSY) drainQueue();
  }

  function drainQueue() {
    if (!SEND_QUEUE.length) { SEND_BUSY = false; return; }
    SEND_BUSY = true;
    const wait = Math.max(0, MIN_SEND_INTERVAL - (Date.now() - LAST_SEND));
    setTimeout(() => {
      const item = SEND_QUEUE.shift();
      if (item) { postToContent(item); LAST_SEND = Date.now(); }
      setTimeout(drainQueue, 0);
    }, wait);
  }

  // ── fetch interceptor ────────────────────────────────────
  // document_start → chạy TRƯỚC khi trang load bất kỳ JS nào → hook kịp trước Vue mount
  // QUAN TRỌNG: lưu reference vào biến closure để setInterval có thể so sánh
  const _originalFetch = window.fetch.bind(window);

  function _olmFetchImpl(origFn, ...args) {
    const requestUrl = args[0] instanceof Request ? args[0].url
      : (typeof args[0] === 'string' ? args[0] : String(args[0] || ''));
    const promise = origFn.apply(this, args);
    if (!requestUrl) return promise;
    promise.then(response => {
      if (!response || !response.ok) return;
      const process = (data) => {
        if (!isTrackedUrl(requestUrl)) learnEndpoint(requestUrl);
        // SECURITY: giới hạn payload API để 1 response bất thường không treo panel.
        // Không drop hẳn — cắt list còn 200 câu để giữ tính năng.
        try {
          if (secSize(data) > SEC_INJ.MAX_MESSAGE_BYTES) {
            if (data && Array.isArray(data.list)) data = { ...data, list: data.list.slice(0, 200) };
            else if (data && Array.isArray(data.data)) data = { ...data, data: data.data.slice(0, 200) };
            else if (data && Array.isArray(data.questions)) data = { ...data, questions: data.questions.slice(0, 200) };
            else if (data && Array.isArray(data.items)) data = { ...data, items: data.items.slice(0, 200) };
            else if (Array.isArray(data)) data = data.slice(0, 200);
            if (secSize(data) > SEC_INJ.MAX_MESSAGE_BYTES) { L.warn('API payload vượt giới hạn, bỏ qua'); return; }
          }
        } catch (_) {}
        enqueueSend({ type: 'OLM_API_DATA', payload: data });
        L.dbg('fetch intercepted:', requestUrl);
      };
      if (isTrackedUrl(requestUrl)) {
        response.clone().json().then(process).catch(() => {});
      } else {
        response.clone().json().then(data => {
          if (looksLikeQuestionList(data)) process(data);
        }).catch(() => {});
      }
    }).catch(() => {});
    return promise;
  }

  // Wrapper được lưu vào biến — có thể so sánh bằng === trong setInterval
  let _currentFetchHook = function(...args) {
    return _olmFetchImpl.call(this, _originalFetch, ...args);
  };
  window.fetch = _currentFetchHook;

  // ── XHR interceptor ──────────────────────────────────────
  const _origXHRSend = XMLHttpRequest.prototype.send;

  function _olmXHRImpl(...args) {
    this.addEventListener('load', function() {
      if (this.status !== 200) return;
      const url = this.responseURL || '';
      if (!url || !this.responseText) return;
      try {
        const data = JSON.parse(this.responseText);
        if (looksLikeQuestionList(data)) {
          if (!isTrackedUrl(url)) learnEndpoint(url);
          enqueueSend({ type: 'OLM_API_DATA', payload: data });
          L.dbg('XHR intercepted:', url);
        }
      } catch (_) {}
    });
    return _origXHRSend.apply(this, args);
  }

  let _currentXHRHook = _olmXHRImpl;
  XMLHttpRequest.prototype.send = _currentXHRHook;

  // ── Hook integrity check ──────────────────────────────────
  // So sánh với biến closure (_currentFetchHook / _currentXHRHook), không dùng function.name
  setInterval(() => {
    if (window.fetch !== _currentFetchHook) {
      L.warn('fetch hook replaced, re-hooking...');
      const prevFetch = window.fetch.bind(window);
      _currentFetchHook = function(...args) {
        return _olmFetchImpl.call(this, prevFetch, ...args);
      };
      window.fetch = _currentFetchHook;
    }
    if (XMLHttpRequest.prototype.send !== _currentXHRHook) {
      L.warn('XHR hook replaced, re-hooking...');
      const prevSend = XMLHttpRequest.prototype.send;
      _currentXHRHook = function(...args) {
        this.addEventListener('load', function() {
          if (this.status !== 200 || !this.responseText) return;
          try {
            const data = JSON.parse(this.responseText);
            const url = this.responseURL || '';
            if (looksLikeQuestionList(data)) {
              if (!isTrackedUrl(url)) learnEndpoint(url);
              enqueueSend({ type: 'OLM_API_DATA', payload: data });
            }
          } catch (_) {}
        });
        return prevSend.apply(this, args);
      };
      XMLHttpRequest.prototype.send = _currentXHRHook;
    }
  }, 5000);

  // ── SPA route change detection (cần main world cho history hook) ─
  const _wrapHistory = (method) => {
    const orig = history[method];
    history[method] = function(...args) {
      const result = orig.apply(this, args);
      window.dispatchEvent(new Event('olm-route-change'));
      return result;
    };
  };
  try { _wrapHistory('pushState'); _wrapHistory('replaceState'); } catch (_) {}
  window.addEventListener('popstate', () => window.dispatchEvent(new Event('olm-route-change')));
  window.addEventListener('olm-route-change', () => {
    L.log('Route change detected');
    postToContent({ type: 'OLM_ROUTE_CHANGE' });
  });

  // ── Anti-hide CSS ────────────────────────────────────────
  function injectAntiHideCSS() {
    if (document.getElementById('olm-anti-hide')) return;
    const s = document.createElement('style');
    s.id = 'olm-anti-hide';
    s.textContent = `[data-question-id] *, [data-id] *, [data-qid] * { visibility: visible !important; }`;
    (document.head || document.documentElement).appendChild(s);
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', injectAntiHideCSS, { once: true });
  } else {
    injectAntiHideCSS();
  }

  // ── Listen for requests FROM content.js ─────────────────
  // SECURITY (v1.3.5): validation layer — mọi message phải có type hợp lệ,
  // reqId hợp lệ (nếu là request/response), payload đúng schema + size limit.
  // Không chấp nhận message thiếu type / reqId tùy ý / payload cực lớn.
  window.addEventListener('message', (event) => {
    if (event.source !== window) return;
    const data = event.data;
    if (!data || typeof data !== 'object') return;
    try {
      if (event.origin && event.origin !== 'null' && event.origin !== location.origin) return;
    } catch (_) {}
    // SECURITY: giới hạn size message để không treo injected.
    if (secSize(data) > SEC_INJ.MAX_MESSAGE_BYTES) return;

    // Handle content.js broadcast announce (token chưa có ở bước này)
    if (data.__olmBridgeAnnounce && data.type === 'OLM_CONTENT_READY') {
      contentScriptReady = true;
      L.log('Content script announced ready (broadcast), sending OLM_INJECTED_READY...');
      // Reply với token để content.js thiết lập bridge
      postToContent({ type: 'OLM_INJECTED_READY', xorKey: OLM_XOR_KEY });
      return;
    }

    // Validated messages (sau khi bridge established)
    if (!data.__olmBridge) return;
    if (data.token !== BRIDGE_TOKEN) return;
    // SECURITY: type phải là string và nằm trong allowlist.
    if (typeof data.type !== 'string' || !SEC_ALLOWED_FROM_CONTENT.has(data.type)) return;

    const msg = data;
    switch (msg.type) {
      case 'OLM_CONTENT_READY':
        contentScriptReady = true;
        L.log('Content script is ready');
        // Gửi announce ready + XOR key về content.js
        postToContent({ type: 'OLM_INJECTED_READY', xorKey: OLM_XOR_KEY });
        break;

      case 'OLM_GET_GLOBALS':
        postToContent({
          type: 'OLM_GLOBALS',
          hasCateUI: typeof window.CATE_UI?.OlmEncode?.xorDecodeBase64 === 'function',
          hasLZString: typeof window.LZString !== 'undefined',
          xorKey: OLM_XOR_KEY,
        });
        break;

      case 'OLM_PAGE_DECODE': {
        // SECURITY: validate reqId + b64 schema + size trước khi decode.
        const reqId = msg.reqId;
        const b64 = msg.b64;
        if (typeof reqId !== 'string' || !/^dr_\d+$/.test(reqId)) break;
        if (typeof b64 !== 'string' || !b64 || b64.length > SEC_INJ.MAX_B64_BYTES) {
          postToContent({ type: 'OLM_PAGE_DECODE_RESULT', reqId: typeof reqId === 'string' ? reqId : 'dr_0', result: null });
          break;
        }
        try {
          const fn = getPageDecodeFn();
          let result = null;
          if (fn) { try { result = fn(b64); } catch (_) {} }
          if (!result) result = tryDecodeViaOlmRuntime(b64);
          if (typeof result === 'string' && result.length > SEC_INJ.MAX_RESULT_BYTES) result = null;
          if (result != null && typeof result !== 'string') result = null;
          postToContent({ type: 'OLM_PAGE_DECODE_RESULT', reqId, result });
        } catch (e) {
          postToContent({ type: 'OLM_PAGE_DECODE_RESULT', reqId, result: null });
        }
        break;
      }

      case 'OLM_DECODE_VUE': {
        // SECURITY: question chỉ cần {id}; validate id là digits.
        const q = msg.question;
        const qid = q && q.id != null ? String(q.id) : '';
        if (!qid || !/^\d+$/.test(qid)) break;
        try {
          let dd = extractDragDropFromVue({ id: qid });
          // SECURITY: validate + giới hạn result trước khi post.
          if (!Array.isArray(dd)) dd = [];
          if (dd.length > SEC_INJ.MAX_VUE_ITEMS) dd = dd.slice(0, SEC_INJ.MAX_VUE_ITEMS);
          const clean = [];
          for (const it of dd) {
            if (!it || typeof it !== 'object') continue;
            if (typeof it.answer !== 'string' || !it.answer.trim()) continue;
            if (it.answer.length > 5000) continue;
            clean.push({ slot: Number(it.slot) || (clean.length + 1), answer: it.answer.slice(0, 5000) });
            if (clean.length >= SEC_INJ.MAX_VUE_ITEMS) break;
          }
          postToContent({ type: 'OLM_VUE_RESULT', questionId: qid, result: clean });
        } catch (e) {
          postToContent({ type: 'OLM_VUE_RESULT', questionId: qid, result: [] });
        }
        break;
      }

      case 'OLM_RENDER_MATH':
        // Content.js yêu cầu trigger MathJax/KaTeX của trang trên element ID
        // Ta không thể pass DOM element qua postMessage → content.js tự xử lý
        break;

      case 'OLM_PAGE_CONTEXT': {
        // ĐÃ XÁC MINH (olm.vn 2026-10): UI mới của OLM render câu hỏi bằng
        // Lit web component <default-root> với shadowRoot MỞ. Thuộc tính
        // reactive của Lit (jsonQuestion, answerData, isShowCorrectAnswer...)
        // được gán dạng expando trên JS wrapper của MAIN world →
        // content script (ISOLATED world) KHÔNG đọc được, nên phải đọc ở đây.
        //
        // Trả về (chỉ dữ liệu thuần, không pass DOM node):
        //   hosts[]: { qid, kind, stem, options:[{ind, correct, text, tag}] }
        postToContent({ type: 'OLM_PAGE_CONTEXT_RESULT', reqId: typeof msg.reqId === 'string' ? msg.reqId : 'pc_0', hosts: readPageQuestionHosts() });
        break;
      }
    }
  });

  // ── Announce sẵn sàng (broadcast — content.js có thể chưa listen kịp) ────
  // Gửi ngay lần đầu và retry để đảm bảo content.js nhận được
  let announceAttempts = 0;
  function announceReady() {
    postToContent({ type: 'OLM_INJECTED_READY', xorKey: OLM_XOR_KEY });
    announceAttempts++;
    if (announceAttempts < 5 && !contentScriptReady) {
      setTimeout(announceReady, 200);
    }
  }
  // Gửi ngay sau khi DOM sẵn sàng một chút để content.js kịp setup listener
  setTimeout(announceReady, 50);

  L.log('injected.js runtime active (MAIN WORLD, document_start)');
})();
