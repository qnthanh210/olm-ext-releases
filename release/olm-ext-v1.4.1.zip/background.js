'use strict';

// Remote Config engine (local, data-only). Duoc import de Service Worker
// dang ky alarm + message handler. KHONG cham vao logic License phia duoi.
// He thong nay hoan toan doc lap voi License Manager: GitHub down khong
// anh huong license, va config tu xa khong bao gio lam license tro nen hop le.
import './remote-config/index.js';

const LOG = (...a) => console.log('[OLM-BG]', ...a);

const DEVICE_ID_KEY   = 'olm_device_id';
const LICENSE_KEY_KEY = 'license_key';
const STATUS_KEY      = 'license_status';
const VERIFIED_KEY    = 'license_verified_at';
const ALARM_NAME      = 'olm_license_recheck';
const RECHECK_MIN     = 10;                       // chu kỳ recheck (phút)
const GRACE_MS        = 6 * 60 * 60 * 1000;       // phải khớp LICENSE_OFFLINE_GRACE_MS ở content.js

// ── Device ID ─────────────────────────────────────────────────
async function ensureDeviceId() {
  const data = await chrome.storage.local.get(DEVICE_ID_KEY);
  if (!data[DEVICE_ID_KEY]) {
    const deviceId = crypto.randomUUID();
    await chrome.storage.local.set({ [DEVICE_ID_KEY]: deviceId });
    LOG('Device ID created:', deviceId);
    return deviceId;
  }
  return data[DEVICE_ID_KEY];
}

// ── Backend proxy call ────────────────────────────────────────
// SW chỉ gọi endpoint backend của bạn — không giữ Supabase key.
// Backend (Supabase Edge Function) mới giữ key thật và xử lý logic.
//
// CÁCH DEPLOY SUPABASE EDGE FUNCTION:
//   1. supabase functions new license-activate
//   2. Copy nội dung hàm (xem README) vào supabase/functions/license-activate/index.ts
//   3. supabase functions deploy license-activate --no-verify-jwt
//   4. Thay PROXY_URL bên dưới bằng URL function của bạn
//
// Edge Function nhận: { key, device_id }
// Edge Function trả:  { status: 'activated' | 'invalid_key' | ... }
// Supabase service_role key chỉ tồn tại trong Edge Function (server-side).
const PROXY_URL = 'https://xaylqpksbxiqoedhitgm.supabase.co/functions/v1/license-activate';

async function callLicenseProxy(key, deviceId) {
  const res = await fetch(PROXY_URL, {
    method:  'POST',
    headers: { 'Content-Type': 'application/json' },
    body:    JSON.stringify({ key, device_id: deviceId }),
  });
  if (!res.ok) throw new Error(`proxy ${res.status}`);
  return res.json();
}

// ── License activation ────────────────────────────────────────
async function activateLicense(rawKey) {
  const key = (rawKey || '').trim();
  if (!key) return { status: 'not_activated' };

  // FIX: sự kiện 'activate' chỉ chạy khi cài/cập nhật SW; nếu storage bị xoá thì
  // deviceId mất và license kẹt network_error vĩnh viễn → luôn đảm bảo có deviceId.
  const deviceId = await ensureDeviceId();
  if (!deviceId) return { status: 'network_error' };

  try {
    return await callLicenseProxy(key, deviceId);
  } catch (e) {
    LOG('activateLicense error:', e.message);
    return { status: 'network_error' };
  }
}

// ── Persist kết quả + recheck nền ─────────────────────────────
// SW có thể bị ngủ bất cứ lúc nào → KHÔNG giữ state trong biến; mọi thứ đọc/ghi qua
// chrome.storage. chrome.alarms đánh thức SW theo chu kỳ, kể cả khi không mở olm.vn.
// content.js lắng nghe chrome.storage.onChanged để cập nhật UI/gate.
async function persistLicenseResult(status) {
  if (!status) return;
  const cur = await chrome.storage.local.get([STATUS_KEY, VERIFIED_KEY]);
  const verifiedAt = Number(cur[VERIFIED_KEY]) || 0;
  const patch = {};
  if (status === 'activated') {
    patch[STATUS_KEY] = 'activated';
    patch[VERIFIED_KEY] = Date.now();
  } else if (status === 'network_error') {
    // Lỗi mạng: giữ nguyên trong thời gian chờ; quá hạn thì hạ trạng thái.
    const withinGrace = verifiedAt > 0 && (Date.now() - verifiedAt) <= GRACE_MS;
    if (cur[STATUS_KEY] === 'activated' && !withinGrace) patch[STATUS_KEY] = 'network_error';
  } else {
    patch[STATUS_KEY] = status;          // expired / invalid_key / device_limit_reached / ...
  }
  if (Object.keys(patch).length) await chrome.storage.local.set(patch);
}

async function backgroundRecheck() {
  const data = await chrome.storage.local.get(LICENSE_KEY_KEY);
  const key = (data[LICENSE_KEY_KEY] || '').trim();
  if (!key) return;                       // chưa có key → không cần gọi server
  const result = await activateLicense(key);
  // Trong lúc chờ server, user có thể đã xoá/đổi key → bỏ kết quả của key cũ,
  // nếu không sẽ ghi 'activated' lên một key không còn tồn tại.
  const after = await chrome.storage.local.get(LICENSE_KEY_KEY);
  if ((after[LICENSE_KEY_KEY] || '').trim() !== key) { LOG('Background recheck: key đã đổi/xoá, bỏ kết quả'); return; }
  await persistLicenseResult(result?.status);
  LOG('Background recheck:', result?.status);
}

async function ensureAlarm() {
  const existing = await chrome.alarms.get(ALARM_NAME);
  if (!existing) chrome.alarms.create(ALARM_NAME, { delayInMinutes: RECHECK_MIN, periodInMinutes: RECHECK_MIN });
}

// Listener PHẢI đăng ký đồng bộ ở top-level để SW vừa được đánh thức vẫn nhận được alarm.
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === ALARM_NAME) backgroundRecheck().catch(e => LOG('alarm recheck error:', e.message));
});
// Cài/cập nhật extension hoặc Chrome khởi động: kiểm tra NGAY (không chờ alarm đầu tiên).
function checkNow(reason) {
  ensureAlarm().catch(() => {});
  backgroundRecheck().catch(e => LOG('checkNow(' + reason + ') error:', e.message));
}
chrome.runtime.onInstalled.addListener(() => checkNow('installed'));
chrome.runtime.onStartup.addListener(() => checkNow('startup'));
// Alarm có thể mất sau khi trình duyệt khởi động lại / SW khởi động lại → đảm bảo luôn tồn tại.
ensureAlarm().catch(() => {});

// ── SW lifecycle ──────────────────────────────────────────────
self.addEventListener('install', () => {
  LOG('SW installed');
  self.skipWaiting();
});

self.addEventListener('activate', () => {
  LOG('SW activated');
  ensureDeviceId();
});

// ── Message handler ───────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || typeof msg !== 'object' || sender.id !== chrome.runtime.id) return false;
  if (msg.type === 'OLM_PING') {
    sendResponse({ ok: true });
    return false;
  }

  if (msg.type === 'OLM_LICENSE_ACTIVATE') {
    activateLicense(msg.key)
      .then(async result => {
        // Key mới vừa activate: đảm bảo alarm đang chạy + ghi kết quả vào storage ngay từ SW.
        try { await persistLicenseResult(result?.status); } catch (_) {}
        try { await ensureAlarm(); } catch (_) {}
        sendResponse(result);
      })
      .catch(e => sendResponse({ status: 'network_error', error: e.message }));
    return true;
  }

  return false;
});

LOG('Background SW ready');
