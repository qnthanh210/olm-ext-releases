// ============================================================
// OLM Panel — content.js (Isolated World)
// CHẠY TRONG ISOLATED WORLD — có DOM access nhưng window riêng
//
// Trách nhiệm:
//   1. Nhận data từ injected.js (main world) qua window.postMessage
//   2. Giải mã nội dung câu hỏi (XOR, gzip, LZString)
//   3. Trích xuất đáp án từ JSON tree / HTML / DOM
//   4. Render panel UI
//   5. Cache kết quả vào chrome.storage.local
// ============================================================
'use strict';

// ── Singleton guard ──────────────────────────────────────────
if (window.__OLM_CONTENT_RUNTIME__) {
  console.warn('[OLM-CS] Duplicate — aborting.');
  throw new Error('OLM already running');
}
window.__OLM_CONTENT_RUNTIME__ = true;

const L = {
  log:  (...a) => console.log('[OLM]', ...a),
  warn: (...a) => console.warn('[OLM]', ...a),
  err:  (...a) => console.error('[OLM]', ...a),
  dbg:  (...a) => false && console.debug('[OLM-DBG]', ...a),
};

// ============================================================
// DEBUG TRACE (opt-in, không ảnh hưởng production)
// Bật: window.__OLM_TRACE__ = true  (hoặc localStorage olm_trace=1)
// Tắt: window.__OLM_TRACE__ = false
//
// Mục đích: truy vết từng bước trích xuất answer để biết chính xác
// answer đến từ field/function nào (plain API, JSON tree, Vue, HTML…).
// Chi phí khi tắt: 1 biến boolean + 1 lần đọc localStorage.
// ============================================================
let __OLM_TRACE_ON__ = false;
try {
  __OLM_TRACE_ON__ = localStorage.getItem('olm_trace') === '1';
} catch (_) {}
// Cho phép bật runtime qua console mà không cần reload
try {
  Object.defineProperty(window, '__OLM_TRACE__', {
    get() { return __OLM_TRACE_ON__; },
    set(v) {
      __OLM_TRACE_ON__ = !!v;
      try { localStorage.setItem('olm_trace', v ? '1' : '0'); } catch (_) {}
      console.log('[OLM-TRACE]', v ? 'ON' : 'OFF');
    },
    configurable: true,
  });
} catch (_) {}

const TRACE = {
  on() { return __OLM_TRACE_ON__; },
  // trace(question, {source, field, raw, parser, sanitized, math, final})
  step(question, info) {
    if (!__OLM_TRACE_ON__) return;
    try {
      const qid = question && (question.id ?? question._id ?? question.question_id ?? '?');
      const qtype = (question && (question.type || question.question_type || '')) || '?';
      const lines = [];
      lines.push('──────── OLM-TRACE ────────');
      lines.push(`QID:  ${qid}`);
      lines.push(`TYPE: ${qtype}`);
      if (info.source != null) lines.push(`SOURCE: ${info.source}`);
      if (info.field != null)  lines.push(`FIELD:  ${info.field}`);
      if (info.raw != null)     lines.push(`RAW:    ${clip(info.raw)}`);
      if (info.parser != null)  lines.push(`PARSER: ${info.parser}`);
      if (info.sanitized != null) lines.push(`SANITIZED: ${clip(info.sanitized)}`);
      if (info.math != null)    lines.push(`MATHTEXT: ${clip(info.math)}`);
      if (info.final != null)   lines.push(`FINAL:  ${clip(info.final)}`);
      if (info.note != null)    lines.push(`NOTE:   ${info.note}`);
      lines.push('────────────────────────');
      console.log('[OLM-TRACE]', lines.join('\n'));
    } catch (e) { /* trace không được làm hỏng pipeline */ }
  },
};
function clip(v) {
  let s;
  try { s = Array.isArray(v) ? JSON.stringify(v) : String(v); } catch (_) { s = '[unserializable]'; }
  return s.length > 300 ? s.slice(0, 300) + `…(+${s.length - 300})` : s;
}

// ============================================================
// CONSTANTS
// ============================================================
const LS_CACHE_KEY    = 'olm_cache_v5';
const LS_SETTINGS_KEY = 'olm_settings_v5';

const DEFAULT_SETTINGS = {
  panelWidth: 25, panelHeight: 80, theme: 'purple',
  zoom: 100, nightMode: false, highlight: true,
  panelBackground: 'default', panelBgOpacity: 0.18, panelBgBlur: 0,
  highlightPageColor: '#39ff14', highlightPanelColor: '#39ff14',
  // Highlight 1 = phát sáng đáp án đúng trên trang olm.vn
  // Highlight 2 = tô sáng list đáp án trong panel
  highlightPage: true, highlightPanel: true,
};

const COLORS = {
  purple:{main:'#bf5fff',accent:'#d480ff',text:'#e8c8ff',bg:'#0d0a12'}, blue:{main:'#00bfff',accent:'#1e90ff',text:'#b0e0e6',bg:'#0a0f1a'}, green:{main:'#00ff7f',accent:'#32cd32',text:'#98ff98',bg:'#0a1a0a'}, red:{main:'#ff4444',accent:'#ff6666',text:'#ffcccc',bg:'#1a0a0a'}, cyan:{main:'#00ffff',accent:'#00eeee',text:'#b0ffff',bg:'#0a1515'}, pink:{main:'#ff69b4',accent:'#ff1493',text:'#ffb0d9',bg:'#1a0a10'}, orange:{main:'#ff9f1c',accent:'#ffbf69',text:'#ffe0b2',bg:'#1a1005'}, gold:{main:'#ffd166',accent:'#ffb703',text:'#fff0b3',bg:'#171207'}, yellow:{main:'#ffe600',accent:'#ffd000',text:'#fff7a8',bg:'#171505'}, lime:{main:'#a8ff00',accent:'#7fff00',text:'#e5ffb3',bg:'#101805'}, teal:{main:'#14f1d9',accent:'#00bfa6',text:'#b8fff6',bg:'#061613'}, indigo:{main:'#7c83ff',accent:'#9b5cff',text:'#d8d9ff',bg:'#0c0d1b'}, violet:{main:'#9b5cff',accent:'#d16bff',text:'#ead7ff',bg:'#11091b'}, rose:{main:'#ff5d8f',accent:'#ff8fab',text:'#ffd1dc',bg:'#1a0910'}, white:{main:'#f2f2f2',accent:'#ffffff',text:'#ffffff',bg:'#101010'},
};
const BUILTIN_BACKGROUNDS = { default:{label:'Nhân vật vàng',path:'assets/panel-bg.jpg'}, cherry:{label:'Hoa anh đào',path:'assets/panel-bg-cherry.jpg'}, cosmic:{label:'Địa cầu vũ trụ',path:'assets/panel-bg-cosmic.jpg'}, starry:{label:'Đêm sao',path:'assets/panel-bg-starry.jpg'}, warrior:{label:'Chiến thần',path:'assets/panel-bg-warrior.jpg'} };
const HIGHLIGHT_COLORS = { green:{label:'Xanh lá',hex:'#39ff14'}, cyan:{label:'Cyan',hex:'#00e5ff'}, blue:{label:'Xanh dương',hex:'#3d8bff'}, purple:{label:'Tím',hex:'#bf5fff'}, pink:{label:'Hồng',hex:'#ff4fa3'}, red:{label:'Đỏ',hex:'#ff4545'}, orange:{label:'Cam',hex:'#ff9f1c'}, gold:{label:'Vàng',hex:'#ffd166'}, lime:{label:'Lime',hex:'#a8ff00'}, white:{label:'Trắng',hex:'#ffffff'} };

// ============================================================
// LICENSE CONSTANTS
// ============================================================
const LM_STORAGE = {
  licenseKey:    'license_key',
  licenseStatus: 'license_status',
  deviceId:      'olm_device_id',
  verifiedAt:    'license_verified_at',   // thời điểm server xác nhận ACTIVATED lần cuối
};
// Offline/chặn server: chỉ được giữ ACTIVATED trong khoảng này kể từ lần server xác nhận cuối.
const LICENSE_OFFLINE_GRACE_MS = 6 * 60 * 60 * 1000;   // 6 giờ

const LICENSE_STATUS = {
  NOT_ACTIVATED:  'not_activated',
  ACTIVATED:      'activated',
  INVALID_KEY:    'invalid_key',
  EXPIRED:        'expired',
  DEVICE_LIMIT:   'device_limit_reached',
  NETWORK_ERROR:  'network_error',
};

const LICENSE_STATUS_TEXT = {
  not_activated:        'Not Activated',
  activated:            '✓ Activated',
  invalid_key:          '✗ Invalid Key',
  expired:              '✗ Key Expired',
  device_limit_reached: '✗ Device Limit Reached',
  network_error:        '⚠ Network Error',
};

// ============================================================
// RUNTIME STATE
// ============================================================
const RT = {
  settings: { ...DEFAULT_SETTINGS },
  cache: {},
  // Bridge
  bridgeToken: null,
  injectedReady: false,
  // Decode
  xorKey: '1047823200',
  pendingDecodes: new Map(),
  decodeReqCounter: 0,
  // UI state
  seenQids: new Set(),
  questionCounter: 0,
  isVisible: true,
  panelPos: { x: null, y: null },
  batchCount: 0,
  // Intervals/timers/observers (for cleanup)
  intervals: new Map(),
  observers: new Map(),
  timers: new Set(),
  // License state — đọc từ chrome.storage.local, không lưu biến tạm
  license: {
    key:      null,
    status:   'not_activated',
    deviceId: null,
  },
};

function safeTimeout(fn, ms) {
  const id = setTimeout(() => { RT.timers.delete(id); fn(); }, ms);
  RT.timers.add(id);
  return id;
}

// ============================================================
// SECURITY (v1.3.5) — HTML sanitizer + URL validation + bridge limits
// ------------------------------------------------------------
// Mọi HTML có nguồn gốc từ OLM API / decoded response / solution /
// question / answer / Vue data / DOM clone đều phải qua
// sanitizeHTML() trước khi đưa vào panel. Dùng ALLOWLIST,
// không dùng blacklist. Token postMessage chỉ là lớp filtering,
// bảo mật thực sự dựa vào schema + reqId + pending validation.
// ============================================================
const SEC_LIMITS = {
  MAX_HTML_BYTES: 500000,       // 500KB cho 1 đoạn HTML decoded
  MAX_MESSAGE_BYTES: 2000000,   // 2MB cho 1 postMessage JSON
  MAX_B64_BYTES: 500000,        // 500KB cho 1 base64 decode request
  MAX_DECODE_RESULT_BYTES: 1000000, // 1MB cho decode result
  MAX_API_ITEMS: 200,           // tối đa 200 câu / 1 message
  REQ_TIMEOUT_MS: 3000,         // pending request expiry khi check response
  SANITIZE_CACHE_MAX: 300,
};

const SEC_ALLOWED_TAGS = new Set([
  'div','span','p','br','strong','b','em','i','u','sub','sup',
  'ul','ol','li','table','thead','tbody','tr','th','td',
  'img','a','h1','h2','h3','h4','h5','h6',
  'blockquote','pre','code','hr','figure','figcaption',
]);

// Element nguy hiểm → xóa toàn bộ kèm nội dung (không unwrap)
const SEC_DROP_ENTIRELY = new Set([
  'script','style','iframe','object','embed','link','meta','base',
  'foreignobject','svg','math','canvas','video','audio','source','track',
  'form','input','button','select','textarea','option','optgroup',
  'fieldset','noscript','template','frame','frameset','applet','marquee',
]);

const SEC_GLOBAL_ATTRS = new Set(['class','title','alt','width','height','colspan','rowspan','data-plain']);
const SEC_URL_ATTRS = new Set(['src','href','srcset','cite','poster','data']);

function secApproxSize(v) {
  try {
    if (typeof v === 'string') return v.length;
    return JSON.stringify(v)?.length || 0;
  } catch (_) { return 0; }
}

// SECURITY: chỉ cho phép scheme cần thiết cho nội dung học tập.
// Cho phép: https:, http:, blob:, data:image/png|jpeg|gif|webp, URL tương đối.
// Chặn: javascript:, vbscript:, data:text/html, data:application/*, ...
function isSafeUrl(url) {
  if (url == null) return false;
  let u = String(url).trim();
  if (!u) return false;
  if (u.startsWith('#')) return true;
  // Loại bỏ control chars để chống bypass kiểu "java\0script:"
  u = u.replace(/[\u0000-\u0020]+/g, '');
  if (!u) return false;
  const m = /^([a-zA-Z][a-zA-Z0-9+.-]*):/.exec(u);
  if (!m) return true; // URL tương đối (/uploads/..., img/...) → cùng origin olm.vn
  const scheme = m[1].toLowerCase();
  if (scheme === 'http' || scheme === 'https' || scheme === 'blob') return true;
  if (scheme === 'data') {
    // Chỉ cho data:image hợp lệ, chặn data:text/html và data:application/*
    return /^data:image\/(png|jpeg|jpg|gif|webp);base64,/i.test(u)
        || /^data:image\/(png|jpeg|jpg|gif|webp),/i.test(u);
  }
  return false;
}

function isSafeSrcset(srcset) {
  if (srcset == null) return true;
  const s = String(srcset);
  if (!s.trim()) return true;
  // srcset: "url1 1x, url2 2x" — validate từng URL
  return s.split(',').every(part => {
    const url = part.trim().split(/\s+/)[0];
    return !url || isSafeUrl(url);
  });
}

function isSafeStyle(styleVal) {
  if (styleVal == null) return true;
  const s = String(styleVal).toLowerCase();
  // Chặn CSS có thể thực thi / exfiltrate
  if (s.includes('javascript:') || s.includes('vbscript:')) return false;
  if (s.includes('expression(') || s.includes('-moz-binding') || s.includes('behaviour')) return false;
  return true;
}

// SECURITY: sanitize 1 subtree đã nằm trong DOM (detached hoặc attached).
function sanitizeSubtree(root) {
  if (!root || !root.querySelectorAll) return root;
  const els = Array.from(root.querySelectorAll('*'));
  // Duyệt ngược để remove/unwrap an toàn
  for (let i = els.length - 1; i >= 0; i--) {
    const el = els[i];
    if (!el || !el.tagName) continue;
    const tag = el.tagName.toLowerCase();
    if (!SEC_ALLOWED_TAGS.has(tag)) {
      if (SEC_DROP_ENTIRELY.has(tag)) {
        try { el.remove(); } catch (_) {}
      } else {
        // Unwrap: giữ lại text/children, bỏ tag lạ (section, article, font...)
        try {
          const parent = el.parentNode;
          if (!parent) continue;
          while (el.firstChild) parent.insertBefore(el.firstChild, el);
          parent.removeChild(el);
        } catch (_) {}
      }
      continue;
    }
    // Tag được phép → lọc attributes
    const attrs = Array.from(el.attributes || []);
    for (const attr of attrs) {
      const name = (attr.name || '').toLowerCase();
      try {
        // Chặn toàn bộ event handler: onclick, onerror, onload, ...
        if (name.startsWith('on')) { el.removeAttribute(attr.name); continue; }
        if (SEC_URL_ATTRS.has(name)) {
          const val = el.getAttribute(attr.name);
          const ok = name === 'srcset' ? isSafeSrcset(val) : isSafeUrl(val);
          if (!ok) el.removeAttribute(attr.name);
          continue;
        }
        if (name === 'style') {
          if (!isSafeStyle(el.getAttribute('style'))) el.removeAttribute('style');
          continue;
        }
        if (name === 'href' && tag !== 'a') { el.removeAttribute(attr.name); continue; }
        if (name === 'src' && tag !== 'img') { el.removeAttribute(attr.name); continue; }
        // Chỉ giữ data-plain (math span của chính extension), bỏ data-* khác
        if (name.startsWith('data-') && name !== 'data-plain') { el.removeAttribute(attr.name); continue; }
        if (!SEC_GLOBAL_ATTRS.has(name)) {
          // href/src/srcset đã xử lý ở trên; còn lại chỉ giữ allowlist
          if (name !== 'href' && name !== 'src' && name !== 'srcset') el.removeAttribute(attr.name);
        }
      } catch (_) {}
    }
    // A với href không an toàn (đã bị strip ở trên) → giữ text
    if (tag === 'a' && !el.getAttribute('href')) {
      // Giữ thẻ a không href làm span thường — vẫn an toàn vì không có URL
    }
    // img không có src hợp lệ → bỏ để tránh broken image trigger
    if (tag === 'img') {
      const src = el.getAttribute('src');
      const srcset = el.getAttribute('srcset');
      if (src && !isSafeUrl(src)) { try { el.removeAttribute('src'); } catch (_) {} }
      if (srcset && !isSafeSrcset(srcset)) { try { el.removeAttribute('srcset'); } catch (_) {} }
    }
  }
  return root;
}

const _sanitizeCache = new Map();
// SECURITY: RAW HTML (untrusted, từ OLM) → SAFE HTML → mới được insert vào panel.
// Dùng cho mọi innerHTML có nguồn gốc OLM. Text thuần thì dùng textContent.
function sanitizeHTML(html, options) {
  if (html == null) return '';
  if (typeof html !== 'string') html = String(html);
  if (!html) return '';
  if (html.length > SEC_LIMITS.MAX_HTML_BYTES) {
    L.warn('sanitizeHTML: payload vượt giới hạn, bỏ qua (' + html.length + ' bytes)');
    return '';
  }
  if (_sanitizeCache.has(html)) return _sanitizeCache.get(html);
  let out = '';
  try {
    const tpl = document.createElement('template');
    // Parse trong <template> detached — script không thực thi
    tpl.innerHTML = html;
    sanitizeSubtree(tpl.content);
    // Lấy lại HTML đã sanitize. Template content fragment không có innerHTML
    // trên mọi trình duyệt cũ nên dùng wrapper div.
    const wrap = document.createElement('div');
    wrap.appendChild(tpl.content.cloneNode(true));
    out = wrap.innerHTML;
  } catch (e) {
    L.warn('sanitizeHTML failed:', e);
    out = '';
  }
  try {
    if (_sanitizeCache.size >= SEC_LIMITS.SANITIZE_CACHE_MAX) {
      _sanitizeCache.delete(_sanitizeCache.keys().next().value);
    }
    // Không cache HTML quá lớn để tránh memory bloat
    if (html.length < 100000) _sanitizeCache.set(html, out);
  } catch (_) {}
  return out;
}

// SECURITY: clone node từ OLM DOM / decoded HTML sang panel.
// Không coi DOM từ trang OLM là trusted: clone → sanitize subtree →
// xóa event handler → validate src/href → mới append.
function sanitizeClone(node) {
  if (!node) return null;
  try {
    const c = node.cloneNode(true);
    if (c.nodeType === 1) sanitizeSubtree(c);
    else if (c.querySelectorAll) sanitizeSubtree(c);
    return c;
  } catch (_) { return null; }
}

// SECURITY: helper insert HTML đã sanitize vào element (thay cho el.innerHTML = raw).
function setSafeInnerHTML(el, rawHtml) {
  if (!el) return;
  try { el.innerHTML = sanitizeHTML(rawHtml); }
  catch (_) { try { el.textContent = ''; } catch (_) {} }
}

// ============================================================
// LICENSE MANAGER
// Supabase calls được route qua background Service Worker.
// Content script KHÔNG giữ API key — chỉ gửi message đến SW.
// ============================================================
// ============================================================
// GLOBAL LICENSE GATE
// license_status === activated → mọi chức năng (kể cả Highlight) được phép.
// Khác activated → khoá toàn bộ: xoá Highlight, chặn tạo mới, dừng retry/async, hiện Gate.
// Mọi chức năng cần license PHẢI dùng isLicenseActive() (không tự so sánh status).
// ============================================================
function isLicenseActive() {
  if (RT.license.status !== LICENSE_STATUS.ACTIVATED) return false;
  // ACTIVATED chỉ có giá trị khi server đã xác nhận trong vòng grace. Hết grace mà chưa có xác nhận
  // mới → khoá ngay, ở MỌI điểm guard (không chờ recheck kế tiếp, không cần timer riêng).
  if (LM._withinGrace()) return true;
  LM._onGraceExpired();
  return false;
}

function handleLicenseLocked(reason = 'license_not_active') {
  // 1) Vô hiệu hoá mọi run()/step()/continuation đang chờ (generation) rồi xoá sạch Highlight + state.
  try {
    PageHL._generation = (PageHL._generation || 0) + 1;
    PageHL._running = false;
    PageHL.reset();            // clearTimeout + invalidateScope + items.clear() + clear() DOM
  } catch (e) {
    L.warn('PageHL.reset on license lock:', e);
    try { PageHL.clear(); } catch (_) {}
  }
  try { PageHL.invalidateScope?.(); } catch (_) {}

  // 2) Dữ liệu cũ không được tự render lại; cho phép render dữ liệu MỚI sau khi unlock.
  try { RT.seenQids.clear(); } catch (_) {}

  // 3) Panel → License Gate. Panel đang thu gọn: xoá nội dung cũ, gate hiện khi mở lại.
  try {
    if (Panel.isCollapsed) {
      if (Panel.contentArea) Panel.contentArea.innerHTML = '';
      Panel._gatePending = true;
    }
    Panel._hideLicenseGate?.();   // gỡ gate cũ để text phản ánh đúng status mới
    Panel._showLicenseGate?.();
  } catch (e) {
    L.warn('show license gate:', e);
  }

  L.log('LICENSE LOCK:', reason);
}

function handleLicenseUnlocked() {
  // Chỉ gỡ Gate. KHÔNG tự tô lại dữ liệu cũ (items đã bị xoá khi lock);
  // Highlight chạy lại khi có dữ liệu mới / render mới qua PageHL.offer().
  try {
    Panel._gatePending = false;
    Panel._hideLicenseGate?.();
    Panel._licenseGateShown = false;
  } catch (e) {
    L.warn('hide license gate:', e);
  }
  L.log('LICENSE UNLOCKED');
}

const LM = {
  async load() {
    try {
      const data = await chrome.storage.local.get([
        LM_STORAGE.licenseKey, LM_STORAGE.licenseStatus, LM_STORAGE.deviceId, LM_STORAGE.verifiedAt,
      ]);
      RT.license.key        = data[LM_STORAGE.licenseKey]    || null;
      RT.license.status     = data[LM_STORAGE.licenseStatus] || LICENSE_STATUS.NOT_ACTIVATED;
      RT.license.deviceId   = data[LM_STORAGE.deviceId]      || null;
      RT.license.verifiedAt = Number(data[LM_STORAGE.verifiedAt]) || 0;

      // Status 'activated' lưu local mà chưa/đã quá hạn xác nhận → không tin, chờ recheck.
      if (RT.license.status === LICENSE_STATUS.ACTIVATED && !this._withinGrace()) {
        this._onGraceExpired();   // NETWORK_ERROR (không giả mạo EXPIRED) + lock + recheck
      }

      const needsRecheck = RT.license.key && [
        LICENSE_STATUS.ACTIVATED,
        LICENSE_STATUS.EXPIRED,
        LICENSE_STATUS.NETWORK_ERROR,
      ].includes(RT.license.status);

      if (needsRecheck) safeTimeout(() => LM.recheck(), 2000);

      this._listenStorage();
    } catch (e) { L.err('LM.load:', e); }
  },

  // Recheck định kỳ do background SW (chrome.alarms) đảm nhiệm — cơ chế duy nhất, chạy cả khi
  // không mở olm.vn, ghi kết quả vào storage. Nhận thay đổi ở đây để UI/gate cập nhật ngay.
  _listenStorage() {
    if (this._storageBound) return;
    this._storageBound = true;
    try {
      chrome.storage.onChanged.addListener((changes, area) => {
        if (area !== 'local') return;
        let uiChanged = false;
        if (changes[LM_STORAGE.verifiedAt]) {
          RT.license.verifiedAt = Number(changes[LM_STORAGE.verifiedAt].newValue) || 0;
        }
        if (changes[LM_STORAGE.licenseKey]) {
          RT.license.key = changes[LM_STORAGE.licenseKey].newValue || null;
        }
        if (changes[LM_STORAGE.licenseStatus]) {
          const next = changes[LM_STORAGE.licenseStatus].newValue || LICENSE_STATUS.NOT_ACTIVATED;
          const prev = RT.license.status;
          if (next !== prev) {
            RT.license.status = next;
            uiChanged = true;
            // Non-active → xoá Highlight NGAY + Gate; chuyển về activated → chỉ unlock.
            if (next === LICENSE_STATUS.ACTIVATED) handleLicenseUnlocked();
            else handleLicenseLocked('storage:' + next);
          }
        }
        if (uiChanged) Panel._updateLicenseStatus?.(RT.license.status);
      });
    } catch (e) { L.err('LM storage listener:', e); }
  },

  _withinGrace() {
    return RT.license.verifiedAt > 0 && (Date.now() - RT.license.verifiedAt) <= LICENSE_OFFLINE_GRACE_MS;
  },

  // Đang ACTIVATED nhưng hết grace và chưa có xác nhận mới từ server → khoá nhất quán.
  // Trạng thái = NETWORK_ERROR (server CHƯA nói expired). Dùng lại handleLicenseLocked().
  // Đặt status TRƯỚC khi lock để isLicenseActive() không đệ quy.
  _onGraceExpired() {
    if (RT.license.status !== LICENSE_STATUS.ACTIVATED) return;
    RT.license.status = LICENSE_STATUS.NETWORK_ERROR;
    try { Panel._updateLicenseStatus?.(RT.license.status); } catch (_) {}
    handleLicenseLocked('grace_expired');
    // Hỏi lại server (qua background). ACTIVE → unlock; EXPIRED/INVALID/DEVICE_LIMIT → lock;
    // vẫn lỗi mạng → giữ khoá. Hoãn 1 tick để không chạy trong lúc đang ở trong một guard.
    if (RT.license.key) safeTimeout(() => LM.recheck(), 0);
  },

  // Verify lại với server; cập nhật UI/gate theo trạng thái SAU KHI áp dụng grace.
  async recheck() {
    if (!RT.license.key || this._rechecking) return;
    this._rechecking = true;
    try {
      L.log('License: recheck...');
      const prev = RT.license.status;
      await LM.activate(RT.license.key, true);
      const now = RT.license.status;          // trạng thái thực tế (đã qua grace)
      L.log('License: recheck result:', now);
      if (now !== prev) Panel._updateLicenseStatus?.(now);
      // Chỉ lock khi KẾT QUẢ CUỐI (sau grace) thật sự non-active; không clear lúc bắt đầu recheck.
      if (!isLicenseActive()) handleLicenseLocked('recheck:' + now);
      else handleLicenseUnlocked();
    } finally { this._rechecking = false; }
  },

  async save(key, status) {
    try {
      const p = {};
      const removeKeys = [];
      if (key !== undefined) {
        RT.license.key = key;
        if (key === null) {
          // Xoá key = reset toàn bộ state license. KHÔNG đụng device_id (định danh thiết bị).
          removeKeys.push(LM_STORAGE.licenseKey, LM_STORAGE.verifiedAt);
          RT.license.verifiedAt = 0;
        } else {
          p[LM_STORAGE.licenseKey] = key;
        }
      }
      if (status !== undefined) {
        const prevStatus = RT.license.status;
        // Lỗi mạng thoáng qua: giữ ACTIVATED nhưng CHỈ trong thời gian grace kể từ lần
        // server xác nhận cuối. Quá hạn (offline lâu / chặn supabase.co) → hạ xuống network_error.
        if (status === LICENSE_STATUS.NETWORK_ERROR
            && RT.license.status === LICENSE_STATUS.ACTIVATED && LM._withinGrace()) {
          // giữ nguyên
        } else {
          RT.license.status = status;
        }
        if (status === LICENSE_STATUS.ACTIVATED) {
          RT.license.verifiedAt = Date.now();
          p[LM_STORAGE.verifiedAt] = RT.license.verifiedAt;
        }
        // Chuyển trạng thái do chính content.js ghi (Activate / recheck) → lock/unlock NGAY,
        // vì storage.onChanged sẽ thấy next === RT.status và bỏ qua.
        if (prevStatus !== RT.license.status) {
          if (isLicenseActive()) handleLicenseUnlocked();
          else handleLicenseLocked('save:' + RT.license.status);
        }
        // Chỉ persist kết quả dứt khoát — network_error là tạm thời, không lưu
        // để lần sau boot sẽ recheck thay vì hiện "network error" cũ
        if (status !== LICENSE_STATUS.NETWORK_ERROR) {
          p[LM_STORAGE.licenseStatus] = status;
        }
      }
      if (Object.keys(p).length) await chrome.storage.local.set(p);
      if (removeKeys.length) await chrome.storage.local.remove(removeKeys);
    } catch (e) { L.err('LM.save:', e); }
  },

  async getDeviceId() {
    if (RT.license.deviceId) return RT.license.deviceId;
    try {
      const data = await chrome.storage.local.get(LM_STORAGE.deviceId);
      RT.license.deviceId = data[LM_STORAGE.deviceId] || null;
      return RT.license.deviceId;
    } catch (e) { return null; }
  },

  // Kích hoạt license — Supabase call được thực hiện bởi background SW
  // để API key không bao giờ xuất hiện trong content script.
  async activate(rawKey, isRecheck = false) {
    const key = (rawKey || '').trim();
    if (!key) {
      await this.save(null, LICENSE_STATUS.NOT_ACTIVATED);
      return LICENSE_STATUS.NOT_ACTIVATED;
    }
    try {
      const result = await chrome.runtime.sendMessage({
        type: 'OLM_LICENSE_ACTIVATE',
        key,
      });
      const status = result?.status || LICENSE_STATUS.NETWORK_ERROR;
      // Recheck chạy ngầm: nếu trong lúc chờ server mà user đã xoá/đổi key thì bỏ kết quả cũ.
      if (isRecheck && RT.license.key !== key) return RT.license.status;
      await this.save(key, status);
      return status;
    } catch (e) {
      L.err('LM.activate:', e);
      if (isRecheck && RT.license.key !== key) return RT.license.status;
      await this.save(key, LICENSE_STATUS.NETWORK_ERROR);
      return LICENSE_STATUS.NETWORK_ERROR;
    }
  },
};

// ============================================================
// CHROME STORAGE (async)
// ============================================================
function debounce(fn, ms) {
  let t = null;
  return function(...args) { clearTimeout(t); t = setTimeout(() => fn.apply(this, args), ms); };
}

// ============================================================
// REMOTE CONFIG (applier phía content script)
// ------------------------------------------------------------
// Nguyên tắc:
//   1. Config chỉ là DỮ LIỆU (selector / số / nhãn). TUYỆT ĐỐI không có JS,
//      không có HTML, không có CSS, không có URL.
//   2. Không bao giờ tin Service Worker một cách mù quáng: mọi giá trị nhận
//      về đều được validate LẠI tại đây (defense in depth) trước khi gán.
//   3. Chỉ áp dụng khi License đang ACTIVE → remote config không bao giờ
//      trở thành đường vòng bypass license.
//   4. Hỏng/thiếu → giữ nguyên giá trị hardcode của extension.
//   5. Gán xong phải xoá cache phụ thuộc selector để không dùng kết quả cũ.
// ============================================================
const RC = {
  enabled: false,
  applied: false,
  version: 'builtin',
  source: 'builtin',
  receivedAt: 0,
  features: null,
};

// Giới hạn lặp lại (mirror của LIMITS trong remote-config/schema.js).
const RC_LIMITS = {
  SELECTOR_LEN: 500,
  SELECTOR_LIST_LEN: 40000,
  PATTERN_LEN: 200,
  LABEL_LEN: 40,
  CHIPS: [8, 500],
  CYCLES: [1, 10],
};
const RC_SELECTOR_CHARS = /^[A-Za-z0-9_\-#.\[\]=\s>:~()'",>+*|^!\\%@$]+$/;
const RC_SELECTOR_BAD   = /(javascript\s*:|vbscript\s*:|data\s*:|expression\s*\(|url\s*\(|@import|-moz-binding|behaviou?r\s*:|\/\*|\*\/)/i;
// Tag không được chọn từ xa (khớp với remote-config/schema.js).
const RC_SELECTOR_BAD_TAG = /(^|[\s,>+~])(script|style|iframe|object|embed|link|meta|base|noscript|frame|frameset|applet|template)\b/i;
const RC_QTYPE_KEYS   = ['mc','tf','fill','match','order','essay','unknown'];
const RC_QTYPE_CLS    = /^[a-z0-9_-]{1,40}$/;

function rcAcceptSelector(sel) {
  if (typeof sel !== 'string') return null;
  const s = sel.trim();
  if (!s || s.length > RC_LIMITS.SELECTOR_LEN) return null;
  if (!RC_SELECTOR_CHARS.test(s) || RC_SELECTOR_BAD.test(s)) return null;
  if (RC_SELECTOR_BAD_TAG.test(s)) return null;
  // Thử biên dịch thật — selector sai cú pháp sẽ ném SyntaxError.
  try { document.querySelector(s); } catch (_) { return null; }
  return s;
}

function rcAcceptSelectorList(list) {
  if (typeof list !== 'string' || list.length > RC_LIMITS.SELECTOR_LIST_LEN) return null;
  const parts = list.split(',').map(s => s.trim()).filter(Boolean);
  if (!parts.length || parts.length > 240) return null;
  for (const p of parts) {
    if (p.length > RC_LIMITS.SELECTOR_LEN) return null;
    if (!RC_SELECTOR_CHARS.test(p) || RC_SELECTOR_BAD.test(p)) return null;
    if (RC_SELECTOR_BAD_TAG.test(p)) return null;
  }
  try { document.querySelector(parts.join(',')); } catch (_) { return null; }
  return parts.join(',');
}

function rcAcceptPattern(pat) {
  if (typeof pat !== 'string') return null;
  const s = pat.trim();
  if (!s || s.length > RC_LIMITS.PATTERN_LEN) return null;
  try { new RegExp(s); } catch (_) { return null; }
  return s;
}

function rcAcceptInt(v, [lo, hi]) {
  if (typeof v !== 'number' || !Number.isInteger(v) || v < lo || v > hi) return null;
  return v;
}

/**
 * Áp dụng config đã nhận. Từng trường được validate và gán ĐỘC LẬP —
 * một trường hỏng không được làm hỏng các trường còn lại.
 */
function applyRemoteConfig(payload) {
  if (!payload || typeof payload !== 'object') return false;
  const cfg = payload.config;
  if (!cfg || typeof cfg !== 'object') return false;

  RC.enabled = true;
  RC.version = String(cfg.configVersion || 'unknown');
  RC.source = String(payload.source || 'unknown');
  RC.receivedAt = Date.now();
  RC.features = (cfg.features && typeof cfg.features === 'object') ? cfg.features : null;

  const F = RC.features;
  // Feature flag tắt → bỏ qua nhóm tương ứng (nhưng vẫn giữ giá trị hardcode).
  const allow = (k) => !F || F[k] !== false;

  const sel = cfg.selectors;
  if (allow('answerDomSelectors') && sel && typeof sel === 'object') {
    const put = (key, target, isList) => {
      const v = isList ? rcAcceptSelectorList(sel[key]) : rcAcceptSelector(sel[key]);
      if (v !== null) target(v);
    };
    if (sel.quizHost !== undefined) put('quizHost', v => { QUIZ_HOST_SEL = v; });
    if (sel.mcOption !== undefined) put('mcOption', v => { MC_OPTION_SEL = v; });
    if (sel.tfRow !== undefined)    put('tfRow',    v => { TF_ROW_SEL = v; });
    if (sel.mcBlock !== undefined)  put('mcBlock',  v => { MC_BLOCK_SEL = v; });
    if (sel.tfBlock !== undefined)  put('tfBlock',  v => { TF_BLOCK_SEL = v; });
    if (sel.legacyBlock !== undefined) put('legacyBlock', v => { LEGACY_BLOCK_SEL = v; });
    if (sel.legacyRoot !== undefined)  put('legacyRoot',  v => { LEGACY_ROOT_SEL = v; });
    if (sel.legacyOption !== undefined) put('legacyOption', v => { LEGACY_OPTION_SEL = v; });
    if (sel.answerDom !== undefined)   put('answerDom',   v => { ANSWER_DOM_SELECTORS = v; }, true);
    if (sel.stripDisplay !== undefined) put('stripDisplay', v => { STRIP_DISPLAY_SEL = v; }, true);
    if (sel.quizHostFallbackPattern !== undefined) {
      const p = rcAcceptPattern(sel.quizHostFallbackPattern);
      if (p !== null) {
        try {
          const re = new RegExp(p, 'i');
          QUIZ_HOST_FALLBACK_PATTERN = p;
          QUIZ_HOST_FALLBACK_RE = re;
        } catch (_) { /* giữ regex cũ */ }
      }
    }
  }

  const mt = cfg.matching;
  if (allow('answerDomSelectors') && mt && typeof mt === 'object') {
    const chips = rcAcceptInt(mt.chipMaxText, RC_LIMITS.CHIPS);
    if (chips !== null) CHIP_MAX_TEXT = chips;
    const cyc = rcAcceptInt(mt.rearmCyclesMax, RC_LIMITS.CYCLES);
    if (cyc !== null) PageHL.maxRearmCycles = cyc;
    if (mt.tfListNamePattern !== undefined) {
      const p = rcAcceptPattern(mt.tfListNamePattern);
      if (p !== null) {
        try { TF_LIST_NAME_RE = new RegExp(p, 'i'); } catch (_) { /* giữ regex cũ */ }
      }
    }
  }

  const ui = cfg.ui;
  if (allow('panelUiLabels') && ui && ui.qtypeLabels && typeof ui.qtypeLabels === 'object') {
    const next = { ...QTYPE_LABEL };
    for (const k of RC_QTYPE_KEYS) {
      const v = ui.qtypeLabels[k];
      if (!v || typeof v !== 'object') continue;
      if (typeof v.text !== 'string' || !v.text || v.text.length > RC_LIMITS.LABEL_LEN) continue;
      if (typeof v.cls !== 'string' || !RC_QTYPE_CLS.test(v.cls)) continue;
      next[k] = { text: v.text, cls: v.cls };
    }
    QTYPE_LABEL = next;
  }

  // Selector đổi → cache cũ không còn đúng. Xoá trước khi highlight chạy lại.
  try { _olmBlockCache.clear(); } catch (_) {}
  try { _olmBlockMiss.clear(); } catch (_) {}
  try { invalidateQuizHostsCache(); } catch (_) {}
  try { PageHL.invalidateScope?.(); } catch (_) {}
  try { PageHL.clear(); } catch (_) {}

  RC.applied = true;
  L.log('Remote config applied:', RC.version, '[' + RC.source + ']');
  return true;
}

/**
 * Lấy config đang ACTIVE từ Service Worker. Không chặn khởi động:
 * panel/highlight dùng giá trị hardcode trước, config tới sau thì áp lại.
 */
async function loadRemoteConfigTunables() {
  try {
    // Gate license: config từ xa KHÔNG được dùng khi license không active.
    if (!isLicenseActive()) return false;
    const res = await chrome.runtime.sendMessage({ type: 'OLM_RC_GET' });
    if (!res || res.error) return false;
    if (res.source === 'builtin') return false;    // đang chạy bằng built-in rồi
    return applyRemoteConfig(res);
  } catch (e) {
    // Không có SW / SW chết → im lặng, giữ hardcode.
    return false;
  }
}

// PHIÊN BẢN SCHEMA CACHE — tăng mỗi khi logic trích đáp án thay đổi.
// Bắt buộc: cache lưu HTML đã render. Khi parser cải thiện (vd thêm dạng
// xếp câu "It||can||be||…"), cache cũ vẫn trả về kết quả tệ và KHÔNG bao giờ
// chạy lại parser → người dùng cứ thấy "// SOLUTION" dù code đã đúng.
// Mọi entry mang version khác bị loại ngay.

const CACHE_VER = '2';

const Store = {
  async loadAll() {
    return new Promise(resolve => {
      try {
        chrome.storage.local.get([LS_CACHE_KEY, LS_SETTINGS_KEY], result => {
          if (chrome.runtime.lastError) { resolve({}); return; }
          resolve(result || {});
        });
      } catch (e) { resolve({}); }
    });
  },
  saveSettings: debounce(function() {
    try {
      chrome.storage.local.set({ [LS_SETTINGS_KEY]: RT.settings });
    } catch (_) {}
  }, 400),
  saveCache: debounce(function() {
    const entries = Object.entries(RT.cache);
    if (entries.length > 500) {
      entries.sort((a, b) => (a[1].ts || 0) - (b[1].ts || 0));
      entries.slice(0, entries.length - 500).forEach(([k]) => delete RT.cache[k]);
    }
    try {
      chrome.storage.local.set({ [LS_CACHE_KEY]: RT.cache });
    } catch (_) {}
  }, 600),
  getCache(qid) {
    const e = RT.cache[String(qid)];
    if (!e) return null;
    // Cache cũ (không có version, hoặc version khác) → coi như không có,
    // buộc parser chạy lại từ đầu.
    if (!e.v || e.v !== CACHE_VER) {
      try { delete RT.cache[String(qid)]; } catch (_) {}
      return null;
    }
    return e.val || null;
  },
  setCache(qid, val) {
    try {
      // SECURITY: giới hạn cache để storage không bị phình bởi payload lạ.
      // Không crash extension khi payload vượt giới hạn — chỉ bỏ cache.
      if (val && typeof val.html === 'string' && val.html.length > 200000) return;
      RT.cache[String(qid)] = { val, ts: Date.now(), v: CACHE_VER };
      Store.saveCache();
    } catch (_) {}
  },
  clearCache() {
    RT.cache = {};
    try { chrome.storage.local.remove(LS_CACHE_KEY); } catch (_) {}
  },
};

// ============================================================
// LZ-STRING (bundled — không phụ thuộc trang hay CDN)
// ============================================================
const LZString = (() => {
  const keyStrBase64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';
  const baseReverseDic = {};
  function getBaseValue(alphabet, character) {
    if (!baseReverseDic[alphabet]) {
      baseReverseDic[alphabet] = {};
      for (let i = 0; i < alphabet.length; i++) baseReverseDic[alphabet][alphabet[i]] = i;
    }
    return baseReverseDic[alphabet][character];
  }
  function decompress(compressed, resetValue, getNextValue) {
    if (compressed == null) return '';
    if (compressed === '') return null;
    const dictionary = {};
    let next, enlargeIn = 4, dictSize = 4, numBits = 3, entry = '', result = [];
    let i, w, bits, resb, maxpower, power, c;
    let data = { val: getNextValue(compressed, 0), position: resetValue, index: 1 };
    for (let i = 0; i < 3; i++) dictionary[i] = i;
    bits = 0; maxpower = 4; power = 1;
    while (power != maxpower) {
      resb = data.val & data.position; data.position >>= 1;
      if (data.position == 0) { data.position = resetValue; data.val = getNextValue(compressed, data.index++); }
      bits |= (resb > 0 ? 1 : 0) * power; power <<= 1;
    }
    switch (next = bits) {
      case 0: bits = 0; maxpower = 256; power = 1;
        while (power != maxpower) { resb = data.val & data.position; data.position >>= 1; if (data.position == 0) { data.position = resetValue; data.val = getNextValue(compressed, data.index++); } bits |= (resb > 0 ? 1 : 0) * power; power <<= 1; }
        c = String.fromCharCode(bits); break;
      case 1: bits = 0; maxpower = 65536; power = 1;
        while (power != maxpower) { resb = data.val & data.position; data.position >>= 1; if (data.position == 0) { data.position = resetValue; data.val = getNextValue(compressed, data.index++); } bits |= (resb > 0 ? 1 : 0) * power; power <<= 1; }
        c = String.fromCharCode(bits); break;
      case 2: return '';
    }
    dictionary[3] = c; w = c; result.push(c);
    while (true) {
      if (data.index > compressed.length) return '';
      bits = 0; maxpower = Math.pow(2, numBits); power = 1;
      while (power != maxpower) { resb = data.val & data.position; data.position >>= 1; if (data.position == 0) { data.position = resetValue; data.val = getNextValue(compressed, data.index++); } bits |= (resb > 0 ? 1 : 0) * power; power <<= 1; }
      switch (c = bits) {
        case 0: bits = 0; maxpower = 256; power = 1;
          while (power != maxpower) { resb = data.val & data.position; data.position >>= 1; if (data.position == 0) { data.position = resetValue; data.val = getNextValue(compressed, data.index++); } bits |= (resb > 0 ? 1 : 0) * power; power <<= 1; }
          dictionary[dictSize++] = String.fromCharCode(bits); c = dictSize - 1; enlargeIn--; break;
        case 1: bits = 0; maxpower = 65536; power = 1;
          while (power != maxpower) { resb = data.val & data.position; data.position >>= 1; if (data.position == 0) { data.position = resetValue; data.val = getNextValue(compressed, data.index++); } bits |= (resb > 0 ? 1 : 0) * power; power <<= 1; }
          dictionary[dictSize++] = String.fromCharCode(bits); c = dictSize - 1; enlargeIn--; break;
        case 2: return result.join('');
      }
      if (enlargeIn == 0) { enlargeIn = Math.pow(2, numBits); numBits++; }
      if (dictionary[c]) { entry = dictionary[c]; } else { if (c === dictSize) { entry = w + w.charAt(0); } else { return null; } }
      result.push(entry);
      dictionary[dictSize++] = w + entry.charAt(0);
      enlargeIn--;
      if (enlargeIn == 0) { enlargeIn = Math.pow(2, numBits); numBits++; }
      w = entry;
    }
  }
  return {
    decompressFromBase64(input) {
      if (input == null) return ''; if (input === '') return null;
      return decompress(input, 32, (data, pos) => getBaseValue(keyStrBase64, data.charAt(pos)));
    },
    decompressFromEncodedURIComponent(input) {
      if (input == null) return '';
      return this.decompressFromBase64(input.replace(/ /g, '+'));
    },
  };
})();

// ============================================================
// POSTMESSAGE BRIDGE (content ↔ injected)
// SECURITY (v1.3.5): token chỉ là lớp filtering, không phải auth tuyệt đối.
// Bảo mật thực sự dựa vào: schema + type allowlist + reqId khớp pending +
// payload size limit + timeout + response chỉ xử lý 1 lần.
// ============================================================
const SEC_ALLOWED_BRIDGE_TYPES = new Set([
  'OLM_INJECTED_READY', 'OLM_CONTENT_READY', 'OLM_XOR_KEY', 'OLM_GLOBALS',
  'OLM_API_DATA', 'OLM_PAGE_DECODE', 'OLM_PAGE_DECODE_RESULT',
  'OLM_DECODE_VUE', 'OLM_VUE_RESULT', 'OLM_ROUTE_CHANGE',
  'OLM_PAGE_CONTEXT', 'OLM_PAGE_CONTEXT_RESULT',
]);

function postToInjected(payload) {
  if (!RT.bridgeToken) return;
  try {
    if (!payload || typeof payload !== 'object') return;
    if (!SEC_ALLOWED_BRIDGE_TYPES.has(payload.type)) return;
    // Giới hạn kích thước request trước khi post (tránh treo panel)
    if (secApproxSize(payload) > SEC_LIMITS.MAX_MESSAGE_BYTES) {
      L.warn('postToInjected: payload vượt giới hạn, bỏ qua:', payload.type);
      return;
    }
    window.postMessage(
      { __olmBridge: true, token: RT.bridgeToken, ...payload },
      location.origin || '*'
    );
  } catch (e) { L.err('postToInjected failed:', e); }
}

function setupBridge() {
  window.addEventListener('message', handleBridgeMessage);
  // Thông báo cho injected.js rằng content.js đã sẵn sàng nhận message
  // Gửi broadcast (token chưa có nên không dùng postToInjected)
  // Injected.js sẽ reply với OLM_INJECTED_READY kèm token
  const announce = () => {
    window.postMessage({ __olmBridgeAnnounce: true, type: 'OLM_CONTENT_READY' }, location.origin || '*');
  };
  announce();
  // Retry nếu injected.js chưa sẵn sàng
  safeTimeout(announce, 100);
  safeTimeout(announce, 300);
  safeTimeout(announce, 700);
}

function handleBridgeMessage(event) {
  // Từ trang gửi lên (main world → isolated)
  const data = event.data;
  // SECURITY: message phải tồn tại và là object
  if (!data || typeof data !== 'object') return;
  if (event.source !== window) return;
  // SECURITY: ưu tiên origin check khi có (MAIN world cùng origin)
  try {
    if (event.origin && event.origin !== 'null' && event.origin !== location.origin) return;
  } catch (_) {}

  // Xử lý announce từ injected.js (chưa có token)
  if (data.__olmBridge && data.type === 'OLM_INJECTED_READY') {
    // SECURITY: validate token là string không rỗng, giới hạn độ dài
    if (typeof data.token !== 'string' || !data.token || data.token.length > 200) return;
    if (!RT.bridgeToken) {
      RT.bridgeToken = data.token;
      L.log('Bridge established. Token:', data.token?.slice(0, 12) + '...');
    } else if (data.token !== RT.bridgeToken) {
      return; // token lạ sau khi bridge established → ignore
    }
    RT.injectedReady = true;
    // SECURITY: validate xorKey schema (digits 6-14)
    if (data.xorKey != null) {
      if (typeof data.xorKey === 'string' && /^\d{6,14}$/.test(data.xorKey)) RT.xorKey = data.xorKey;
    }
    // Báo lại cho injected.js biết content.js đã nhận
    postToInjected({ type: 'OLM_CONTENT_READY' });
    return;
  }

  // Broadcast announce từ injected.js (khi injected.js gửi OLM_CONTENT_READY)
  if (data.__olmBridgeAnnounce && data.type === 'OLM_CONTENT_READY') {
    // injected.js nhận OLM_CONTENT_READY từ content.js → reply với OLM_INJECTED_READY
    // (handler ở injected.js)
    return;
  }

  // Message có token → validate
  if (!data.__olmBridge) return;
  if (!RT.bridgeToken || data.token !== RT.bridgeToken) return;
  // SECURITY: không chấp nhận message thiếu type / type lạ
  if (typeof data.type !== 'string' || !SEC_ALLOWED_BRIDGE_TYPES.has(data.type)) return;
  // SECURITY: giới hạn kích thước message JSON để 1 message bất thường
  // không làm treo panel
  if (secApproxSize(data) > SEC_LIMITS.MAX_MESSAGE_BYTES) {
    L.warn('Bridge: message vượt giới hạn, bỏ qua:', data.type);
    return;
  }

  switch (data.type) {
    case 'OLM_XOR_KEY':
      // SECURITY: validate schema key
      if (typeof data.key === 'string' && /^\d{6,14}$/.test(data.key)) {
        RT.xorKey = data.key;
        L.log('XOR key updated:', data.key);
      }
      break;

    case 'OLM_GLOBALS':
      L.log('Page globals:', data);
      break;

    case 'OLM_API_DATA': {
      // SECURITY: validate payload là object, giới hạn số câu
      const p = data.payload;
      if (!p || typeof p !== 'object') break;
      let list = Array.isArray(p) ? p : (p.list || p.data || p.questions || p.items);
      const n = Array.isArray(list) ? list.length : (Array.isArray(p) ? p.length : 0);
      if (Array.isArray(list) && list.length > SEC_LIMITS.MAX_API_ITEMS) {
        L.warn('Bridge: API payload quá lớn (' + list.length + ' items), cắt còn ' + SEC_LIMITS.MAX_API_ITEMS);
        // Cắt thay vì drop hẳn để không mất tính năng với đề lớn
        if (Array.isArray(p)) data.payload = p.slice(0, SEC_LIMITS.MAX_API_ITEMS);
        else if (Array.isArray(p.list)) data.payload = { ...p, list: p.list.slice(0, SEC_LIMITS.MAX_API_ITEMS) };
        else if (Array.isArray(p.data)) data.payload = { ...p, data: p.data.slice(0, SEC_LIMITS.MAX_API_ITEMS) };
        else if (Array.isArray(p.questions)) data.payload = { ...p, questions: p.questions.slice(0, SEC_LIMITS.MAX_API_ITEMS) };
        else if (Array.isArray(p.items)) data.payload = { ...p, items: p.items.slice(0, SEC_LIMITS.MAX_API_ITEMS) };
      }
      L.log('API data received, items:', n);
      const snapshot = data.payload;
      RateLimiter.push(() => Panel.renderData(snapshot));
      break;
    }

    case 'OLM_PAGE_DECODE_RESULT': {
      // SECURITY: Only accept responses matching an active pending request.
      // reqId phải là string hợp lệ, tồn tại trong pending, chưa timeout,
      // response chỉ xử lý 1 lần (delete ngay trước resolve).
      if (typeof data.reqId !== 'string' || !/^dr_\d+$/.test(data.reqId)) break;
      const entry = RT.pendingDecodes.get(data.reqId);
      if (!entry) break; // response cho request không tồn tại / đã xử lý → ignore
      if (Date.now() - entry.createdAt > SEC_LIMITS.REQ_TIMEOUT_MS) {
        // Request quá hạn → ignore response, cleanup
        try { clearTimeout(entry.timeoutId); } catch (_) {}
        RT.pendingDecodes.delete(data.reqId);
        break;
      }
      // SECURITY: validate result schema + size
      let result = data.result;
      if (result != null && typeof result !== 'string') break;
      if (typeof result === 'string' && result.length > SEC_LIMITS.MAX_DECODE_RESULT_BYTES) {
        L.warn('Bridge: decode result vượt giới hạn, bỏ qua');
        try { clearTimeout(entry.timeoutId); } catch (_) {}
        RT.pendingDecodes.delete(data.reqId);
        entry.resolve(null);
        break;
      }
      RT.pendingDecodes.delete(data.reqId);
      try { clearTimeout(entry.timeoutId); } catch (_) {}
      entry.resolve(result);
      break;
    }

    case 'OLM_VUE_RESULT': {
      // SECURITY: questionId phải khớp pending 'vue_<id>', payload là array giới hạn
      if (data.questionId == null) break;
      const qidStr = String(data.questionId);
      if (!/^\d+$/.test(qidStr)) break;
      const key = 'vue_' + qidStr;
      const entry = RT.pendingDecodes.get(key);
      if (!entry) break;
      if (Date.now() - entry.createdAt > SEC_LIMITS.REQ_TIMEOUT_MS) {
        try { clearTimeout(entry.timeoutId); } catch (_) {}
        RT.pendingDecodes.delete(key);
        break;
      }
      let result = data.result;
      if (!Array.isArray(result)) break;
      if (result.length > 100) result = result.slice(0, 100);
      // Validate từng item {slot, answer}
      const clean = [];
      for (const it of result) {
        if (!it || typeof it !== 'object') continue;
        const ans = it.answer;
        if (typeof ans !== 'string' || !ans.trim()) continue;
        if (ans.length > 5000) continue;
        clean.push({ slot: Number(it.slot) || (clean.length + 1), answer: ans.slice(0, 5000) });
        if (clean.length >= 100) break;
      }
      RT.pendingDecodes.delete(key);
      try { clearTimeout(entry.timeoutId); } catch (_) {}
      entry.resolve(clean);
      break;
    }

    case 'OLM_ROUTE_CHANGE':
      L.log('SPA route change detected');
      safeTimeout(() => Healer.verifyRoot(), 400);
      safeTimeout(() => Healer.verifyRoot(), 1500);
      // Highlight 1 (trang): đổi trang → bỏ dấu cũ, scope cache cũng phải
      // bị bỏ vì câu đang hiển thị đã đổi hoàn toàn.
      if (RT.settings.highlightPage) {
        PageHL.clear();
        PageHL.items.forEach(it => { it.done = false; it.tries = 0; it.els = []; it._cycles = 0; it._rearmAt = 0; });
        PageHL.invalidateScope();
        PageHL.schedule(200);
      }
      break;

    case 'OLM_PAGE_CONTEXT_RESULT': {
      // SECURITY: reqId phải khớp 1 pending request (pc_<n>), timeout + 1 lần.
      if (typeof data.reqId !== 'string' || !/^pc_\d+$/.test(data.reqId)) break;
      const entry = RT.pendingDecodes.get(data.reqId);
      if (!entry) break;
      RT.pendingDecodes.delete(data.reqId);
      try { clearTimeout(entry.timeoutId); } catch (_) {}
      const hosts = Array.isArray(data.hosts) ? data.hosts : [];
      // SECURITY: validate schema + cap số host/option (payload do trang kiểm soát)
      const clean = [];
      for (const h of hosts.slice(0, 8)) {
        if (!h || typeof h !== 'object') continue;
        const qid = h.qid == null ? '' : String(h.qid);
        const opts = Array.isArray(h.options) ? h.options.slice(0, 60) : [];
        const oClean = [];
        for (const o of opts) {
          if (!o || typeof o !== 'object') continue;
          const t = typeof o.text === 'string' ? o.text.slice(0, 300) : '';
          oClean.push({
            tag: String(o.tag || 'div').slice(0, 12).toLowerCase(),
            ind: o.ind == null ? null : String(o.ind).slice(0, 8),
            correct: !!o.correct,
            text: t,
            cls: String(o.cls || '').slice(0, 80),
          });
        }
        clean.push({
          qid: qid.slice(0, 40),
          kind: String(h.kind || '').slice(0, 12),
          scope: String(h.scope || '').slice(0, 12),
          stem: typeof h.stem === 'string' ? h.stem.slice(0, 300) : '',
          options: oClean,
        });
      }
      entry.resolve(clean);
      break;
    }
  }
}

// ── Đọc identity của câu hỏi ĐANG HIỂN THỊ qua bridge ────────────
// Lý do: <default-root> là Lit component, jsonQuestion.id là **expando của
// MAIN world** → isolated world không đọc được. injected.js đọc hộ rồi trả về.
// Cache ngắn (mặc định 400ms) để 1 pass highlight chỉ gọi 1 lần cho mọi câu.
let _pageCtxCache = { t: 0, hosts: null };
function pageContextAsync(maxAgeMs) {
  const ttl = maxAgeMs == null ? 400 : maxAgeMs;
  if (_pageCtxCache.hosts && Date.now() - _pageCtxCache.t < ttl) return Promise.resolve(_pageCtxCache.hosts);
  return new Promise(resolve => {
    if (!RT.bridgeToken || !RT.injectedReady) { resolve(null); return; }
    const reqId = 'pc_' + (++RT.decodeReqCounter);
    const timeoutId = setTimeout(() => {
      if (RT.pendingDecodes.has(reqId)) { RT.pendingDecodes.delete(reqId); resolve(null); }
    }, 500);
    const dup = RT.pendingDecodes.get(reqId);
    if (dup) { try { clearTimeout(dup.timeoutId); } catch (_) {} RT.pendingDecodes.delete(reqId); }
    RT.pendingDecodes.set(reqId, { resolve, createdAt: Date.now(), timeoutId });
    postToInjected({ type: 'OLM_PAGE_CONTEXT', reqId });
  }).then(hosts => {
    if (hosts && hosts.length) { _pageCtxCache = { t: Date.now(), hosts }; }
    return hosts;
  });
}

// ============================================================
// RATE LIMITER
// ============================================================
const RateLimiter = {
  queue: [], busy: false, last: 0, minInterval: 0,
  push(fn) { this.queue.push(fn); if (!this.busy) this._next(); },
  _next() {
    if (!this.queue.length) { this.busy = false; return; }
    this.busy = true;
    // minInterval = 0 → render ngay, không throttle
    // Skeleton pattern đã đảm bảo UI không bị block
    const wait = Math.max(0, this.minInterval - (Date.now() - this.last));
    setTimeout(async () => {
      const fn = this.queue.shift();
      if (fn) { try { await fn(); } catch (e) { L.err('RateLimiter:', e); } this.last = Date.now(); }
      setTimeout(() => this._next(), 0);
    }, wait);
  },
};

// ============================================================
// DECODE PIPELINE (isolated world — không có CATE_UI trực tiếp)
// ============================================================
function normalizeBase64(s) {
  if (s == null || typeof s !== 'string') return '';
  let t = s.trim().replace(/\s/g, '');
  t = t.replace(/-/g, '+').replace(/_/g, '/');
  const pad = t.length % 4;
  if (pad) t += '='.repeat(4 - pad);
  return t;
}

function isGarbageText(str) {
  if (str == null || str === '') return true;
  const bad = (str.match(/\uFFFD/g) || []).length;
  if (str.length > 0 && bad / str.length > 0.02) return true;
  if (str.length > 40 && !str.includes('<') && /[\u0000-\u0008\u000b\u000c\u000e-\u001f]/.test(str)) return true;
  return false;
}

function looksLikeHtml(s) { return typeof s === 'string' && /^\s*</.test(s); }

function isOlmPackedPayload(bytes) {
  if (!bytes || bytes.length < 4) return false;
  if (bytes[0] === 0x0d && bytes[1] === 0x40 && bytes[2] === 0x0a) return true;
  let ctrl = 0;
  const n = Math.min(80, bytes.length);
  for (let i = 0; i < n; i++) { const b = bytes[i]; if (b < 32 && b !== 9 && b !== 10 && b !== 13) ctrl++; }
  return ctrl > n * 0.25;
}

function olmXorDecodeBase64(b64, key) {
  key = key || RT.xorKey;
  if (!b64) return null;
  const normalized = normalizeBase64(b64);
  if (!normalized || !/^[A-Za-z0-9+/=]+$/.test(normalized)) return null;
  try {
    const raw = atob(normalized);
    const kl = key.length;
    const xored = new Uint8Array(raw.length);
    for (let i = 0; i < raw.length; i++) xored[i] = raw.charCodeAt(i) ^ key.charCodeAt(i % kl);
    try { return new TextDecoder('utf-8', { fatal: true }).decode(xored); }
    catch (_) { return new TextDecoder('iso-8859-1').decode(xored); }
  } catch (_) { return null; }
}

// Yêu cầu injected.js decode qua CATE_UI/OlmRuntime
// SECURITY: reqId khớp pending, timeout cleanup, response 1 lần, giới hạn size.
function pageDecodeAsync(b64) {
  return new Promise(resolve => {
    if (!RT.bridgeToken || !RT.injectedReady) { resolve(null); return; }
    if (typeof b64 !== 'string' || !b64 || b64.length > SEC_LIMITS.MAX_B64_BYTES) { resolve(null); return; }
    const reqId = 'dr_' + (++RT.decodeReqCounter);
    const createdAt = Date.now();
    const timeoutId = setTimeout(() => {
      if (RT.pendingDecodes.has(reqId)) { RT.pendingDecodes.delete(reqId); resolve(null); }
    }, 600); // 600ms — đủ cho 1 roundtrip postMessage
    // Tận dụng Map hiện tại, lưu thêm metadata để validate response
    RT.pendingDecodes.set(reqId, { resolve, createdAt, timeoutId });
    // Chống memory leak: giới hạn pending
    if (RT.pendingDecodes.size > 50) {
      const first = RT.pendingDecodes.keys().next().value;
      const old = RT.pendingDecodes.get(first);
      try { clearTimeout(old?.timeoutId); } catch (_) {}
      RT.pendingDecodes.delete(first);
      try { old?.resolve(first.startsWith('vue_') ? [] : null); } catch (_) {} // FIX: không để promise treo vĩnh viễn
    }
    postToInjected({ type: 'OLM_PAGE_DECODE', b64, reqId });
  });
}

// Yêu cầu injected.js trích xuất Vue drag-drop
// SECURITY: chỉ gửi id tối thiểu (injected chỉ cần question.id), validate size.
function vueDecodeAsync(question) {
  return new Promise(resolve => {
    if (!RT.bridgeToken || !RT.injectedReady) { resolve([]); return; }
    const qid = question && question.id != null ? String(question.id) : '';
    if (!qid || !/^\d+$/.test(qid)) { resolve([]); return; }
    const key = 'vue_' + qid;
    // FIX: request trùng key → resolve request cũ trước khi ghi đè (tránh treo + timeout xoá nhầm entry mới)
    const dup = RT.pendingDecodes.get(key);
    if (dup) {
      try { clearTimeout(dup.timeoutId); } catch (_) {}
      RT.pendingDecodes.delete(key);
      try { dup.resolve([]); } catch (_) {}
    }
    const createdAt = Date.now();
    const timeoutId = setTimeout(() => {
      if (RT.pendingDecodes.get(key)?.timeoutId === timeoutId) { RT.pendingDecodes.delete(key); resolve([]); }
    }, 400);
    RT.pendingDecodes.set(key, { resolve, createdAt, timeoutId });
    if (RT.pendingDecodes.size > 50) {
      const first = RT.pendingDecodes.keys().next().value;
      const old = RT.pendingDecodes.get(first);
      try { clearTimeout(old?.timeoutId); } catch (_) {}
      RT.pendingDecodes.delete(first);
      try { old?.resolve(first.startsWith('vue_') ? [] : null); } catch (_) {}
    }
    // Chỉ gửi id, không gửi toàn bộ question object (giảm payload + lộ dữ liệu)
    postToInjected({ type: 'OLM_DECODE_VUE', question: { id: qid } });
  });
}

function sleep(ms) { return new Promise(r => safeTimeout(r, ms)); }

// Cache decode results — tránh decode cùng content 2 lần
const _decodeCache = new Map();
const _DECODE_CACHE_MAX = 300;

async function decodeQuestionContent(raw) {
  if (raw == null) return '';
  const s = typeof raw === 'string' ? raw : String(raw);
  // SECURITY: giới hạn kích thước input để 1 payload bất thường không treo panel.
  if (s.length > SEC_LIMITS.MAX_DECODE_RESULT_BYTES) {
    L.warn('decodeQuestionContent: input vượt giới hạn, bỏ qua (' + s.length + ')');
    return '';
  }
  const trimmed = s.trim();
  if (!trimmed) return '';
  if (looksLikeHtml(trimmed)) {
    // HTML từ API vẫn phải qua sanitize ở tầng render — trả về nguyên để
    // extractor đọc, render layer sẽ sanitize trước khi mount.
    if (trimmed.length > SEC_LIMITS.MAX_HTML_BYTES) return '';
    return trimmed;
  }

  // Cache hit — tránh decode lại cùng content
  if (_decodeCache.has(trimmed)) return _decodeCache.get(trimmed);

  function cacheReturn(val) {
    if (_decodeCache.size >= _DECODE_CACHE_MAX) {
      // Xóa entry đầu tiên (oldest)
      _decodeCache.delete(_decodeCache.keys().next().value);
    }
    _decodeCache.set(trimmed, val);
    return val;
  }

  const b64 = normalizeBase64(trimmed);
  if (!b64 || !/^[A-Za-z0-9+/=]+$/.test(b64)) return cacheReturn(trimmed);

  // 1. XOR local — nhanh nhất, không cần bridge
  const xorResult = olmXorDecodeBase64(b64);
  if (xorResult && !isGarbageText(xorResult) &&
      (xorResult.includes('<') || xorResult.trim().startsWith('{') || xorResult.length > 30)) {
    return cacheReturn(xorResult);
  }

  // Decode bytes 1 lần duy nhất cho các bước sau
  let bytes;
  try {
    const bs = atob(b64);
    bytes = new Uint8Array(bs.length);
    for (let i = 0; i < bs.length; i++) bytes[i] = bs.charCodeAt(i);
  } catch (_) { return cacheReturn(trimmed); }

  // 2. Gzip
  if (bytes.length >= 2 && bytes[0] === 0x1f && bytes[1] === 0x8b && typeof DecompressionStream !== 'undefined') {
    try {
      const blob = new Blob([bytes]);
      const ds = new DecompressionStream('gzip');
      const out = await new Response(blob.stream().pipeThrough(ds)).arrayBuffer();
      return cacheReturn(new TextDecoder('utf-8').decode(out));
    } catch (_) {}
  }

  // 3. LZString
  try {
    const lz = LZString.decompressFromBase64(b64) || LZString.decompressFromEncodedURIComponent(trimmed);
    if (lz && !isGarbageText(lz) && (looksLikeHtml(lz) || lz.length > 40)) return cacheReturn(lz);
  } catch (_) {}

  // 4. Page decode qua bridge — chỉ khi bridgeToken sẵn sàng
  if (RT.injectedReady) {
    const r = await pageDecodeAsync(b64);
    if (r && !isGarbageText(r) && (r.includes('<') || r.trim().startsWith('{') || r.length > 20)) {
      return cacheReturn(r);
    }
  }

  // 5. Plain UTF-8
  try {
    const utf8 = new TextDecoder('utf-8', { fatal: false }).decode(bytes);
    if (!isGarbageText(utf8)) return cacheReturn(utf8);
  } catch (_) {}

  return cacheReturn(trimmed);
}
// Decode sync (dùng trong scheduleDomEnrich không async)
function decodeSync(b64) {
  if (!b64) return '';
  // Reuse cache từ decodeQuestionContent
  if (_decodeCache.has(b64)) return _decodeCache.get(b64);
  const b = normalizeBase64(b64);
  if (!b) return '';
  const xor = olmXorDecodeBase64(b);
  if (xor && !isGarbageText(xor) && (xor.includes('<') || xor.trim().startsWith('{') || xor.length > 30)) {
    _decodeCache.set(b64, xor); return xor;
  }
  try {
    const bs = atob(b); const arr = new Uint8Array(bs.length);
    for (let i = 0; i < bs.length; i++) arr[i] = bs.charCodeAt(i);
    const r = new TextDecoder('utf-8', { fatal: false }).decode(arr);
    if (!isGarbageText(r)) { _decodeCache.set(b64, r); return r; }
  } catch (_) {}
  try { const lz = LZString.decompressFromBase64(b); if (lz && !isGarbageText(lz)) { _decodeCache.set(b64, lz); return lz; } } catch (_) {}
  return '';
}

// ============================================================
// MATH & TEXT UTILITIES
// ============================================================
const SUB = ['₀','₁','₂','₃','₄','₅','₆','₇','₈','₉'];
const SUP = ['⁰','¹','²','³','⁴','⁵','⁶','⁷','⁸','⁹'];

// ── Bảng ký hiệu LaTeX → Unicode ──────────────────────────────────
// Dùng cho latexToHtml (render). latexToPlain() dùng bảng này để sinh
// text thuần → data-plain KHỚP ĐÚNG với những gì KaTeX hiển thị trên trang.
// (Trước đây renderLatexSegment() và latexToHtml() là 2 bộ quy tắc khác nhau
//  → data-plain lệch với text render, khiến Highlight 1 không khớp.)
const LATEX_SYM = {
  cdot:'·', times:'×', div:'÷', pm:'±', mp:'∓', ast:'∗', star:'⋆', bullet:'•',
  leq:'≤', le:'≤', geq:'≥', ge:'≥', neq:'≠', ne:'≠', approx:'≈', equiv:'≡',
  sim:'∼', propto:'∝', ll:'≪', gg:'≫',
  infty:'∞', partial:'∂', nabla:'∇', hbar:'ℏ', ell:'ℓ',
  alpha:'α', beta:'β', gamma:'γ', Gamma:'Γ', delta:'δ', Delta:'Δ',
  epsilon:'ε', varepsilon:'ε', zeta:'ζ', eta:'η', theta:'θ', vartheta:'ϑ',
  iota:'ι', kappa:'κ', lambda:'λ', Lambda:'Λ', mu:'μ', nu:'ν', xi:'ξ', Xi:'Ξ',
  pi:'π', Pi:'Π', rho:'ρ', varrho:'ϱ', sigma:'σ', Sigma:'Σ', tau:'τ',
  upsilon:'υ', phi:'φ', varphi:'ϕ', chi:'χ', psi:'ψ', Psi:'Ψ',
  omega:'ω', Omega:'Ω',
  ldots:'…', cdots:'⋯', dots:'…', vdots:'⋮', ddots:'⋱',
  cup:'∪', cap:'∩', subset:'⊂', supset:'⊃', subseteq:'⊆', supseteq:'⊇',
  setminus:'∖', mid:'∣', backslash:'\\', smallsetminus:'\\', nmid:'∤', parallel:'∥',
  square:'□', bigcirc:'◯', checkmark:'✓', dagger:'†', ddagger:'‡',
  ominus:'⊖', oslash:'⊘', odot:'⊙', inter:'∩', bigtriangleup:'△', bigtriangledown:'▽',
  in:'∈', notin:'∉', ni:'∋', emptyset:'∅', varnothing:'∅',
  forall:'∀', exists:'∃', nexists:'∄', neg:'¬', lnot:'¬', land:'∧', lor:'∨',
  to:'→', rightarrow:'→', leftarrow:'←', gets:'←',
  Rightarrow:'⇒', Leftarrow:'⇐', iff:'⟺', leftrightarrow:'↔', Leftrightarrow:'⟺',
  mapsto:'↦', uparrow:'↑', downarrow:'↓', Rightleftharpoons:'⇌',
  perp:'⊥', parallel:'∥', angle:'∠', degree:'°', circ:'∘', otimes:'⊗', oplus:'⊕',
  aleph:'ℵ', wp:'℘', re:'ℜ', im:'ℑ', prime:'′',
  langle:'⟨', rangle:'⟩', lceil:'⌈', rceil:'⌉', lfloor:'⌊', rfloor:'⌋',
  quad:' ', qquad:'  ', enspace:' ', ' ':' ',
  sum:'∑', prod:'∏', coprod:'∐', int:'∫', iint:'∬', iiint:'∭', oint:'∮',
  lim:'lim', liminf:'lim inf', limsup:'lim sup', min:'min', max:'max',
  arg:'arg', det:'det', dim:'dim', ker:'ker', gcd:'gcd', sup:'sup', inf:'inf',
  sin:'sin', cos:'cos', tan:'tan', cot:'cot', sec:'sec', csc:'csc',
  arcsin:'arcsin', arccos:'arccos', arctan:'arctan',
  sinh:'sinh', cosh:'cosh', tanh:'tanh',
  log:'log', ln:'ln', lg:'lg', exp:'exp',
  displaystyle:'', textstyle:'', limits:'', nolimits:'',
  mathbf:'', mathit:'', mathrm:'', mathsf:'', mathtt:'', mathcal:'', mathbb:'', mathfrak:'',
  text:'', textrm:'', textbf:'', textit:'', texttt:'', mbox:'', underline:'',
  hline:'', phantom:'', vphantom:'', hphantom:'', smash:'',
  big:'', Big:'', bigg:'', Bigg:'', bigl:'', bigr:'', Bigl:'', Bigr:'',
  left:'', right:'', 'bigl_':'', nonumber:'', nopagebreak:'',
};

// ── Lệnh LaTeX KHÔNG mang nghĩa hiển thị → bỏ hẳn ─────────────────
const LATEX_DROP = new Set([
  'displaystyle','textstyle','scriptstyle','limits','nolimits','nonumber',
  'label','ref','tag','vspace','hspace','newline','indent','centering',
  'bfseries','itshape','rmfamily','sffamily','ttfamily','normalfont','ensuremath',
  'protect','allowbreak','nobreak','hfill','vfill','smallskip','medskip','bigskip',
]);

// ── Lệnh LaTeX → plain text (cho data-plain / so khớp Highlight 1) ───
const LATEX_PLAIN = {
  ...LATEX_SYM,
  // Hàm: giữ nguyên chữ thường, chỉ bỏ dấu backslash.
  // `value` = chuỗi thay thế cho plain (undefined → bỏ hẳn).
};

// helper: đọc 1 đối số LaTeX {…} hoặc 1 ký tự / 1 lệnh tại vị trí i
function _latexArg(src, i) {
  while (i < src.length && /\s/.test(src[i])) i++;
  if (i >= src.length) return ['', i];
  if (src[i] === '{') {
    let depth = 0;
    for (let j = i; j < src.length; j++) {
      const ch = src[j];
      if (ch === '\\') { j++; continue; }
      if (ch === '{') depth++;
      else if (ch === '}') { depth--; if (depth === 0) return [src.slice(i + 1, j), j + 1]; }
    }
    return [src.slice(i + 1), src.length];
  }
  if (src[i] === '\\') {
    const m = /^\\[a-zA-Z]+/.exec(src.slice(i));
    if (m) return [m[0], i + m[0].length];
    return [src.slice(i, i + 2), Math.min(i + 2, src.length)];
  }
  return [src[i], i + 1];
}

// Đọc 1 đối số CHỈ khi nó là {…} — tránh nuốt nhầm ký tự/nhãn
// (vd: \sum_{i} → '_' bị coi là đối số)
function _latexBraceArg(src, i) {
  while (i < src.length && /\s/.test(src[i])) i++;
  if (src[i] === '{') return _latexArg(src, i);
  return null;
}

// ─────────────────────────────────────────────────────────────────
// latexToPlain(latex) — BỘ CHUẨN HÓA DUY NHẤT cho text thuần.
// Phải cho ra ĐÚNG text mà KaTeX hiển thị trên olm.vn (đã đối chiếu thật):
//   "y=\cos x"           → "y=cos x"      (DOM: "y=cosx" — khớp sau khi bỏ space)
//   "{{\sin }^{2}}x"       → "sin2x"        (KaTeX của OLM render ² thành "2")
//   "\dfrac{\cos x}{x^3}" → "(cos x)/(x3)" (KHÔNG được mất \dfrac)
//   "\left| \sin x \right|" → "|sin x|"     (KHÔNG được mất dấu |)
//   "2\,019\cos x"        → "2 019cos x"   (KHÔNG được lọt \, )
//   "\mathbb{R}"          → "ℝ"
// Lưu ý phân biệt 2 loại chỉ số của OLM:
//   #n# / @n@  → sub/superscript UNICODE (quy ước rich-text của OLM)
//   ^n / _{n}  → chỉ số LaTeX, KaTeX render thành SỐ THƯỜNG ("x²" → "x2")
// ─────────────────────────────────────────────────────────────────
const LATEX_BLACKBOARD = {
  R: 'ℝ', N: 'ℕ', Z: 'ℤ', Q: 'ℚ', C: 'ℂ', P: 'ℙ',
};

function _supDigits(n) {
  return String(n).split('').map(c => SUP[+c] ?? c).join('');
}
function _subDigits(n) {
  return String(n).split('').map(c => SUB[+c] ?? c).join('');
}

// Bỏ marker OLM: #n# / @n@ là sub/sup, # hoặc @ còn lại là bullet → bỏ.
function stripOlmMarkers(s) {
  return String(s == null ? '' : s)
    .replace(/#(\d+)#/g, (_, n) => _subDigits(n))
    .replace(/@(\d+)@/g, (_, n) => _supDigits(n))
    // bullet OLM đặt ở đầu/cuối olm-list-item (vd "#Tập xác định...")
    .replace(/(^|[\s(])[#@]+(?=\S)/g, '$1')
    .replace(/[#@]+(?=$|[\s.,;:)\]])/g, '');
}

// Vị trí của '{' ngay sau 1 lệnh LaTeX (bỏ qua khoảng trắng).
function _braceAt(src, after) {
  let i = after;
  while (i < src.length && /[ \t\n\r]/.test(src[i])) i++;
  return src[i] === '{' ? i : -1;
}

function latexToPlain(latex) {
  if (latex == null) return '';
  let s = String(latex);
  if (!s) return '';
  // 1) Marker OLM (sub/sup/bullet) — trước khi xử lý backslash.
  s = stripOlmMarkers(s);

  // 2) \mathbb{R} → ℝ  (đặt trước bước "text-like" để không mất nội dung)
  for (let guard = 0; guard < 10; guard++) {
    const m = /\\(?:mathbb|Bbb)\s*\{/.exec(s);
    if (!m) break;
    const at = _braceAt(s, m.index + m[0].length - 1);
    if (at < 0) break;
    const [a, j1] = _latexArg(s, at);
    s = s.slice(0, m.index) + (LATEX_BLACKBOARD[a] || a) + s.slice(j1);
  }

  // 3) \frac / \dfrac / \tfrac / \cfrac → (num)/(den) — đệ quy, xử lý được
  //    dấu ngoặc lồng nhau. Regex cũ /\\frac\{([^}]+)\}\{([^}]+)\}/ vỡ ở
  //    \frac{\cos x}{x^3} và không nhận \dfrac → sinh đáp án sai.
  for (let guard = 0; guard < 12; guard++) {
    const m = /\\(frac|dfrac|tfrac|cfrac)(?![a-zA-Z])/.exec(s);
    if (!m) break;
    const at = _braceAt(s, m.index + m[0].length);
    if (at < 0) { s = s.slice(0, m.index) + s.slice(m.index + m[0].length); continue; }
    const [a, j1] = _latexArg(s, at);
    const bAt = _braceAt(s, j1);
    if (bAt < 0) break;
    const [b, j2] = _latexArg(s, bAt);
    s = s.slice(0, m.index) + '(' + latexToPlain(a) + ')/(' + latexToPlain(b) + ')' + s.slice(j2);
  }

  // 4) \sqrt[n]{x} và \sqrt{x}
  for (let guard = 0; guard < 12; guard++) {
    const m = /\\sqrt(?![a-zA-Z])/.exec(s);
    if (!m) break;
    let idx = m.index + m[0].length;
    while (idx < s.length && /[ \t\n\r]/.test(s[idx])) idx++;
    let deg = '';
    if (s[idx] === '[') { const e = s.indexOf(']', idx); if (e > 0) { deg = s.slice(idx + 1, e); idx = e + 1; } }
    const at = _braceAt(s, idx);
    if (at < 0) break;
    const [a, j1] = _latexArg(s, at);
    s = s.slice(0, m.index) + '√' + (deg ? latexToPlain(deg) : '') + '(' + latexToPlain(a) + ')' + s.slice(j1);
  }

  // 5) Dấu | tuyệt đối — \left| \right| \lvert \rvert \vert \|
  s = s.replace(/\\(?:left|right|lvert|rvert|vert|Vert)\s*(?=\|)/g, '')
       .replace(/\\\|/g, '|');
  // 6) Khoảng trắng "vô hình" trong LaTeX: \, \; \: \! \>
  //    (bản cũ KHÔNG xử lý → "2\,019" lọt thẳng vào đáp án, xem screenshot)
  s = s.replace(/\\[,;:!> ]/g, ' ');
  // 7) Vector / dấu phủ
  s = s.replace(/\\(?:overrightarrow|overleftarrow|wideparen)(?![a-zA-Z])\s*/g, '');
  for (const cmd of ['vec', 'hat', 'widehat', 'tilde', 'bar', 'overline', 'underline', 'overbrace', 'underbrace']) {
    for (let guard = 0; guard < 6; guard++) {
      const re = new RegExp('\\\\' + cmd + '(?![a-zA-Z])\\s*\\{');
      const m = re.exec(s);
      if (!m) break;
      const [a, j1] = _latexArg(s, m.index + m[0].length - 1);
      const mark = { vec: '⃗', hat: '̂', widehat: '̂', tilde: '̃', bar: '̄',
                     overline: '̄', underline: '_', overbrace: '⏞', underbrace: '⏟' }[cmd] || '';
      s = s.slice(0, m.index) + latexToPlain(a) + mark + s.slice(j1);
    }
  }
  // 8) \text{...} & \mathrm & friends → giữ nội dung chữ
  for (let guard = 0; guard < 20; guard++) {
    const m = /\\(?:text|textrm|textbf|textit|texttt|mathrm|mathbf|mathit|mathsf|mathtt|mathcal|mathbb|mathfrak|operatorname|name|mbox|hbox|underset|overset)\s*(\[[^\]]*\])?\s*\{/.exec(s);
    if (!m) break;
    const open = s.indexOf('{', m.index + m[0].length - 1);
    if (open < 0) break;
    const [a, j1] = _latexArg(s, open);
    s = s.slice(0, m.index) + latexToPlain(a) + s.slice(j1);
  }
  // 9) \color{...} / \textcolor{...}{...} → bỏ màu, giữ nội dung
  for (let guard = 0; guard < 8; guard++) {
    const m = /\\(?:color|textcolor)(?![a-zA-Z])\s*\{/.exec(s);
    if (!m) break;
    const at = _braceAt(s, m.index + m[0].length);
    if (at < 0) break;
    const [, j1] = _latexArg(s, at);
    s = s.slice(0, m.index) + s.slice(j1);
  }
  // 10) \begin{env} … \end{env} → bỏ tên môi trường (giữ nội dung)
  s = s.replace(/\\(?:begin|end)\s*\{[^}]*\}/g, ' ');
  // 11) \left( \right) \left. … → bỏ lệnh, giữ ký tự
  s = s.replace(/\\(?:left|right)(?![a-zA-Z])\s*(.)/g, (_, c) => (c === '.' ? '' : c));

  // 12) ^ và _ — KaTeX render mũ/hạ bằng CSS nên textContent ra SỐ THƯỜNG
  //     ("x^2" → "x2", "x_1" → "x1"), và khoảng trắng nguồn quanh mũ bị nuốt.
  //     Bản cũ cho "x²" (superscript unicode) nên Highlight 1 không bao giờ khớp
  //     với DOM "x2" trên môn Toán. Giữ nguyên số là đúng và khớp thật.
  for (let guard = 0; guard < 40; guard++) {
    const i = s.search(/[\^_]/);
    if (i < 0) break;
    // nuốt 1 khoảng trắng ngay TRƯỚC mũ/hạ (LaTeX: "\sin ^{2}")
    let start = i;
    while (start > 0 && /[ \t]/.test(s[start - 1])) start--;
    const [, ni] = _latexArg(s, i + 1);
    const inner = latexToPlain(_latexArg(s, i + 1)[0]);
    // nuốt 1 khoảng trắng ngay SAU mũ/hạ (LaTeX: "\sin^2 x" → "sin2x")
    let end = ni;
    while (end < s.length && /[ \t]/.test(s[end])) end++;
    s = s.slice(0, start) + inner + s.slice(end);
  }

  // 13) Lệnh quen → Unicode / chữ
  s = s.replace(/\\([a-zA-Z]+)/g, (full, name) => {
    if (LATEX_DROP.has(name)) return ' ';
    if (Object.prototype.hasOwnProperty.call(LATEX_PLAIN, name)) {
      const v = LATEX_PLAIN[name];
      return v == null ? ' ' : v;
    }
    return ''; // lệnh lạ → bỏ
  });
  // 14) Ký tự escape đơn: \{ \} \% \$ \& \# \_ \|
  s = s.replace(/\\([{}$%&_#|~^\\])/g, '$1');
  // 15) Bỏ ngoặc nhóm còn sót
  s = s.replace(/[{}]/g, '');
  // 16) gộp khoảng trắng (kể cả các space unicode mà KaTeX sinh ra)
  s = s.replace(/[\s\u00a0\u202f\u2009\u200a\u2007\u200b]+/g, ' ').trim();
  return s;
}

function escapeAttr(t) {
  return String(t == null ? '' : t)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

// Tương thích ngược: bản cũ gọi applyLatexMap() ở nhiều nơi.
// Nay chỉ chuyển tiếp sang bộ chuẩn hóa duy nhất latexToPlain().
function applyLatexMap(s) {
  try { return latexToPlain(s); } catch (_) { return String(s == null ? '' : s); }
}

// Tương thích ngược: renderLatexSegment() nay = latexToPlain().
// Đảm bảo data-plain (dùng để so khớp Highlight 1) LUÔN khớp với text mà
// latexToHtml() render ra — trước đây 2 bộ quy tắc lệch nhau sinh false/negative
// match trên môn Toán.
function renderLatexSegment(latex) {
  try { return latexToPlain(latex); } catch (_) { return String(latex == null ? '' : latex).trim(); }
}

// Renderer LaTeX → HTML có cấu trúc: \frac → phân số thật, \sqrt → căn có gạch,
// ^/_ → <sup>/<sub>. Không phụ thuộc CDN.
function latexToHtml(src) {
  const esc = t => String(t).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  const s = String(src == null ? '' : src);
  let out = '';
  let i = 0;
  while (i < s.length) {
    const c = s[i];

    // Lũy thừa / chỉ số dưới
    if (c === '^' || c === '_') {
      const [arg, ni] = _latexArg(s, i + 1);
      const inner = latexToHtml(arg);
      out += c === '^' ? `<sup>${inner}</sup>` : `<sub>${inner}</sub>`;
      i = ni; continue;
    }
    if (c === '{') { const [arg, ni] = _latexArg(s, i); out += latexToHtml(arg); i = ni; continue; }
    if (c === '}') { i++; continue; }

    if (c === '\\') {
      const m = /^\\([a-zA-Z]+)/.exec(s.slice(i));
      if (m) {
        const cmd = m[1];
        const j0 = i + m[0].length;
        if (cmd === 'frac' || cmd === 'dfrac' || cmd === 'tfrac') {
          const [a, j1] = _latexArg(s, j0);
          const [b, j2] = _latexArg(s, j1);
          out += `<span class="olm-frac"><span class="olm-frac-n">${latexToHtml(a)}</span>`
               + `<span class="olm-frac-sep">/</span><span class="olm-frac-d">${latexToHtml(b)}</span></span>`;
          i = j2; continue;
        }
        if (cmd === 'sqrt') {
          let idx = j0, deg = '';
          if (s[idx] === '[') { const e = s.indexOf(']', idx); if (e > 0) { deg = s.slice(idx + 1, e); idx = e + 1; } }
          const [a, j1] = _latexArg(s, idx);
          const head = deg ? `<sup>${latexToHtml(deg)}</sup>√` : '√';
          out += `<span class="olm-sqrt">${head}<span class="olm-sqrt-b">${latexToHtml(a)}</span></span>`;
          i = j1; continue;
        }
        if (cmd === 'begin' || cmd === 'end') {
          const b = _latexBraceArg(s, j0);
          i = b ? b[1] : j0; continue;
        }
        if (cmd === 'left' || cmd === 'right') {
          const [d, j1] = _latexArg(s, j0);
          const ch = d.length === 2 && d[0] === '\\' ? d[1] : d;
          out += ch === '.' ? '' : esc(ch);
          i = j1; continue;
        }
        if (cmd === 'text' || cmd === 'mathrm' || cmd === 'textrm' || cmd === 'textbf'
            || cmd === 'textit' || cmd === 'operatorname' || cmd === 'mbox' || cmd === 'mathop') {
          const [a, j1] = _latexArg(s, j0);
          out += `<span class="olm-plain">${latexToHtml(a)}</span>`;
          i = j1; continue;
        }
        if (cmd === 'overline' || cmd === 'bar') {
          const [a, j1] = _latexArg(s, j0);
          out += `<span class="olm-over">${latexToHtml(a)}</span>`;
          i = j1; continue;
        }
        if (cmd === 'vec') {
          const [a, j1] = _latexArg(s, j0);
          out += `${latexToHtml(a)}⃗`;
          i = j1; continue;
        }
        if (cmd === 'hat' || cmd === 'widehat') {
          const [a, j1] = _latexArg(s, j0);
          out += `${latexToHtml(a)}̂`;
          i = j1; continue;
        }
        if (cmd === 'color' || cmd === 'textcolor') {
          const b = _latexBraceArg(s, j0); i = b ? b[1] : j0; continue;
        }
        if (LATEX_SYM[cmd] !== undefined) {
          const v = String(LATEX_SYM[cmd]);
          // Giá trị là chữ (sin, lim, max…) → đứng thẳng, không nghiêng
          out += /^[A-Za-zÀ-ỹ\s]+$/.test(v) ? `<span class="olm-plain">${esc(v)}</span>` : esc(v);
          i = j0; continue;
        }
        // Lệnh lạ → bỏ lệnh, chỉ giữ nội dung {} ngay sau đó (nếu có)
        const b = _latexBraceArg(s, j0);
        if (b && b[0]) out += latexToHtml(b[0]);
        i = b ? b[1] : j0;
        continue;
      }
      // \\ (ngắt dòng) · \, \; \: \! · \ ký tự đặc biệt
      const n = s[i + 1];
      if (n === undefined) { i++; continue; }
      if (n === '\\') {
        let j = i + 2;
        while (j < s.length && /\s/.test(s[j])) j++;
        if (s[j] === '[') { const e = s.indexOf(']', j); j = e > 0 ? e + 1 : j; }
        out += ' '; i = j; continue;
      }
      if (',;:'.includes(n)) { out += ' '; i += 2; continue; }
      if (n === '!' || n === ' ') { i += 2; continue; }
      out += esc(n); i += 2; continue;
    }

    if (c === '&') { i++; continue; }
    if (c === '~') { out += ' '; i++; continue; }

    let j = i;
    while (j < s.length && '^_\\{}&~'.indexOf(s[j]) === -1) j++;
    if (j === i) j++;
    out += esc(s.slice(i, j));
    i = j;
  }
  return out;
}

function mathTextToHtml(s) {
  if (!s || typeof s !== 'string') return escapeHtml(s || '');

  // Bọc phần math: data-plain giữ bản text thuần ĐÃ QUA CHÍNH NHIÃ latexToPlain
  // → khớp đúng text mà latexToHtml() render, và khớp KaTeX trên trang.
  const wrapMath = (latex) => {
    const plain = renderLatexSegment(latex);
    return `<span class="olm-math" data-plain="${escapeAttr(plain)}">${latexToHtml(latex)}</span>`;
  };

  // Tokenize: tách phần LaTeX có delimiter \(...\) \[...\] $$...$$ $...$ khỏi plain text
  // FIX v1.3.2: OLM Toán dùng $...$ đơn rất nhiều ($ABC$, $\widehat{B}=...$).
  // Regex cũ chỉ có \(...\) \[...\] $$...$$ → panel hiện raw $...$ ("lỗi math text")
  // và cleanMathText/highlight mismatch. Thêm nhánh \$([^\$]+?)\$ (đặt SAU $$).
  const parts = [];
  const mathRe = /\\\((.+?)\\\)|\\\[(.+?)\\\]|\$\$(.+?)\$\$|\$([^\$]+?)\$/gs;
  let last = 0, m;
  mathRe.lastIndex = 0;
  while ((m = mathRe.exec(s)) !== null) {
    if (m.index > last) parts.push({ type: 'text', v: s.slice(last, m.index) });
    parts.push({ type: 'math', v: m[1] ?? m[2] ?? m[3] ?? m[4] });
    last = m.index + m[0].length;
  }
  if (last < s.length) parts.push({ type: 'text', v: s.slice(last) });
  if (parts.length === 0) parts.push({ type: 'text', v: s });

  // Nếu không có delimiter nào mà toàn bộ string có lệnh LaTeX
  // → render toàn bộ như LaTeX (trường hợp API trả về LaTeX thô không có \(…\))
  if (parts.length === 1 && parts[0].type === 'text' && /\\[a-zA-Z]/.test(s)) {
    const rendered = renderLatexSegment(s);
    if (rendered !== s) return wrapMath(s);
  }

  // Phần text thường cũng phải bỏ marker OLM (#/@) và escape.
  const html = [];
  for (const p of parts) {
    if (p.type === 'math') {
      html.push(wrapMath(p.v));
    } else {
      html.push(stripOlmMarkers(p.v).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'));
    }
  }
  return html.join('');
}

function cleanMathText(s) {
  if (s == null) return s;
  const out = String(s);
  if (!out) return out;
  // Bóc delimiter rồi chuẩn hóa bằng BỘ DUY NHẤT latexToPlain()
  // (trước đây dùng chuỗi replace cũ: không xử lý \dfrac, \left|, \, → sinh
  //  đáp án sai/lọt ký tự LaTeX thô vào panel, ví dụ "y=2\,019cos x+2\, 020")
  let t = out;
  const mathRe = /\\\((.+?)\\\)|\\\[(.+?)\\\]|\$\$(.+?)\$\$|\$([^\$]+?)\$/gs;
  const parts = [];
  let last = 0, m;
  mathRe.lastIndex = 0;
  while ((m = mathRe.exec(t)) !== null) {
    if (m.index > last) parts.push({ type: 'text', v: t.slice(last, m.index) });
    parts.push({ type: 'math', v: m[1] ?? m[2] ?? m[3] ?? m[4] });
    last = m.index + m[0].length;
  }
  if (last < t.length) parts.push({ type: 'text', v: t.slice(last) });
  const res = parts.map(p => (p.type === 'math'
    ? renderLatexSegment(p.v)
    : stripOlmMarkers(p.v)));
  t = res.join(' ').replace(/\s+/g, ' ').trim();
  // Nếu còn LaTeX thô không có delimiter (vd toàn bộ string là $...$ đã bóc hết
  // nhưng chứa \frac) → chuẩn hóa nốt phần text.
  if (/\\[a-zA-Z]|[{}]/.test(t)) {
    try { t = latexToPlain(t); } catch (_) {}
  }
  return t;
}

function escapeHtml(t) { if (t == null) return ''; const d = document.createElement('div'); d.textContent = String(t); return d.innerHTML; }
function normText(s) { return String(s || '').replace(/\s+/g, ' ').trim(); }
function htmlLooksLikeHasMath(html) { return /katex|mathjax|data-math|\\frac|\\sum|class="math/i.test(html); }

function setAnswerText(li, text) {
  // SECURITY: mathTextToHtml escapes text nhưng vẫn route qua sanitize
  // để mọi đường vào panel đều qua 1 sanitizer dùng chung.
  try { li.innerHTML = sanitizeHTML(mathTextToHtml(String(text || ''))); }
  catch (_) { li.textContent = String(text || ''); }
}

// ============================================================
// ANSWER EXTRACTION FUNCTIONS (port đầy đủ từ script gốc)
// ============================================================
function lexicalPlainText(node) {
  if (node == null) return '';
  if (typeof node === 'string') return node;
  if (typeof node === 'number') return String(node);
  if (Array.isArray(node)) return node.map(lexicalPlainText).join('');
  if (typeof node !== 'object') return '';
  let s = '';
  if (typeof node.text === 'string') s += node.text;
  // FIX v1.3.2: Lexical mới của OLM lưu công thức ở node {type:"equation", equation:"\\sqrt{2}."}
  // Code cũ chỉ đọc node.text → equation bị mất → đáp án toán trống → highlight fail + panel trống.
  if (typeof node.equation === 'string' && node.equation) s += (s ? ' ' : '') + node.equation;
  else if (typeof node.latex === 'string' && node.latex && !node.text) s += (s ? ' ' : '') + node.latex;
  if (Array.isArray(node.children)) s += node.children.map(lexicalPlainText).join('');
  return s;
}

function extractStemTextFromLexical(jsonData) {
  try {
    const root = jsonData && (jsonData.root != null ? jsonData.root : jsonData);
    if (!root || !Array.isArray(root.children)) return '';
    const parts = [];
    for (const child of root.children) {
      if (!child) continue;
      if (child.type === 'olm-list') break;
      if (child.type === 'paragraph' || child.type === 'heading') {
        const t = normText(lexicalPlainText(child)); if (t) parts.push(t);
      }
    }
    return parts.join('\n');
  } catch (_) { return ''; }
}

// tryParseQuestionJsonTree — bao gồm decode base64 json_content qua bridge
// Memo theo từng object question: hàm này được gọi nhiều lần/stem (extract + sanitize)
// mà JSON.parse trên json_content lớn rất tốn kém.
const _jsonTreeMemo = new WeakMap();
function tryParseQuestionJsonTree(question) {
  if (!question || typeof question !== 'object') return null;
  if (_jsonTreeMemo.has(question)) return _jsonTreeMemo.get(question);
  const val = _parseQuestionJsonTree(question);
  try { _jsonTreeMemo.set(question, val); } catch (_) {}
  return val;
}

function _parseQuestionJsonTree(question) {
  const raw = question.json_content;
  if (raw == null) return null;
  if (typeof raw === 'object') return raw;
  const str = String(raw).trim();
  if (str.startsWith('{')) { try { return JSON.parse(str); } catch (_) {} }
  // Thử decode base64 (sync)
  const b64 = normalizeBase64(str);
  if (b64 && /^[A-Za-z0-9+/=]+$/.test(b64)) {
    const decoded = decodeSync(b64);
    if (decoded && decoded.trim().startsWith('{')) {
      try { return JSON.parse(decoded); } catch (_) {}
    }
  }
  return null;
}

// [REMOTE-CONFIG] let (không phải const): có thể bị thay bằng giá trị đã
// validate từ remote config. Mặc định = đúng giá trị hardcode của v1.3.12.
let ANSWER_DOM_SELECTORS = [
  // ── UI MỚI của olm.vn (đã kiểm chứng 2026-10) ──
  // Trắc nghiệm: div.qselect (đúng = .correctq), nội dung ở .qsign
  '.qselect.correctq','div.qselect.qcorrect','[class*="qselect"].correctq',
  '.qselect[data-correct="true"]','[ind].correctq',
  // Đúng/Sai: span.qiradio.xcorrect
  '.qiradio.xcorrect','.xcorrect','[class*="xcorrect"]',
  // ── UI cũ (giữ nguyên) ──
  '.correctAnswer','.correct-answer',
  '[data-correct="true"]','[data-correct="1"]','[data-is-correct="true"]',
  '.is-correct','.answer-correct','.answer.true','.answer--correct',
  '.quiz-answer.correct','.item-correct','.dap-an-dung','.true-answer',
  '[class*="correctAnswer"]','[class*="answer-correct"]',
  '[data-solution]','[data-dap-an]',
  '.olm-correct','.quiz-correct','.item--correct',
  '.match-correct','.pair-correct',
  '[data-answer]','[data-blank-answer]',
  // OLM dùng data-accept cho ô điền từ (tiếng Anh word-form / rewrite)
  '[data-accept]','input[data-accept]','textarea[data-accept]',
  '.drag-result','.drop-result','.fill-result',
  '[class*="dap-an-dung"]','.answer-filled','.blank-filled','.slot-filled',
  // Tiếng Anh / Worksheet
  '.correct-option','.selected-answer.correct','[data-state="correct"]',
  '.choice.correct','.option.correct',
  '[class*="correct-choice"]','[class*="right-answer"]',
  '.answer-key','.model-answer','.sample-answer',
  '.gap-answer','.blank-answer','[class*="gap-fill"]',
  '.word-answer','.fill-answer',
  '.match-answer','.pair-answer','.correct-pair',
].join(', ');

function querySelectorDeep(root, sel) {
  if (!root) return null;
  try { const d = root.querySelector(sel); if (d) return d; } catch (_) {}
  const all = root.querySelectorAll ? root.querySelectorAll('*') : [];
  for (let i = 0; i < all.length; i++) {
    const el = all[i];
    if (el.shadowRoot) { const h = querySelectorDeep(el.shadowRoot, sel); if (h) return h; }
  }
  return null;
}

function querySelectorAllDeep(root, sel) {
  const out = [];
  if (!root || !root.querySelectorAll) return out;
  try { root.querySelectorAll(sel).forEach(el => out.push(el)); } catch (_) {}
  // Có kết quả ở light DOM → bỏ qua quét shadow root (tiết kiệm 1 lần duyệt toàn bộ subtree)
  if (out.length) return out;
  try {
    root.querySelectorAll('*').forEach(el => {
      if (el.shadowRoot && el.tagName && (el.tagName.includes('-') || /^(DETAILS|SUMMARY)$/.test(el.tagName))) {
        querySelectorAllDeep(el.shadowRoot, sel).forEach(x => out.push(x));
      }
    });
  } catch (_) {}
  return out;
}

// Cache block câu hỏi theo id — tránh quét lại document mỗi lần extract
const _olmBlockCache = new Map();
const _olmBlockMiss = new Map();   // id → số lần miss (giới hạn quét shadow DOM lặp lại)
const OLM_BLOCK_SEL_TEMPLATES = id => [
  `[data-id="${id}"]`,`[data-idquestion="${id}"]`,`[data-question-id="${id}"]`,
  `[data-question="${id}"]`,`[data-qid="${id}"]`,`[data-questionid="${id}"]`,
  `[data-id_question="${id}"]`,`[data-question_id="${id}"]`,
  // Trang review bài đã làm của OLM dùng data-id-quiz / data-id_quiz
  // (vd: <div class="quiz-content" data-id-quiz="201193999939">)
  `[data-id-quiz="${id}"]`,`[data-id_quiz="${id}"]`,`[data-idquiz="${id}"]`,
  `[data-quiz="${id}"]`,`[data-quiz-id="${id}"]`,
  `#question-${id}`,`#cauhoi-${id}`,`#q-${id}`,`[id="q-${id}"]`,
];

function findQuestionBlockInPage(question) {
  try {
    const qid = question.id != null ? String(question.id) : '';
    const oid = question._id != null ? String(question._id) : '';
    const ids = [qid, oid].filter(Boolean);
    if (!ids.length) return null;

    // 1. Dùng cache (kiểm tra còn trong DOM không)
    const key = ids.join('|');
    const cached = _olmBlockCache.get(key);
    if (cached) {
      if (cached.isConnected && !cached.closest('#olm-answers-container') && !cached.closest('#olm-panel-root')) return cached;
      _olmBlockCache.delete(key);
    }

    // 2. Gộp TẤT CẢ selector thành 1 query duy nhất (thay vì ~20 lần quét shadow root)
    const combined = ids.map(OLM_BLOCK_SEL_TEMPLATES).flat().join(',');
    let found = null;
    try {
      for (const el of document.querySelectorAll(combined)) {
        if (el.closest('#olm-answers-container') || el.closest('#olm-panel-root')) continue;
        found = el; break;
      }
    } catch (_) {}
    // 3. Chỉ quét shadow DOM khi light DOM miss — tối đa 2 lần/nhóm id
    //    (tránh lặp lại full-document scan với các câu không có block trên trang)
    if (!found) {
      const misses = _olmBlockMiss.get(key) || 0;
      if (misses < 2) {
        const deep = querySelectorDeep(document, combined);
        _olmBlockMiss.set(key, misses + 1);
        if (_olmBlockMiss.size > 400) _olmBlockMiss.delete(_olmBlockMiss.keys().next().value);
        if (deep && !deep.closest('#olm-answers-container') && !deep.closest('#olm-panel-root')) found = deep;
      }
    }

    if (found) {
      _olmBlockCache.set(key, found);
      _olmBlockMiss.delete(key);
      if (_olmBlockCache.size > 200) _olmBlockCache.delete(_olmBlockCache.keys().next().value);
    }
    return found;
  } catch (_) {}
  return null;
}

function extractAnswersFromPlainApiFields(question) {
  if (!question || typeof question !== 'object') return null;
  // pick: trả về null nếu giá trị rỗng, chỉ dấu chấm, hoặc không phải string/number
  const pick = v => {
    if (v == null) return null;
    if (typeof v === 'number') return String(v);
    if (typeof v !== 'string') return null;
    const t = v.trim();
    // Bỏ qua giá trị rỗng hoặc chỉ là dấu chấm/khoảng trắng
    if (!t || /^[.\s]+$/.test(t)) return null;
    return t;
  };
  const direct = pick(question.answer) || pick(question.correct_answer) || pick(question.correctAnswer)
    || pick(question.da) || pick(question.dap_an) || pick(question.result) || pick(question.true_answer);
  // Lưu ý: bỏ question.key khỏi đây vì "key" thường là license key, không phải đáp án
  if (direct) {
    const ul = document.createElement('ul');
    const li = document.createElement('li'); setAnswerText(li, direct); ul.appendChild(li);
    TRACE.step(question, {
      source: 'question object (plain API field)', field: 'answer|correct_answer|correctAnswer|da|dap_an|result|true_answer',
      raw: direct, parser: 'plain API', sanitized: direct, final: [direct],
    });
    return ul;
  }
  const arr = question.answers || question.options || question.list_answer || question.listAnswer;
  if (Array.isArray(arr)) {
    const texts = arr.filter(item => item && typeof item === 'object' &&
      (item.correct === true || item.is_correct === true || item.isCorrect === true || item.dung === true))
      .map(item => pick(item.text) || pick(item.label) || pick(item.content) || pick(item.value) || pick(item.title))
      .filter(Boolean);
    if (texts.length) {
      const ul = document.createElement('ul');
      texts.forEach(t => { const li = document.createElement('li'); setAnswerText(li, t); ul.appendChild(li); });
      TRACE.step(question, {
        source: 'question object (array field, items flagged correct)',
        field: 'answers|options|list_answer|listAnswer',
        raw: arr, parser: 'plain API', sanitized: texts, final: texts,
      });
      return ul;
    }
  }
  return null;
}

// ─────────────────────────────────────────────────────────────────
// ĐÚNG / SAI
// ─────────────────────────────────────────────────────────────────
// OLM KHÔNG dùng node isTrue/answer-bool cho câu ĐS. Đã kiểm chứng trên
// olm.vn: câu ĐS là olm-list với name:"true-false", lockOptionPosition:true,
// mỗi olm-list-item có `correct: true|false`, `level:"1"|"2"` và text BẮT ĐẦU
// bằng marker "#" (bullet của OLM).
// Hàm cũ chỉ nhận isTrue/answer-bool → không nhận diện được câu ĐS của OLM,
// panel in mệnh đề kèm dấu "#", và không gắn nhãn Đúng/Sai.
// [REMOTE-CONFIG] let — xem RC.applyRemoteConfig()
let TF_LIST_NAME_RE = /true[\s-]?f(?:a|)lse|true[\s-]?false|dung[\s-]?sai/i;

function isTrueFalseList(listNode) {
  if (!listNode || listNode.type !== 'olm-list') return false;
  return TF_LIST_NAME_RE.test(String(listNode.name || ''))
      || TF_LIST_NAME_RE.test(String(listNode.listType || ''));
}

function extractTrueFalseAnswers(root) {
  const results = []; const seen = new Set();
  function add(text, correct) {
    const t = normText(stripOlmMarkers(String(text == null ? '' : text)));
    if (!t || t.length > 400) return;
    if (seen.has(t)) return;
    seen.add(t);
    results.push({ text: t, correct });
  }
  function walk(node, depth) {
    if (!node || typeof node !== 'object' || depth > 30) return;
    if (Array.isArray(node)) { node.forEach(n => walk(n, depth + 1)); return; }
    // ── Dạng OLM: olm-list name="true-false" ──
    if (isTrueFalseList(node) && Array.isArray(node.children)) {
      for (const item of node.children) {
        if (!item || typeof item !== 'object') continue;
        if (typeof item.correct !== 'boolean') continue;
        add(lexicalPlainText(item), item.correct);
      }
      return;
    }
    // ── Dạng cũ: isTrue / answer(bool) / correct(bool) + statement ──
    const hasIsTrue = typeof node.isTrue === 'boolean';
    const hasAnswerBool = typeof node.answer === 'boolean';
    const hasCorrectBool = typeof node.correct === 'boolean' &&
      (node.statement != null || node.type === 'true-false-item' || node.type === 'olm-true-false-item');
    if (hasIsTrue || hasAnswerBool || hasCorrectBool) {
      const correctVal = hasIsTrue ? node.isTrue : hasAnswerBool ? node.answer : node.correct;
      const text = normText(node.statement || node.text || node.label || node.content
        || lexicalPlainText(node.children ? { children: node.children } : node));
      if (text) add(text, correctVal);
    }
    if (Array.isArray(node.statements)) {
      node.statements.forEach(s => {
        if (!s || typeof s !== 'object') return;
        const text = normText(s.statement || s.text || s.label || '');
        const correctVal = typeof s.isTrue === 'boolean' ? s.isTrue : typeof s.correct === 'boolean' ? s.correct : null;
        if (text && correctVal !== null) add(text, correctVal);
      });
    }
    if (Array.isArray(node.children)) node.children.forEach(c => walk(c, depth + 1));
    for (const k of Object.keys(node)) {
      if (k === 'children' || k === 'parent' || k === 'statements' || k === '__ob__') continue;
      const v = node[k]; if (v && typeof v === 'object') walk(v, depth + 1);
    }
  }
  walk(root, 0);
  return results;
}

function extractDragDropAnswers(root) {
  const results = []; const seen = new Set(); const slotCounter = { n: 0 };
  function pushAnswer(text) {
    const t = cleanMathText(normText(String(text || '')));
    if (!t) return; slotCounter.n++;
    const key = `${slotCounter.n}:${t}`;
    if (seen.has(key)) return; seen.add(key);
    results.push({ slot: slotCounter.n, answer: t });
  }
  function walk(node, depth) {
    if (!node || typeof node !== 'object' || depth > 35) return;
    if (Array.isArray(node)) { node.forEach(n => walk(n, depth+1)); return; }
    const t = node.type || '';
    // OLM tiếng Anh dùng type "fillme-input" với đáp án nằm ở field `content`
    // (vd: {type:"fillme-input", content:"constructive", placeholder:"?"})
    if (/fillme|math.?input|short.?answer|math.?answer|fill.?answer|olm.?input|input.?answer|answer.?box/i.test(t)) {
      const ans = node.correctAnswer || node.correct_answer || node.answer || node.accepts || node.content || node.value;
      if (ans != null) { Array.isArray(ans) ? ans.forEach(pushAnswer) : pushAnswer(ans); return; }
    }
    if (/blank|slot|drop.?zone|fill/i.test(t)) {
      const ans = node.answer || node.accepts || node.correctAnswer || node.correct_answer || node.content || node.value || node.text;
      if (ans != null) { Array.isArray(ans) ? ans.forEach(pushAnswer) : pushAnswer(ans); return; }
    }
    if (/drag.?item|drag.?answer|answer.?item/i.test(t)) {
      const ans = node.answer || node.text || node.label || node.content;
      if (ans) { pushAnswer(ans); return; }
    }
    for (const key of ['blanks','answers','slots','items','correctAnswers','correct_answers']) {
      if (Array.isArray(node[key])) {
        node[key].forEach(item => {
          if (!item) return;
          const ans = typeof item === 'string' ? item : item.answer || item.text || item.label || item.value || item.content;
          if (ans) pushAnswer(ans);
        });
        if (results.length) return;
      }
    }
    if (Array.isArray(node.children)) {
      let blankCount = 0;
      node.children.forEach(child => {
        if (!child) return;
        const ct = child.type || '';
        if (/fillme|blank|slot|fill|math.?input|short.?answer|olm.?input|answer.?box/i.test(ct)) {
          blankCount++;
          const ans = child.correctAnswer || child.correct_answer || child.answer || child.accepts || child.content || child.value;
          if (ans != null) { Array.isArray(ans) ? ans.forEach(pushAnswer) : pushAnswer(ans); }
        }
      });
      if (blankCount > 0) return;
      node.children.forEach(c => walk(c, depth+1)); return;
    }
    for (const k of Object.keys(node)) {
      if (k === 'parent' || k === '__ob__' || k === 'children') continue;
      const v = node[k]; if (v && typeof v === 'object') walk(v, depth+1);
    }
  }
  walk(root, 0); return results;
}

function extractDragDropFromHtml(html) {
  if (!html || isGarbageText(html)) return [];
  // SECURITY: div detached chỉ để parse (không bao giờ append vào DOM nên
  // <script>/<img onerror> không thực thi). Chỉ đọc attributes/text.
  // Mọi node đưa vào panel từ kết quả hàm này đều qua textContent/mathTextToHtml.
  const div = document.createElement('div'); div.innerHTML = html;
  const results = []; let idx = 0;
  div.querySelectorAll('input[data-answer], input[data-correct], input[data-accept], textarea[data-accept], span[data-answer], [data-blank-answer], [data-accept]').forEach(el => {
    idx++;
    const ans = el.getAttribute('data-answer') || el.getAttribute('data-correct') || el.getAttribute('data-accept') || el.getAttribute('data-blank-answer') || el.value || '';
    if (ans.trim()) results.push({ slot: idx, answer: cleanMathText(ans.trim()) });
  });
  div.querySelectorAll('select').forEach(sel => {
    idx++;
    const correct = sel.querySelector('option[data-correct="true"], option[data-correct="1"]');
    if (correct) results.push({ slot: idx, answer: cleanMathText(correct.textContent.trim()) });
  });
  return results;
}

// ============================================================
// DẠNG XẾP CÂU / XẾP TỪ (type-advance, q_type "order")
// ------------------------------------------------------------
// OLM gói toàn bộ từ/cụm từ của câu đúng vào MỘT chuỗi, phân tách bằng "||":
//   <ol class="quiz-list"><li>It||can||be||tough||when||your family||…</li></ol>
// Trong json_content chuỗi đó nằm ở node extended-text bên trong olm-list-item
// và item có correct:false ⇒ không extractor nào dựa correct:true bắt được.
// Đây là dấu hiệu DUY NHẤT đáng tin cho dạng này, nên ta dò theo chính nó.
// ============================================================

// "It||can||be||…" → ['It','can','be',…]. Trả [] nếu không phải dạng này.
function splitPipeOrder(text) {
  const s = String(text == null ? '' : text).replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
  if (s.indexOf('||') < 0) return [];
  const parts = s.split('||').map(p => cleanMathText(p.trim())).filter(Boolean);
  return parts.length >= 2 ? parts : [];
}

// Từ json_content (Lexical tree): bất kỳ node nào có `text` chứa "||".
function extractPipeOrderAnswers(root) {
  if (!root || typeof root !== 'object') return [];
  const results = [];
  const seen = new Set();
  const walk = (node, depth) => {
    if (!node || typeof node !== 'object' || depth > 30 || results.length) return;
    if (Array.isArray(node)) { for (const n of node) walk(n, depth + 1); return; }
    if (typeof node.text === 'string' && node.text.indexOf('||') >= 0) {
      for (const p of splitPipeOrder(node.text)) {
        if (!seen.has(p)) { seen.add(p); results.push(p); }
      }
      if (results.length) return;
    }
    if (node.content != null && typeof node.content === 'string' && node.content.indexOf('||') >= 0) {
      for (const p of splitPipeOrder(node.content)) {
        if (!seen.has(p)) { seen.add(p); results.push(p); }
      }
      if (results.length) return;
    }
    if (Array.isArray(node.children)) for (const c of node.children) walk(c, depth + 1);
  };
  try { walk(root, 0); } catch (_) {}
  return results;
}

// Từ HTML đã giải mã: <li> trong ol.quiz-list / ul.quiz-list chứa "||".
function extractPipeOrderFromHtml(html) {
  if (!html || isGarbageText(html)) return [];
  // SECURITY: div detached, chỉ đọc textContent — không append vào DOM.
  const div = document.createElement('div');
  div.innerHTML = html;
  const results = [];
  const seen = new Set();
  let lis = [];
  try { lis = Array.from(div.querySelectorAll('li,td,p,div')); } catch (_) {}
  for (const el of lis.slice(0, 300)) {
    // Bỏ qua node cha đã chứa node con cùng đáp án (tránh lặp).
    if (el.querySelector && el.querySelector('li,td')) continue;
    const parts = splitPipeOrder(el.textContent);
    if (!parts.length) continue;
    for (const p of parts) if (!seen.has(p)) { seen.add(p); results.push(p); }
    if (results.length) break;
  }
  return results;
}

// ── Extract đáp án dạng worksheet tiếng Anh từ JSON tree ────────────────
// Xử lý: word form, gap fill, sentence reorder, matching pairs
function extractEnglishWorksheetAnswers(root) {
  if (!root || typeof root !== 'object') return [];
  const results = [];
  const seen = new Set();

  function push(slot, answer) {
    const t = cleanMathText(normText(String(answer || '')));
    if (!t || seen.has(t)) return;
    seen.add(t);
    results.push({ slot, answer: t });
  }

  function walk(node, depth) {
    if (!node || typeof node !== 'object' || depth > 30) return;
    if (Array.isArray(node)) { node.forEach(n => walk(n, depth + 1)); return; }

    const t = (node.type || '').toLowerCase();

    // Word form / cloze / gap-fill nodes (bao gồm fillme-input của OLM)
    if (/fillme|word.?form|gap.?fill|cloze|fill.?blank|input/.test(t)) {
      const ans = node.correctAnswer || node.correct_answer || node.answer
               || node.content || node.word || node.form || node.value || node.text;
      if (ans) { push(results.length + 1, ans); return; }
    }

    // Sentence reorder
    if (/reorder|rearrange|sort/.test(t) && Array.isArray(node.correctOrder || node.order)) {
      const order = node.correctOrder || node.order;
      const items = node.items || node.sentences || node.words || [];
      order.forEach((idx, i) => {
        const raw = idx != null ? String(idx).trim() : '';
        if (!raw) return;
        // idx là số → index vào items, KHÔNG phải text đáp án
        if (/^\d+$/.test(raw)) {
          const it = Array.isArray(items) ? items[Number(raw)] : null;
          const txt = it == null ? ''
            : (typeof it === 'string' ? it : (it.text || it.content || it.label || ''));
          if (txt) push(i + 1, txt);
          return; // không tra được → bỏ, không in số thô
        }
        const t = Array.isArray(items) ? (items[Number(raw)] ?? raw) : raw;
        if (t) push(i + 1, t);
      });
      return;
    }

    // Matching pairs (tiếng Anh)
    if (/match|pair/.test(t) && node.left != null && node.right != null) {
      push(results.length + 1, `${node.left} → ${node.right}`);
      return;
    }

    // Word bank / options với correct flag
    if ((node.correct === true || node.isCorrect === true) && node.word) {
      push(results.length + 1, node.word);
      return;
    }

    // Recurse
    if (Array.isArray(node.children)) node.children.forEach(c => walk(c, depth + 1));
    for (const k of Object.keys(node)) {
      if (k === 'children' || k === 'parent' || k === '__ob__') continue;
      const v = node[k];
      if (v && typeof v === 'object') walk(v, depth + 1);
    }
  }

  walk(root, 0);
  return results;
}

function collectCorrectTextsFromJsonTree(node, out, textSeen, visited) {
  if (node == null || out.length > 50) return;
  if (typeof node === 'object' && node !== null) { if (visited.has(node)) return; visited.add(node); }
  if (typeof node === 'string' || typeof node === 'number') return;
  if (Array.isArray(node)) { node.forEach(ch => collectCorrectTextsFromJsonTree(ch, out, textSeen, visited)); return; }
  if (typeof node !== 'object') return;
  const markCorrect = node.correct === true || node.isCorrect === true || node.is_correct === true || node.dung === true || node.type === 'correct';
  if (markCorrect) {
    // FIX v1.3.2: thêm node.equation / node.latex (Lexical equation nodes không có text)
    const parts = [node.text, node.label, node.content, node.value, node.title, node.html, node.equation, node.latex]
      .filter(v => v != null && String(v).trim()).map(v => String(v).trim());
    let s = parts.join(' ').trim();
    if (!s && (node.type === 'olm-list-item' || !parts.length)) s = normText(lexicalPlainText(node));
    if (s && !textSeen.has(s)) { textSeen.add(s); out.push(s); }
  }
  if (!markCorrect && node.correctAnswer != null) {
    const vals = Array.isArray(node.correctAnswer) ? node.correctAnswer : [node.correctAnswer];
    vals.forEach(v => { const s = normText(String(v || '')); if (s && s !== '.' && !textSeen.has(s)) { textSeen.add(s); out.push(s); } });
  }
  if (Array.isArray(node.options)) node.options.forEach(opt => {
    if (opt && (opt.correct === true || opt.isCorrect === true)) collectCorrectTextsFromJsonTree(opt, out, textSeen, visited);
  });
  for (const k of Object.keys(node)) {
    if (k === 'parent' || k === '__ob__') continue;
    const ch = node[k]; if (ch && typeof ch === 'object') collectCorrectTextsFromJsonTree(ch, out, textSeen, visited);
  }
}

function collectAnswersFromJsonLoose(node, out, textSeen, depth) {
  if (node == null || depth > 28 || out.length > 100) return;
  if (typeof node === 'string' || typeof node === 'number') return;
  if (Array.isArray(node)) {
    node.forEach(item => {
      if (item && typeof item === 'object') {
        const L = item.left != null ? String(item.left).trim() : '';
        const R = item.right != null ? String(item.right).trim() : '';
        if (L && R) { const line = L + ' ↔ ' + R; if (!textSeen.has(line)) { textSeen.add(line); out.push(line); } }
        const a = item.a != null ? String(item.a).trim() : ''; const b = item.b != null ? String(item.b).trim() : '';
        if (a && b && !item.left) { const line = a + ' ↔ ' + b; if (!textSeen.has(line)) { textSeen.add(line); out.push(line); } }
      }
      collectAnswersFromJsonLoose(item, out, textSeen, depth+1);
    }); return;
  }
  if (typeof node !== 'object') return;
  for (const k of Object.keys(node)) {
    if (k === 'parent' || k === '__ob__') continue;
    const v = node[k];
    // ── Sửa lỗi sinh danh sách "1. 1 / 2. 2 / ... / 999. 999" ──
    // Trước đây: /^(correctorder|rightorder|order|keys)$/i khớp MỌI property
    // tên "keys"/"order" rồi đánh số thẳng giá trị thô. Với một node có
    // keys:[1..999] (id/index list, không phải đáp án) → ra 999 dòng
    // "1. 1" … "999. 999".
    //
    // Sửa đúng bản chất, KHÔNG dùng filter "loại số":
    //  1) Chỉ nhận field mang nghĩa "thứ tự đáp án" (correctOrder/rightOrder).
    //     Bỏ `keys` và `order` trần vì đó là tên property phổ biến, không
    //     phải khoá đáp án.
    //  2) Giá trị số trong field thứ tự là INDEX, không phải text đáp án →
    //     phải tra text thật trong mảng item của cùng node. Không tra được
    //     thì bỏ, tuyệt đối không in số thô.
    if (Array.isArray(v) && /^(correctorder|rightorder|correctanswerorder)$/i.test(k)) {
      const items = node.items || node.sentences || node.words || node.options
                 || node.choices || node.parts || node.answers || node.list || node.children;
      v.forEach((x, i) => {
        const raw = x != null ? String(x).trim() : '';
        if (!raw) return;
        // x là index (số) → tra text trong items cùng node
        if (/^\d+$/.test(raw)) {
          const idx = Number(raw);
          const it = Array.isArray(items) ? items[idx] : null;
          const txt = it == null ? ''
            : (typeof it === 'string' ? it
              : (it.text ?? it.content ?? it.label ?? it.value ?? it.title ?? ''));
          const t = txt ? normText(String(txt)) : '';
          if (t && !textSeen.has(t)) { textSeen.add(t); out.push(`${i + 1}. ${t}`); }
          return; // không có text để tra → bỏ, KHÔNG in index thô
        }
        // x đã là text → dùng trực tiếp (đáp án thứ tự dạng chuỗi)
        if (!textSeen.has(raw)) { textSeen.add(raw); out.push(`${i + 1}. ${raw}`); }
      });
    }
    if (v && typeof v === 'object') collectAnswersFromJsonLoose(v, out, textSeen, depth+1);
  }
}

function collectLexicalGroupListStructure(node, out, textSeen, depth, visited) {
  if (depth > 28 || out.length > 25 || !node || typeof node !== 'object') return;
  if (!visited) visited = new WeakSet();
  if (visited.has(node)) return; visited.add(node);
  if (node.type === 'olm-list' && node.name === 'group-list' && Array.isArray(node.children)) {
    const lines = [];
    for (const item of node.children) {
      if (!item || item.type !== 'olm-list-item') continue;
      const children = item.children || []; let title = ''; const pieces = [];
      for (const c of children) {
        if (c.type === 'group-title' && typeof c.text === 'string') title = normText(c.text);
        else if (c.type === 'position-column' && c.position === 'group') { const t = normText(lexicalPlainText(c)); if (t) pieces.push(t); }
      }
      if (title || pieces.length) {
        const line = title ? `${cleanMathText(title)} — ${pieces.map(cleanMathText).join(', ')}` : pieces.map(cleanMathText).join(', ');
        const norm = normText(line); if (norm) lines.push(norm);
      }
    }
    if (lines.length) {
      const block = '[Cấu trúc nhóm]\n' + lines.join('\n');
      if (!textSeen.has(block)) { textSeen.add(block); out.push(block); }
    }
  }
  if (Array.isArray(node.children)) node.children.forEach(ch => collectLexicalGroupListStructure(ch, out, textSeen, depth+1, visited));
  for (const k of Object.keys(node)) {
    if (k === 'children' || k === 'parent') continue;
    const v = node[k]; if (v && typeof v === 'object') collectLexicalGroupListStructure(v, out, textSeen, depth+1, visited);
  }
}

function collectLexicalPipePairRows(node, out, textSeen, depth) {
  if (depth > 28 || out.length > 40 || !node || typeof node !== 'object') return;
  if (node.type === 'olm-list-item') {
    const raw = normText(lexicalPlainText(node));
    if (raw && /\|\|/.test(raw) && raw.indexOf('↔') === -1) {
      const segs = raw.split('||').map(x => normText(x)).filter(Boolean);
      if (segs.length === 2) { const line = segs[0] + ' ↔ ' + segs[1]; if (!textSeen.has(line)) { textSeen.add(line); out.push(line); } }
    }
  }
  if (Array.isArray(node.children)) node.children.forEach(ch => collectLexicalPipePairRows(ch, out, textSeen, depth+1));
  for (const k of Object.keys(node)) {
    if (k === 'children' || k === 'parent') continue;
    const v = node[k]; if (v && typeof v === 'object') collectLexicalPipePairRows(v, out, textSeen, depth+1);
  }
}

function sanitizeAnswerStrings(collected, question) {
  if (!collected || !collected.length) return [];

  // Lấy stem text từ json_content để so sánh (tránh in lại câu hỏi)
  const jsonTree = tryParseQuestionJsonTree(question);
  const stemText = normText(extractStemTextFromLexical(jsonTree) || question?.title || '');
  const stemWords = stemText.length > 15
    ? stemText.toLowerCase().replace(/\s+/g,' ').slice(0, 120)
    : '';

  const out = [];
  for (const s of collected) {
    const t = normText(String(s));
    if (!t || t.length > 1500) continue;
    // Bỏ chuỗi chỉ toàn dấu chấm câu / khoảng trắng
    if (/^[.\s,;:!?·\-–—]+$/.test(t)) continue;
    // Bỏ ký tự đơn không phải chữ/số
    if (t.length === 1 && !/[\w\dÀ-ỹ]/.test(t)) continue;
    // Bỏ nếu đáp án chứa lại stem câu hỏi (80% trở lên)
    if (stemWords.length > 15) {
      const tLow = t.toLowerCase().replace(/\s+/g,' ');
      if (tLow.includes(stemWords) || stemWords.includes(tLow.slice(0, 80))) continue;
    }
    // Bỏ nếu là đúng 1 dấu chấm
    if (t === '.') continue;
    out.push(t);
  }

  // Heuristic: 4 đáp án dài tương đương nhau → thường là 4 lựa chọn A/B/C/D
  // không phải đáp án đúng → bỏ toàn bộ
  if (out.length === 4 && out.every(x => !x.includes('↔'))) {
    const lens = out.map(x => x.length);
    const avg = lens.reduce((a,b) => a+b, 0) / lens.length;
    if (avg > 25 && avg < 400 && lens.every(x => Math.abs(x - avg) < avg * 0.65)) return [];
  }
  return out;
}

function extractStructuredAnswersFromHtml(root) {
  if (!root || !root.querySelectorAll) return [];
  const parts = []; const seen = new Set();
  const push = (s) => { const t = normText(s); if (t && !seen.has(t)) { seen.add(t); parts.push(t); } };
  try { root.querySelectorAll('input[data-accept], textarea[data-accept]').forEach(inp => { (inp.getAttribute('data-accept')||'').split('|').forEach(push); }); } catch (_) {}
  try { root.querySelectorAll('[data-solution], [data-dap-an]').forEach(el => { const t = el.textContent || el.getAttribute('data-solution') || el.getAttribute('data-dap-an'); if (t) push(t); }); } catch (_) {}
  return parts;
}

// [REMOTE-CONFIG] Danh sách selector loại bỏ khỏi phần câu hỏi khi hiển thị.
// Nâng lên module scope để applyRemoteConfig() có thể thay bằng giá trị đã validate.
let STRIP_DISPLAY_SEL = [
  'ol.quiz-list','ul.quiz-list','.quiz-list','.interaction','.form-group',
  '.loigiai','.huong-dan-giai','.explain','.solution','#solution','.guide','.exp',
  '.quiz-option','.quiz-item','.quiz-answer','.q-option','.answer-option',
  '.ds-dapan','.list-dapan','.list-group-item',
  '[class*="quiz-option"]','[class*="quiz_item"]','[class*="answer-list"]','[class*="list-answer"]',
  '[class*="match"]','[class*="ghep"]','[class*="pair-list"]','[class*="drag-drop"]',
  '[class*="olm-match"]','.cau-ghep-noi','.match-quiz',
].join(',');

function stripQuestionDisplayElements(root) {
  if (!root || !root.querySelectorAll) return;
  // Gộp tất cả selector vào 1 lần querySelectorAll duy nhất.
  try { root.querySelectorAll(STRIP_DISPLAY_SEL).forEach(el => { try { el.remove(); } catch(_){} }); } catch(_) {}
  // Radio/checkbox — xóa wrapper
  try {
    root.querySelectorAll('input[type="radio"],input[type="checkbox"]').forEach(inp => {
      const el = inp.closest('label') || inp.closest('li') || inp.closest('.form-check')
               || inp.closest('[class*="option"]') || inp.parentElement;
      if (el && el !== root) { try { el.remove(); } catch(_){} }
    });
  } catch(_) {}
}

function extractAnswersFromDomForQuestion(question) {
  // ── Đường 1: UI cũ (block có attribute id) ──
  const block = findQuestionBlockInPage(question);
  if (block) {
    const built = buildAnswerUlFromBlock(block);
    if (built) return built;
  }
  // ── Đường 2: UI MỚI — nội dung nằm trong shadowRoot của <default-root>
  // (đã kiểm chứng). Không có data-id nào ở đây nên bản cũ luôn trả null
  // → panel rơi về "null — no answer found" với toàn bộ câu Toán.
  try {
    const hosts = getQuizHosts(300);
    for (const h of hosts) {
      const opts = h.options || [];
      if (!opts.length) continue;
      const picked = opts.filter(o => o.correct);
      const use = picked.length ? picked : opts;
      const ul = document.createElement('ul');
      use.slice(0, 20).forEach(o => {
        const li = document.createElement('li');
        setAnswerText(li, o.text);
        ul.appendChild(li);
      });
      if (ul.children.length) {
        TRACE.step(question, {
          source: 'page DOM (shadow root quiz host)', field: h.kind === 'tf' ? 'tf-row.xcorrect' : '.qselect.correctq',
          parser: 'quiz-host scan', math: 'mathTextToHtml',
          final: use.slice(0, 20).map(o => o.text),
        });
        return ul;
      }
    }
  } catch (_) {}
  return null;
}

// Gom option đúng trong 1 block của UI cũ thành <ul> (sanitize trước khi trả).
function buildAnswerUlFromBlock(block) {
  if (!block || !block.querySelectorAll) return null;
  let els = querySelectorAllDeep(block, ANSWER_DOM_SELECTORS);
  if (!els.length) { try { els = Array.from(block.querySelectorAll(ANSWER_DOM_SELECTORS)); } catch (_) { els = []; } }
  els = els.filter(el => !el.closest('#olm-answers-container') && !el.closest('#olm-panel-root'));
  if (els.length) {
    const ul = document.createElement('ul');
    // SECURITY: DOM từ trang OLM không phải trusted — clone rồi sanitize
    // subtree (xóa event handler, validate src/href) mới append vào panel.
    els.slice(0, 20).forEach(ans => {
      const li = document.createElement('li');
      ans.childNodes.forEach(n => { const sc = sanitizeClone(n); if (sc) li.appendChild(sc); });
      ul.appendChild(li);
    });
    sanitizeSubtree(ul);
    if (ul.children.length) return ul;
  }
  const fillAll = block.querySelectorAll ? block.querySelectorAll('input[data-accept], textarea[data-accept]') : [];
  if (fillAll.length) {
    const ul = document.createElement('ul');
    Array.from(fillAll).forEach(inp => { (inp.getAttribute('data-accept')||'').split('|').forEach(a => { const t = a.trim(); if (!t) return; const li = document.createElement('li'); li.textContent = t; ul.appendChild(li); }); });
    if (ul.children.length) return ul;
  }
  const ddSelectors = ['[data-answer]','[data-blank-answer]','input[data-correct]','span[data-answer]','.drag-result span','.drop-result span','.blank-filled','.slot-filled'];
  const ddList = document.createElement('ul'); let ddIdx = 0;
  for (const sel of ddSelectors) {
    try {
      const els2 = Array.from(block.querySelectorAll(sel)).filter(el => !el.closest('#olm-answers-container') && !el.closest('#olm-panel-root'));
      if (els2.length) {
        els2.forEach(el => { ddIdx++; const ans = el.getAttribute('data-answer') || el.getAttribute('data-blank-answer') || el.getAttribute('data-correct') || el.textContent.trim(); if (ans) { const li = document.createElement('li'); li.textContent = `Chỗ ${ddIdx}: ${cleanMathText(ans)}`; ddList.appendChild(li); } });
        if (ddList.children.length) return ddList; break;
      }
    } catch (_) {}
  }
  return null;
}

// ── Detect loại câu hỏi từ json_content hoặc API fields ──────────────────
function detectQuestionType(question, jsonTree) {
  // 0. Dạng xếp câu / xếp từ: đáp án gói trong 1 chuỗi "a||b||c" (type-advance).
  // Phải kiểm TRƯỚC mọi nhánh khác vì q_type=20 và title="order N" không rơi
  // vào regex nào, còn json tree lại có olm-list singlechoice (dễ nhầm MC).
  if (question && typeof question.html === 'string' && /\|\|/.test(question.html)) return 'order';
  if (question && typeof question.content === 'string') {
    try { if (extractPipeOrderFromHtml(decodeSync(question.content) || '').length) return 'order'; } catch (_) {}
  }
  if (jsonTree) {
    const rt0 = jsonTree.root ?? jsonTree;
    try { if (extractPipeOrderAnswers(rt0).length) return 'order'; } catch (_) {}
  }

  // 1. Từ field type/question_type
  const raw = (question.type || question.question_type || question.kind || '').toLowerCase();
  if (/\bmultiple.?choice\b|single.?choice|trac.?nghiem|mc\b/.test(raw)) return 'mc';
  if (/\btrue.?false\b|dung.?sai|tf\b/.test(raw)) return 'tf';
  if (/\bfill|blank|dien.?vao|short.?answer|gap.?fill|word.?form|cloze/.test(raw)) return 'fill';
  if (/\bmatch|ghep.?noi|pair|matching/.test(raw)) return 'match';
  if (/\border|sap.?xep|sort|reorder|rearrang/.test(raw)) return 'order';
  if (/\bessay|tu.?luan|open|writing/.test(raw)) return 'essay';

  // 2. Từ json_content (Lexical tree)
  if (jsonTree) {
    const rootNode = jsonTree.root ?? jsonTree;
    const listNode = Array.isArray(rootNode?.children)
      ? rootNode.children.find(c => c?.type === 'olm-list')
      : null;
    if (listNode) {
      const ltype = (listNode.listType || listNode.name || '').toLowerCase();
      if (/true.?false|dung.?sai/.test(ltype)) return 'tf';
      if (/match|ghep/.test(ltype)) return 'match';
      if (/order|sort/.test(ltype)) return 'order';
      if (/fill|blank|dien/.test(ltype)) return 'fill';
      if (/group/.test(ltype)) return 'match';
      return 'mc';
    }
    // Walk nhẹ thay vì JSON.stringify toàn tree
    function _hasNodeType(node, re, depth) {
      if (!node || depth > 6) return false;
      if (re.test(node.type || '')) return true;
      if (Array.isArray(node.children)) {
        for (const c of node.children) { if (_hasNodeType(c, re, depth + 1)) return true; }
      }
      return false;
    }
    const inputRe = /olm-input|math-input|short-answer|gap-fill|word-form|cloze/;
    const orderRe = /reorder|rearrange|sort-sentence/;
    if (_hasNodeType(rootNode, inputRe, 0)) return 'fill';
    if (_hasNodeType(rootNode, orderRe, 0)) return 'order';
  }

  // 3. Từ answers array
  const arr = question.answers || question.options || [];
  if (Array.isArray(arr) && arr.length) return 'mc';

  // 4. Field trực tiếp
  if (question.answer != null || question.correct_answer != null) return 'fill';

  return 'unknown';
}

// [REMOTE-CONFIG] let — nhãn có thể thay bằng giá trị đã validate từ xa.
let QTYPE_LABEL = {
  mc:      { text: 'Trắc nghiệm',        cls: 'olm-qtype-mc'    },
  tf:      { text: 'Đúng / Sai',         cls: 'olm-qtype-tf'    },
  fill:    { text: 'Điền / Word Form',    cls: 'olm-qtype-fill'  },
  match:   { text: 'Ghép nối / Matching', cls: 'olm-qtype-match' },
  order:   { text: 'Sắp xếp / Reorder',  cls: 'olm-qtype-order' },
  essay:   { text: 'Tự luận / Writing',  cls: 'olm-qtype-essay' },
  unknown: { text: '?',                  cls: 'olm-qtype-mc'    },
};

// getAnswersAsDOM — ASYNC để có thể gọi vueDecodeAsync
async function getAnswersAsDOM(question, decodedHtml) {
  const plain = extractAnswersFromPlainApiFields(question);
  if (plain) return plain;

  // ── DẠNG XẾP CÂU / XẾP TỪ: đáp án "It||can||be||…" ──
  // Đặt ĐẦU hàm, trước mọi extractor khác, vì "||" là dấu hiệu gần như
  // không trùng nhầm và phải thắng trước các extractor dựa correct:true /
  // olm-list (node list-item của dạng này có correct:false nên chúng trượt,
  // nhưng "loose" collector thì không).
  // Dấu hiệu triệu chứng khi thiếu nhánh này: panel gắn nhãn
  // "SẮP XẾP / REORDER" nhưng chỉ hiện "// SOLUTION" (bản dịch tiếng Việt).
  {
    const pipeSources = [];
    if (decodedHtml != null && !isGarbageText(decodedHtml)) pipeSources.push(decodedHtml);
    if (question && typeof question.html === 'string' && !isGarbageText(question.html)) pipeSources.push(question.html);
    if (question && typeof question.html_i18n === 'string' && /\|\|/.test(question.html_i18n)) pipeSources.push(question.html_i18n);
    if (question && typeof question.content === 'string' && /\|\|/.test(question.content)) {
      let dec = null;
      try { dec = decodeSync(question.content); } catch (_) {}
      if (dec && !isGarbageText(dec)) pipeSources.push(dec);
    }
    for (const srcHtml of pipeSources) {
      const pipeAnswers = extractPipeOrderFromHtml(srcHtml);
      if (!pipeAnswers.length) continue;
      const ul = document.createElement('ul');
      pipeAnswers.forEach(word => { const li = document.createElement('li'); setAnswerText(li, word); ul.appendChild(li); });
      TRACE.step(question, {
        source: 'html (dạng order)', field: 'li chứa "||"',
        raw: pipeAnswers.join('||'), parser: 'pipe-order', math: 'text', final: pipeAnswers,
      });
      return ul;
    }
  }

  const listElement = document.createElement('ul');
  const jsonData = tryParseQuestionJsonTree(question);
  if (jsonData) {
    try {
      const rootNode = jsonData.root != null ? jsonData.root : jsonData;

      // True/False
      const tfAnswers = extractTrueFalseAnswers(rootNode);
      if (tfAnswers.length) {
        tfAnswers.forEach(({ text, correct }) => {
          const li = document.createElement('li');
          const label = correct === true ? '✔ Đúng' : correct === false ? '✘ Sai' : '?';
          li.textContent = `[${label}] ${cleanMathText(text)}`;
          li.style.color = correct === true ? '#bf5fff' : correct === false ? '#ff4444' : 'rgba(var(--olm-accent-rgb),0.3)';
          listElement.appendChild(li);
        });
        TRACE.step(question, {
          source: 'json_content', field: 'isTrue|answer(bool)|correct(bool)',
          raw: rootNode, parser: 'true/false', math: 'cleanMathText',
          final: tfAnswers.map(a => cleanMathText(a.text)),
        });
        return listElement;
      }

      // Drag-drop từ JSON
      const ddAnswers = extractDragDropAnswers(rootNode);
      // Nếu không có từ JSON, yêu cầu Vue extract từ main world
      const vueDD = ddAnswers.length ? ddAnswers : await vueDecodeAsync(question);
      if (vueDD.length) {
        vueDD.forEach(({ slot, answer }) => {
          const li = document.createElement('li');
          // SECURITY: answer từ JSON/Vue (untrusted) đã escape qua mathTextToHtml,
          // route thêm qua sanitize để giữ formatting mà chặn event handler/URL xấu.
          const safeSlot = Number(slot) || 0;
          setSafeInnerHTML(li, `<span style="color:rgba(var(--olm-accent-rgb),0.6);font-size:10px;">[slot.${safeSlot}]</span> ${mathTextToHtml(String(answer || ''))}`);
          listElement.appendChild(li);
        });
        TRACE.step(question, {
          source: ddAnswers.length ? 'json_content' : 'Vue main-world bridge (injected.js)',
          field: 'drag/drop slots',
          raw: ddAnswers.length ? rootNode : '(from Vue)',
          parser: ddAnswers.length ? 'drag-drop (json)' : 'drag-drop (vue)',
          math: 'mathTextToHtml',
          final: vueDD.map(d => d.answer),
        });
        return listElement;
      }

      // Worksheet tiếng Anh (word form, gap fill, reorder, matching)
      const enAnswers = extractEnglishWorksheetAnswers(rootNode);
      if (enAnswers.length) {
        enAnswers.forEach(({ slot, answer }) => {
          const li = document.createElement('li');
          // SECURITY: như trên — answer từ worksheet JSON là untrusted.
          const safeSlot = Number(slot) || 0;
          setSafeInnerHTML(li, `<span style="color:rgba(255,165,0,0.6);font-size:10px;">[${safeSlot}]</span> ${mathTextToHtml(String(answer || ''))}`);
          listElement.appendChild(li);
        });
        TRACE.step(question, {
          source: 'json_content', field: 'worksheet nodes (fillme/wordform/match/reorder)',
          raw: rootNode, parser: 'english worksheet', math: 'mathTextToHtml',
          final: enAnswers.map(a => a.answer),
        });
        return listElement;
      }

      // Dạng XẾP CÂU / XẾP TỪ (type-advance, q_type "order", title "order N").
      // OLM gói đáp án vào 1 node text duy nhất phân tách bằng "||":
      //   root[2]/olm-list[0]/olm-list-item[0]/extended-text
      //     = "It||can||be||tough||when||your family||doesn't fully||…"
      // (đã kiểm chứng trên olm.vn, Câu 27 "Looking back" 2026-10).
      // Node list-item này có correct:false nên mọi extractor based correct:true
      // đều trượt → trước đây panel rơi về nhánh "// SOLUTION" (bản dịch tiếng Việt)
      // và highlight không có gì để tô.
      const pipeAnswers = extractPipeOrderAnswers(rootNode);
      if (pipeAnswers.length) {
        pipeAnswers.forEach(word => {
          const li = document.createElement('li');
          setAnswerText(li, word);
          listElement.appendChild(li);
        });
        TRACE.step(question, {
          source: 'json_content', field: 'olm-list-item text chứa "||" (dạng order)',
          raw: pipeAnswers.join('||'), parser: 'pipe-order', math: 'text',
          final: pipeAnswers,
        });
        return listElement;
      }

      // Trắc nghiệm / ghép / nhóm
      const collected = []; const textSeen = new Set(); const visited = new WeakSet();
      collectCorrectTextsFromJsonTree(rootNode, collected, textSeen, visited);
      collectAnswersFromJsonLoose(rootNode, collected, textSeen, 0);
      let sanitized = sanitizeAnswerStrings(collected, question);
      if (!sanitized.length) {
        const hSeen = new Set(); const hints = [];
        collectLexicalGroupListStructure(rootNode, hints, hSeen, 0);
        sanitized = sanitizeAnswerStrings(hints, question);
      }
      if (!sanitized.length) {
        const hSeen = new Set(); const hints = [];
        collectLexicalPipePairRows(rootNode, hints, hSeen, 0);
        sanitized = sanitizeAnswerStrings(hints, question);
      }
      if (sanitized.length) {
        sanitized.forEach(text => { const li = document.createElement('li'); setAnswerText(li, text); listElement.appendChild(li); });
        TRACE.step(question, {
          source: 'json_content', field: 'collectCorrectTexts + collectAnswersLoose',
          raw: collected, parser: 'json tree', sanitized: sanitized, final: sanitized,
        });
        return listElement;
      }
      // Fallback: tìm node correct đầu tiên
      const findCorrect = (n) => {
        if (!n) return null;
        if (n.correct === true || n.isCorrect === true) return n;
        if (n.children) { for (const c of n.children) { const f = findCorrect(c); if (f) return f; } }
        return null;
      };
      const correctNode = findCorrect(rootNode);
      if (correctNode) {
        const answerText = normText(lexicalPlainText(correctNode));
        if (answerText) { const li = document.createElement('li'); setAnswerText(li, answerText); listElement.appendChild(li); return listElement; }
      }
    } catch (e) { L.err('JSON extraction error:', e); }
  }

  // HTML-based extraction
  const html = decodedHtml != null ? decodedHtml : decodeSync(question.content || '');
  if (!html || isGarbageText(html)) {
    // Không có decodedContent dùng được → thử question.html trước khi bỏ cuộc.
    const alt = question && typeof question.html === 'string' ? question.html : '';
    if (!alt || isGarbageText(alt)) return null;
    const ddAlt = extractDragDropFromHtml(alt);
    if (ddAlt.length) {
      ddAlt.forEach(({ slot, answer }) => { const li = document.createElement('li'); li.textContent = `Chỗ ${slot}: ${answer}`; listElement.appendChild(li); });
      return listElement;
    }
    return null;
  }

  // Drag-drop từ HTML
  const ddFromHtml = extractDragDropFromHtml(html);
  if (ddFromHtml.length) {
    ddFromHtml.forEach(({ slot, answer }) => { const li = document.createElement('li'); li.textContent = `Chỗ ${slot}: ${answer}`; listElement.appendChild(li); });
    return listElement;
  }

  // Dạng xếp câu: <ol class="quiz-list"><li>It||can||be||…</li></ol>
  // (ANSWER_DOM_SELECTORS không có selector nào khớp <li> trần nên nếu thiếu
  //  nhánh này thì panel rơi xuống getSolutionAsDOM và chỉ hiện bản dịch.)
  const pipeHtml = extractPipeOrderFromHtml(html);
  if (pipeHtml.length) {
    pipeHtml.forEach(word => { const li = document.createElement('li'); setAnswerText(li, word); listElement.appendChild(li); });
    TRACE.step(question, {
      source: 'decoded HTML (question.content)', field: 'li chứa "||" (dạng order)',
      raw: pipeHtml.join('||'), parser: 'pipe-order (html)', math: 'text', final: pipeHtml,
    });
    return listElement;
  }

  const tempDiv = document.createElement('div');
  // SECURITY: detached parse only — không append tempDiv vào DOM.
  // Mọi node đưa vào panel bên dưới đều qua sanitizeClone/sanitize.
  tempDiv.innerHTML = html;
  const correctAnswers = tempDiv.querySelectorAll(ANSWER_DOM_SELECTORS);
  if (correctAnswers.length > 0) {
    // FIX v1.3.2: clone raw giữ nguyên <span class="math-tex">\(...\)</span> / $...$ chưa render
    // → panel hiện raw latex ("lỗi math text") và plainOf() mismatch → highlight fail.
    // Nếu đáp án có media (img/table/...) thì giữ clone để không mất hình,
    // ngược lại render qua mathTextToHtml để có data-plain chuẩn cho highlight.
    correctAnswers.forEach(ans => {
      const li = document.createElement('li');
      const hasMedia = ans.querySelector && ans.querySelector('img,table');
      const rawHtml = ans.innerHTML || '';
      const looksMath = /math-tex|katex|\\\(|\\\[|\$\$|\$|\\frac|\\sqrt|\\[a-zA-Z]+/.test(rawHtml + ' ' + (ans.textContent || ''));
      if (!hasMedia && looksMath) {
        setAnswerText(li, (ans.textContent || '').trim());
      } else if (!hasMedia) {
        setAnswerText(li, (ans.textContent || '').trim());
      } else {
        // SECURITY: clone từ decoded HTML (untrusted) → sanitize từng node,
        // validate img src/href, xóa event handler.
        ans.childNodes.forEach(n => { const sc = sanitizeClone(n); if (sc) li.appendChild(sc); });
        sanitizeSubtree(li);
      }
      listElement.appendChild(li);
    });
    TRACE.step(question, {
      source: 'decoded HTML (question.content)', field: 'ANSWER_DOM_SELECTORS',
      raw: html, parser: 'html selector', final: Array.from(correctAnswers).map(a => a.textContent.trim()),
    });
    return listElement;
  }
  const fillInputs = tempDiv.querySelectorAll('input[data-accept], textarea[data-accept]');
  if (fillInputs.length) {
    fillInputs.forEach(inp => { (inp.getAttribute('data-accept')||'').split('|').forEach(a => { const t = a.trim(); if (!t) return; const li = document.createElement('li'); setAnswerText(li, t); listElement.appendChild(li); }); });
    if (listElement.children.length) return listElement;
  }
  const structured = extractStructuredAnswersFromHtml(tempDiv);
  if (structured.length) {
    structured.forEach(text => { const li = document.createElement('li'); setAnswerText(li, text); listElement.appendChild(li); });
    TRACE.step(question, {
      source: 'decoded HTML (question.content)', field: 'data-accept|data-solution|data-dap-an',
      raw: html, parser: 'structured html', sanitized: structured, final: structured,
    });
    return listElement;
  }
  TRACE.step(question, {
    source: '(none)', parser: 'all extractors failed',
    raw: html, note: 'no answer produced — plain API null, json tree empty, html selectors empty',
    final: [],
  });
  return null;
}

function getSolutionAsDOM(decodedContent) {
  if (!decodedContent || isGarbageText(decodedContent)) return null;
  if (String(decodedContent).length > SEC_LIMITS.MAX_HTML_BYTES) return null;
  // SECURITY: detached parse only. Clone trả về đã được sanitize.
  const tempDiv = document.createElement('div'); tempDiv.innerHTML = decodedContent;
  const solSel = '.loigiai,.huong-dan-giai,.explain,.solution,#solution,.guide,.exp,.exp-in,.giai,.huong-dan,.cach-giai,[class*="solution"],[class*="loigiai"],[class*="explain"],[class*="huong-dan"],.answer-explanation,.result-explain';
  const solutionNode = tempDiv.querySelector(solSel);
  if (solutionNode) {
    const clone = sanitizeClone(solutionNode);
    if (!clone) return null;
    try { clone.querySelectorAll('h3,h4').forEach(h => h.remove()); } catch (_) {}
    sanitizeSubtree(clone);
    return clone;
  }
  const clone = sanitizeClone(tempDiv);
  if (!clone) return null;
  try { clone.querySelectorAll('ol.quiz-list,ul.quiz-list,.quiz-list,.interaction,input[type=radio],input[type=checkbox],.form-group,button,.quiz-option,.answer-option,[class*="quiz-option"]').forEach(el => el.remove()); } catch (_) {}
  sanitizeSubtree(clone);
  const text = (clone.textContent || '').trim();
  return text.length > 10 ? clone : null;
}

// ============================================================
// FIX v1.3.2: correct ORIGINAL indices cho QuizX (trắc nghiệm OLM)
// ------------------------------------------------------------
// Vấn đề: câu hỏi tham số (@p.da[p.t]@ + code p.t=random/shuffle) — API trả
// template, trang render giá trị cụ thể (vd 5√6/2) + shuffle thứ tự option.
// Ext cũ chỉ match TEXT → template "@p.da[p.t]@" vs "5√6/2" không bao giờ khớp
// → "highlight lỗi". Nhưng qlib.js giữ nguyên original index ở
//   <div class="qselect" data-ind="<origIdx>">
// và API cho biết origIdx nào đúng (li.correctAnswer / json correct:true).
// Vì vậy highlight đúng phải ưu tiên match data-ind, không phụ thuộc text.
// ============================================================
// FIX v1.3.6: correct indices THEO TỪNG sub-list (câu nhiều ý).
// getCorrectOriginalIndices cũ chỉ đọc olm-list ĐẦU TIÊN (find) rồi applyOne
// áp index đó cho CẢ block → tô lem sang tiểu câu khác (vd vệt sáng thừa ở
// Câu 1 Anh). Hàm mới trả về mảng-nhóm: groups[i] = indices đúng của list thứ i,
// applyOne áp groups[i] CHỈ trong <ol> thứ i của block.
function getCorrectIndexGroups(question, decodedHtml) {
  const groups = [];
  try {
    const tree = tryParseQuestionJsonTree(question);
    const rootNode = tree && (tree.root != null ? tree.root : tree);
    const lists = rootNode && Array.isArray(rootNode.children)
      ? rootNode.children.filter(c => c && c.type === 'olm-list' && Array.isArray(c.children))
      : [];
    for (const listNode of lists) {
      const g = [];
      listNode.children.forEach((item, idx) => {
        if (item && (item.correct === true || item.isCorrect === true || item.is_correct === true)) {
          g.push(String(idx));
        }
      });
      if (g.length) groups.push(g);
    }
    if (groups.length) return groups;
  } catch (_) {}
  try {
    const html = decodedHtml != null ? decodedHtml : decodeSync(question.content || '');
    if (html && !isGarbageText(html)) {
      // SECURITY: detached parse only để đọc index, không append vào DOM.
      const d = document.createElement('div');
      d.innerHTML = html;
      const lists = d.querySelectorAll('ol.quiz-list, ul.quiz-list, .quiz-list, ol, ul');
      for (const list of lists) {
        const lis = Array.from(list.children).filter(el => el && /^(LI|DIV)$/.test(el.tagName));
        if (!lis.length) continue;
        const g = [];
        lis.forEach((li, idx) => {
          try {
            if (li.classList && (li.classList.contains('correctAnswer') || li.classList.contains('correct-answer') || li.classList.contains('is-correct') || li.classList.contains('answer-correct'))) {
              g.push(String(idx));
            } else if (li.getAttribute && (li.getAttribute('data-correct') === 'true' || li.getAttribute('data-correct') === '1' || li.getAttribute('data-is-correct') === 'true')) {
              g.push(String(idx));
            }
          } catch (_) {}
        });
        if (g.length) groups.push(g);
      }
      if (groups.length) return groups;
    }
  } catch (_) {}
  return groups;
}

function getCorrectOriginalIndices(question, decodedHtml) {
  // Giữ API cũ cho callers hiện tại: gộp phẳng các nhóm per-list.
  // Logic chi tiết đã chuyển vào getCorrectIndexGroups (fix multi-ý v1.3.6).
  const flat = [];
  try {
    for (const g of getCorrectIndexGroups(question, decodedHtml)) {
      for (const v of g) if (!flat.includes(v)) flat.push(v);
    }
  } catch (_) {}
  return flat;
}

// ============================================================
// HIGHLIGHT ĐÁP ÁN (trang olm.vn + panel) — có nút bật/tắt
// ============================================================
const HIGHLIGHT_PAGE_CSS = `
  /* Câu hỏi chứa đáp án được tìm thấy */
  .olm-hl-block {
    box-shadow: inset 3px 0 0 0 rgba(var(--olm-hl1-rgb),.9) !important;
    background-color: rgba(var(--olm-hl1-rgb),.07) !important;
  }
  /* Option / trả lời đúng trên trang — PHÁT SÁNG */
  .olm-hl-hit {
    background-image: linear-gradient(180deg, rgba(var(--olm-hl1-rgb),.30), rgba(var(--olm-hl1-rgb),.15)) !important;
    background-color: rgba(var(--olm-hl1-rgb),.22) !important;
    outline: 3px solid rgba(var(--olm-hl1-rgb),.95) !important;
    outline-offset: 2px;
    border-radius: 8px !important;
    box-shadow: 0 0 18px rgba(var(--olm-hl1-rgb),.6), inset 0 0 12px rgba(var(--olm-hl1-rgb),.25) !important;
    animation:
      olm-hl-flash .9s ease-out 1,
      olm-hl-glow 1.6s ease-in-out .9s infinite !important;
  }
  /* Ô input cần điền đáp án */
  .olm-hl-input {
    background-color: rgba(var(--olm-hl1-rgb),.20) !important;
    outline: 3px dashed rgba(var(--olm-hl1-rgb),.95) !important;
    outline-offset: 2px;
    box-shadow: 0 0 18px rgba(var(--olm-hl1-rgb),.6) !important;
    animation:
      olm-hl-flash .9s ease-out 1,
      olm-hl-glow 1.6s ease-in-out .9s infinite !important;
  }
  /* Dạng xếp từ / xếp câu: chip rời thuộc câu đúng */
  .olm-hl-chip {
    background-image: linear-gradient(180deg, rgba(var(--olm-hl1-rgb),.34), rgba(var(--olm-hl1-rgb),.16)) !important;
    background-color: rgba(var(--olm-hl1-rgb),.24) !important;
    outline: 2px solid rgba(var(--olm-hl1-rgb),.92) !important;
    outline-offset: 1px;
    box-shadow: 0 0 14px rgba(var(--olm-hl1-rgb),.55) !important;
    animation: olm-hl-glow 1.6s ease-in-out infinite !important;
  }
  /* Badge số thứ tự đúng (1,2,3…) để người dùng xếp chip theo thứ tự này */
  .olm-hl-chip::after {
    content: attr(data-olm-order);
    position: absolute;
    top: -7px;
    left: -7px;
    min-width: 17px;
    height: 17px;
    padding: 0 3px;
    border-radius: 9px;
    background: rgba(var(--olm-hl1-rgb),.96);
    color: #04140a;
    font: 700 10px/17px system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;
    text-align: center;
    box-shadow: 0 0 8px rgba(var(--olm-hl1-rgb),.85);
    pointer-events: none;
    z-index: 3;
  }
  @keyframes olm-hl-flash {
    0%   { box-shadow: 0 0 0 8px rgba(var(--olm-hl1-rgb),.6); }
    100% { box-shadow: 0 0 18px rgba(var(--olm-hl1-rgb),.6), inset 0 0 12px rgba(var(--olm-hl1-rgb),.25); }
  }
  /* Pulse phát sáng nhẹ — chỉ chạy trên vài option được đánh dấu nên tốn rất ít */
  @keyframes olm-hl-glow {
    0%, 100% { box-shadow: 0 0 9px rgba(var(--olm-hl1-rgb),.35),  inset 0 0 8px  rgba(var(--olm-hl1-rgb),.18); }
    50%      { box-shadow: 0 0 26px rgba(var(--olm-hl1-rgb),.8),   inset 0 0 16px rgba(var(--olm-hl1-rgb),.35); }
  }
`;

// ────────────────────────────────────────────────────────────────────
// HOST TRẮC NGHIỆM / ĐÚNG-SAI ĐANG HIỂN THỊ (đã kiểm chứng trên olm.vn)
// ────────────────────────────────────────────────────────────────────
// UI mới của OLM (2026-10):
//   <default-root>                       Lit host, shadowRoot MỞ
//     └ shadowRoot
//         ├ <type-quiz-x>                trắc nghiệm, shadowRoot MỞ
//         │   #quiz-list > .answer-container.quiz-list > div.qselect[ind]
//         │     · ind = chỉ số option GỐC (trang shuffle thứ tự hiển thị)
//         │     · div.qselect.correctq = đáp án đúng
//         └ <type-true-fasle>             đúng/sai (typo của OLM), shadowRoot MỞ
//             #true-false > table > tr.tf-row
//               · td:first-child = nội dung mệnh đề
//               · td.tf-box > span.qiradio.xcorrect[ind] = nút Đúng đúng
//
// KHÔNG có data-id / data-id-quiz / data-ind ở bất kỳ đâu → toàn bộ logic
// cũ tìm block theo [data-id] và khớp [data-ind] là DEAD CODE.
// [REMOTE-CONFIG] Các hằng dưới đây là `let` (không phải const) để có thể thay
// bằng giá trị ĐÃ ĐƯỢC VALIDATE từ remote config — xem applyRemoteConfig().
// Mặc định = đúng giá trị hardcode của v1.3.12 (không đổi hành vi).
let QUIZ_HOST_SEL   = 'default-root';
// Regex đã COMPILE sẵn; khi remote config đổi pattern, applyRemoteConfig() dựng
// lại biến này (compile trong try/catch — lỗi thì giữ regex cũ).
let QUIZ_HOST_FALLBACK_RE = /quiz|question|true-fasle|true-false|advance|order|sort/i;
let QUIZ_HOST_FALLBACK_PATTERN = 'quiz|question|true-fasle|true-false|advance|order|sort';
let MC_OPTION_SEL   = '.qselect,[class*="qselect"]';
let TF_ROW_SEL      = 'tr.tf-row,.tf-row';
let MC_BLOCK_SEL    = '#quiz-list,.answer-container.quiz-list,.answer-container,.quiz-list,.previewquiz';
let TF_BLOCK_SEL    = '#true-false';
// ── UI cũ: block câu hỏi ──
// Đã kiểm chứng trên olm.vn (2026-10): block KHÔNG mang attribute id câu
// (`data-id*` không tồn tại) mà dùng id CỐ ĐỊNH `#question` / `.question`.
// Vì vậy selector cũ chỉ toàn `[data-id*]` là luôn trượt → UI cũ không bao
// giờ tìm được scope và applyOne bail ngay.
// `data-stt` là thuộc tính của thanh điều hướng câu (span 1..30) → loại.
let LEGACY_BLOCK_SEL = '[data-id-quiz],[data-id_quiz],[data-idquiz],[data-question-id],[data-idquestion],'
  + '[data-qid],[data-question],[data-questionid],[data-quiz]:not([data-stt]),'
  + '[data-quiz-id],[data-id]';
let LEGACY_ROOT_SEL = '#question,div.question';
let LEGACY_OPTION_SEL = '.qselect,.correctAnswer,[ind],[data-ind],li,td,label,[class*="option"],[class*="choice"]';

// Text thuần của 1 node lựa chọn — loại bỏ lớp KaTeX ẩn (mathml) và icon,
// để còn đúng những gì người dùng NHÌN THẤY (giống textContent của trang).
function visibleOptionText(el) {
  if (!el) return '';
  try {
    const c = el.cloneNode(true);
    c.querySelectorAll('.katex-mathml,.katex-html .strut,script,style,template,[aria-hidden="true"],[hidden]')
      .forEach(n => { try { n.remove(); } catch (_) {} });
    return normText(c.textContent || '');
  } catch (_) { return normText(el.textContent || ''); }
}

// Thu thập mọi shadowRoot bên trong 1 root (giới hạn sâu + rộng để nhẹ).
function shadowRootsWithin(root, maxDepth) {
  const out = [root];
  let frontier = [root];
  for (let d = 0; d < (maxDepth || 3) && frontier.length && out.length < 12; d++) {
    const add = [];
    for (const r of frontier) {
      let els = [];
      try { els = r.querySelectorAll('*'); } catch (_) { continue; }
      for (const el of els) {
        if (el.shadowRoot && out.indexOf(el.shadowRoot) < 0 && add.indexOf(el.shadowRoot) < 0) {
          add.push(el.shadowRoot);
          if (out.length + add.length >= 12) break;
        }
      }
    }
    if (!add.length) break;
    out.push(...add);
    frontier = add;
  }
  return out;
}

function isLitQuizHost(el) {
  const t = (el.tagName || '').toLowerCase();
  return t === QUIZ_HOST_SEL || (t.includes('-') && QUIZ_HOST_FALLBACK_RE.test(t));
}

// ============================================================
// DẠNG MỚI: XẾP TỪ / XẾP CÂU — các "chip" (ô chữ rời)
// ============================================================
// Ví dụ: "Put the words/phrases to make a complete sentence."
// → chỉ có MỘT câu đúng gồm N chip rời lẻ. Không có `ind`, không có class
// `correctq`, và không tồn tại "option" nào chứa nguyên câu ⇒ cả đường match
// theo ind lẫn match theo text đều thất bại.
// Cách duy nhất hữu ích: khớp TỪNG TỪ của câu đúng vào chip, sáng chúng lên
// rồi đánh số thứ tự đúng (badge 1,2,3…) để người dùng xếp theo.
// [REMOTE-CONFIG] let — có thể thay bằng giá trị đã validate từ xa.
let CHIP_MAX_TEXT = 90;

// Khóa so khớp: bỏ dấu câu + hạ chữ thường + gộp khoảng trắng.
// Chip trên trang là "your decisions." còn câu đúng tách từ là "your" /
// "decisions." → phải bỏ dấu ở CUỐI mới khớp được.
function chipKey(s) {
  return String(s == null ? '' : s)
    .replace(/[\u2018\u2019\u201C\u201D]/g, '')
    .replace(/[.,;:!?"'`\u2014\u2013()\[\]{}]/g, '')
    .replace(/\s+/g, ' ')
    .trim()
    .toLowerCase();
}

// Index "text chuẩn hoá → [phần tử]" cho 1 root (document hoặc shadowRoot).
// Dựng MỘT LẦN / root rồi cache — tránh querySelectorAll('*') cho từng câu.
// Map trả về có thêm `.words`: "từ đơn → [phần tử chứa từ đó]".
const _leafIdxCache = new WeakMap();
function indexChipElements(els) {
  const map = new Map();
  const words = new Map();
  for (const el of els) {
    try {
      if (el.closest && el.closest('#olm-answers-container,#olm-panel-root,#olm-settings-modal')) continue;
    } catch (_) {}
    // Chỉ giữ phần tử LÁ. Nếu không lọc, container bọc TOÀN BỘ chip có
    // text = nguyên câu và sẽ khớp n-gram 4 từ → tô nhầm 1 khối thay vì chip.
    const kids = el.children;
    if (kids && kids.length > 1) continue;
    if (kids && kids.length === 1 && kids[0].children && kids[0].children.length > 1) continue;
    const raw = (el.textContent || '').replace(/\s+/g, ' ').trim();
    if (!raw || raw.length > CHIP_MAX_TEXT) continue;
    const key = chipKey(raw);
    if (!key) continue;
    let arr = map.get(key);
    if (!arr) { arr = []; map.set(key, arr); }
    if (arr.length < 8) arr.push(el);
    for (const w of key.split(' ')) {
      if (!w) continue;
      let wa = words.get(w);
      if (!wa) { wa = []; words.set(w, wa); }
      if (wa.length < 8) wa.push(el);
    }
  }
  map.words = words;
  return map;
}

function leafTextIndex(root) {
  let cached = _leafIdxCache.get(root);
  if (cached && Date.now() - cached.t < 800) return cached.map;
  let all = [];
  try { all = root.querySelectorAll('*'); } catch (_) {}
  const map = indexChipElements(all);
  _leafIdxCache.set(root, { t: Date.now(), map });
  return map;
}

// Câu đúng (trong panel) → danh sách từ theo THỨ TỰ.
function chipTokensOf(item) {
  const answers = (item && item.answers) || [];
  const toks = [];
  for (const a of answers) {
    let s = String(a == null ? '' : a).replace(/\s+/g, ' ').trim();
    if (!s || s.length > 300) continue;
    // Phòng khi chuỗi "||" chưa được tách (đáp án dạng order từ nguồn khác):
    // tách luôn ở đây để không sinh token rác kiểu "it||can||be".
    s = s.split('||').map(x => x.trim()).filter(Boolean).join(' ');
    for (const p of s.split(' ')) {
      const k = chipKey(p);
      if (k) toks.push(k);
    }
  }
  return toks;
}

// Trả [{el, ord}] nếu tìm được chip cho câu đúng, ngược lại null.
// N-gram 1→4 từ: chip có thể là 1 từ ("be") hoặc cụm ("your family").
function matchChipsIn(index, tokens) {
  if (!index || !tokens || tokens.length < 3) return null;
  const used = new Set();    // phần tử đã gán
  const taken = new Set();   // vị trí token đã khớp
  const hits = [];
  const isUsable = (e) => {
    if (used.has(e)) return false;
    try { return PageHL.visible(e); } catch (_) { return false; }
  };
  const take = (i, n, el) => {
    used.add(el);
    for (let k = 0; k < n; k++) taken.add(i + k);
    hits.push({ el, ord: i + 1 });
  };

  // Vòng 1: n-gram theo đúng thứ tự câu đúng → ord = vị trí từ.
  for (let i = 0; i < tokens.length; i++) {
    if (taken.has(i)) continue;
    for (let n = Math.min(4, tokens.length - i); n >= 1; n--) {
      const arr = index.get(tokens.slice(i, i + n).join(' '));
      if (!arr) continue;
      const el = arr.find(isUsable);
      if (el) { take(i, n, el); break; }
    }
  }
  // Vòng 2: token còn sót nằm trong một chip chưa dùng (khớp theo ranh giới
  // từ). Cần cho chip nhiều từ ở VÁCH cuối: câu đúng kết bằng "decisions."
  // trong khi chip là "your decisions." → vòng 1 không có n-gram nào khớp.
  if (index.words) {
    for (let i = 0; i < tokens.length; i++) {
      if (taken.has(i)) continue;
      const arr = index.words.get(tokens[i]);
      if (!arr) continue;
      const el = arr.find(isUsable);
      if (el) take(i, 1, el);
    }
  }
  hits.sort((a, b) => a.ord - b.ord);
  // Đánh số LIÊN TỤC 1..N theo thứ tự bấm/xếp, không phải vị trí từ trong câu.
  // Câu đúng có thể lặp từ ("…when it doesn't…" dùng chip "It" đã dùng) →
  // đánh số theo vị trí từ sẽ nhảy số và gây hiểu nhầm.
  hits.forEach((h, k) => { h.ord = k + 1; });
  // Ngưỡng: ≥ 3 chip VÀ phủ ≥ 50% số từ — tránh bôi nhầm câu khác.
  if (hits.length < 3) return null;
  if (hits.length < Math.ceil(tokens.length * 0.5)) return null;
  return hits;
}

// Khối bao quanh nhóm chip (dùng cho .olm-hl-block — vệt sáng trái).
function chipBlockOf(el, root) {
  let b = el;
  for (let i = 0; i < 3; i++) {
    const p = b && b.parentElement;
    if (!p || !p.parentElement) break;
    if (p === root || /^(BODY|HTML)$/.test(p.tagName)) break;
    if ((p.textContent || '').length > 3000) break;
    b = p;
  }
  return b;
}

// Tìm các host quiz trong DOM (isolated world thấy được shadowRoot MỞ).
// `hints` = [{qid, tokens[]}] từ các câu trong panel chưa tô được, dùng để
// nhận diện dạng câu không có option (xếp từ / chip rời).
function locateQuizHosts(hints) {
  const out = [];
  let hosts = [];
  try { hosts = Array.from(document.querySelectorAll(QUIZ_HOST_SEL)); } catch (_) {}
  if (!hosts.length) {
    try {
      hosts = Array.from(document.querySelectorAll('*')).filter(el => el.shadowRoot && isLitQuizHost(el));
    } catch (_) {}
  }
  for (const host of hosts.slice(0, 8)) {
    if (!host || !host.isConnected || host.hidden) continue;
    let sr0 = null;
    try { sr0 = host.shadowRoot; } catch (_) {}
    if (!sr0) continue;
    let found = null;
    const roots = shadowRootsWithin(sr0, 3);
    for (const r of roots) {
      // ── Trắc nghiệm ──
      let mc = [];
      try { mc = Array.from(r.querySelectorAll(MC_OPTION_SEL)); } catch (_) {}
      if (mc.length) {
        let block = null;
        try { block = r.querySelector(MC_BLOCK_SEL); } catch (_) {}
        found = {
          kind: 'mc', host, root: r, block: block || mc[0].parentElement || r,
          stem: (() => { const q = r.querySelector('.question-content'); return q ? normText(q.textContent || '') : ''; })(),
          options: mc.map(el => ({
            el,
            ind: el.getAttribute('ind'),
            correct: /correctq|qcorrect|is-correct|answer-correct/i.test(String(el.className || '')),
            text: visibleOptionText(el.querySelector('.qsign') || el),
          })),
        };
        break;
      }
      // ── Đúng / Sai ──
      let tf = [];
      try { tf = Array.from(r.querySelectorAll(TF_ROW_SEL)); } catch (_) {}
      if (tf.length) {
        let block = null;
        try { block = r.querySelector(TF_BLOCK_SEL); } catch (_) {}
        found = {
          kind: 'tf', host, root: r, block: block || tf[0].parentElement || r,
          stem: (() => { const q = r.querySelector('.question-content'); return q ? normText(q.textContent || '') : ''; })(),
          options: tf.map(el => {
            const mark = el.querySelector('.qiradio.xcorrect,.xcorrect,[class*="xcorrect"]') || el.querySelector('[ind]');
            const cell = el.querySelector('td:first-child');
            return {
              el, ind: mark ? mark.getAttribute('ind') : null,
              correct: !!el.querySelector('.qiradio.xcorrect,.xcorrect,[class*="xcorrect"]'),
              text: visibleOptionText(cell || el),
            };
          }),
        };
        break;
      }
    }
    // ── Dạng XẾP TỪ / XẾP CÂU (chip rời) ──
    // Câu này không có .qselect nên không có option ⇒ 2 vòng trên rơi qua.
    // Chỉ chạy khi MC + TF đều thất bại và có câu đúng dạng nhiều từ trong panel.
    if (!found && hints && hints.length) {
      for (const hint of hints) {
        if (!hint || !hint.tokens || hint.tokens.length < 3) continue;
        for (const r of roots) {
          let idx = null;
          try { idx = leafTextIndex(r); } catch (_) {}
          const hits = matchChipsIn(idx, hint.tokens);
          if (hits && hits.length) {
            found = {
              kind: 'chips', host, root: r, block: chipBlockOf(hits[0].el, r),
              stem: '', qid: hint.qid || '',
              options: hits.map(h => ({
                el: h.el, ind: String(h.ord), ord: h.ord,
                correct: false, text: visibleOptionText(h.el),
              })),
            };
            break;
          }
        }
        if (found) break;
      }
    }
    if (found) out.push(found);
  }

  // ── Dạng chip nhưng OLM KHÔNG render trong web component (light DOM) ──
// CHỈ chạy khi (1) vòng Lit ở trên không tìm được gì VÀ (2) trang không có
// <default-root> nào. Điều kiện (2) là chốt chặn quan trọng: trên UI cũ, các
// <li class="qselect"> của câu trắc nghiệm cũng là "phần tử lá" và text của
// chúng có thể trùng nhiều từ với câu đúng → nếu không chặn, probe này tìm
// nhầm scope "chip", bỏ qua nhánh legacy và gán nhầm qid cho câu đang xem.
if (!out.length && !hosts.length && hints && hints.length) {
  const candRoots = [document];
  try {
    document.querySelectorAll('*').forEach(el => { if (el.shadowRoot) shadowRootsWithin(el.shadowRoot, 3).forEach(r => candRoots.push(r)); });
  } catch (_) {}
  for (const hint of hints) {
    if (!hint || !hint.tokens || hint.tokens.length < 3) continue;
    for (const r of candRoots) {
      let idx = null;
      try { idx = leafTextIndex(r); } catch (_) {}
      const hits = matchChipsIn(idx, hint.tokens);
      if (hits && hits.length) {
        out.push({
          kind: 'chips', host: r, root: r, block: chipBlockOf(hits[0].el, r),
          stem: '', qid: hint.qid || '',
          options: hits.map(h => ({
            el: h.el, ind: String(h.ord), ord: h.ord,
            correct: false, text: visibleOptionText(h.el),
          })),
        });
        break;
      }
    }
    if (out.length) break;
  }
}

  // ── UI cũ (đã kiểm chứng trên olm.vn) ──
  //   div#question.question          ← block của câu ĐANG XEM
  //     ├ #u_quiz    : bản user trả lời  (.qselect[data-ind], đúng thì .correctq)
  //     ├ #u_correct : bản ĐÁP ÁN ĐÚNG  (.qselect.qcorrect)   ← ưu tiên
  //     └ #u_exp     : hướng dẫn giải
  //   Stem nằm ở #u_correct > p > strong (KHÔNG có .question-content).
  //   Không có attribute id câu ở đâu cả → gate phải dựa vào stem.
  //   PHẢI ưu tiên #u_correct: #u_quiz chứa BẢN SAO option của người dùng với
  //   cùng data-ind, lấy cả hai nhóm thì mọi ind trùng nhau → tô nhầm 8/8 ô.
  if (!out.length) {
    try {
      // (1) UI cũ canonical: #question / div.question — PHẢI thử trước.
      //     Các attribute id* của OLM cũng xuất hiện trên thanh điều hướng câu
      //     (span[data-stt][data-quiz] × 30) và chúng nằm TRƯỚC #question trong
      //     document order → nếu gộp chung rồi slice() thì block thật bị cắt mất.
      let blocks = [];
      try { blocks = Array.from(document.querySelectorAll(LEGACY_ROOT_SEL)).slice(0, 4); } catch (_) {}
      if (!blocks.length) {
        try { blocks = Array.from(document.querySelectorAll('#qholder')).slice(0, 2); } catch (_) {}
      }
      if (!blocks.length) {
        try {
          blocks = Array.from(document.querySelectorAll(LEGACY_BLOCK_SEL))
            .filter(b => !b.hasAttribute('data-stt')).slice(0, 12);
        } catch (_) {}
      }
      for (const b of blocks) {
        if (!b.isConnected) continue;
        const rect = b.getBoundingClientRect();
        if (rect.width < 40 || rect.height < 20) continue;
        let corrBox = null;
        let quizBox = null;
        try { corrBox = b.querySelector('#u_correct,.correct-answer'); } catch (_) {}
        try { quizBox = b.querySelector('#u_quiz,.user-answer,.quiz-box'); } catch (_) {}
        // OLM đặt #u_correct = display:none mặc định (chỉ mở khi bấm
        // "Correct answer"), còn #u_quiz luôn hiện. Mọi option trong #u_correct
        // đều getClientRects()==0 → nếu lấy nó thì bị bỏ qua và highlight
        // không bao giờ lên. ⇒ ƯU TIÊN khối đang hiển thị.
        const vis = (el) => { try { return !!(el && el.getClientRects().length); } catch (_) { return false; } };
        const nOpts = (el) => { try { return el ? el.querySelectorAll('.qselect,[ind],[data-ind]').length : 0; } catch (_) { return 0; } };
        let srcBox = null;
        if (nOpts(quizBox) >= 2 && vis(quizBox)) srcBox = quizBox;
        else if (nOpts(corrBox) >= 2 && vis(corrBox)) srcBox = corrBox;
        else if (nOpts(corrBox) >= 2) srcBox = corrBox;
        else if (nOpts(quizBox) >= 2) srcBox = quizBox;
        else srcBox = corrBox || quizBox;
        let opts = [];
        try { opts = Array.from((srcBox || b).querySelectorAll(LEGACY_OPTION_SEL)); } catch (_) {}
        // Câu không có option (điền từ, xếp câu) → vẫn giữ block, đường input/chip
        // sẽ xử lý sau.
        if (opts.length < 2 && !b.querySelector('input,textarea,button')) continue;
        // Stem: ưu tiên <strong>/<p> trong khối đang hiển thị.
        const stemSrc = (() => {
          for (const box of [srcBox, quizBox, corrBox, b]) {
            if (!box) continue;
            const s = box.querySelector('p strong,strong,p,.question-content');
            if (s && normText(s.textContent || '')) return s;
          }
          return null;
        })();        out.push({
          kind: 'legacy', host: b, root: b, block: b,
          qid: b.getAttribute('data-id-quiz') || b.getAttribute('data-id_quiz')
            || b.getAttribute('data-idquiz') || b.getAttribute('data-question-id')
            || b.getAttribute('data-idquestion') || b.getAttribute('data-qid')
            || b.getAttribute('data-question') || b.getAttribute('data-questionid')
            || b.getAttribute('data-quiz') || b.getAttribute('data-quiz-id')
            || b.getAttribute('data-id') || '',
          stem: stemSrc ? normText(stemSrc.textContent || '') : '',
          options: opts.map(el => ({
            el, ind: el.getAttribute('ind') != null ? el.getAttribute('ind') : el.getAttribute('data-ind'),
            correct: /correctq|qcorrect|correctAnswer|is-correct|answer-correct|item-correct/i.test(String(el.className || '')),
            text: visibleOptionText(el),
          })),
        });
        // #question chỉ chứa 1 câu → lấy block đầu tiên là đủ, và quan trọng là
        // phải dừng ở đây để không nhét thêm #qholder/`.question` lồng nhau.
        if (b.id === 'question') break;
      }
    } catch (_) {}
  }
  return out;
}

// Cache ngắn cho locateQuizHosts(): cùng 1 câu hỏi đang hiển thị được dò lại
// bởi PageHL và bởi vòng enrich của panel. Mỗi lần gọi đều quét
// querySelectorAll('*') trên document + mọi shadow root → rất tốn khi 16 câu.
let _quizHostsCache = { t: 0, hosts: null, hints: false };
function getQuizHosts(maxAgeMs, hints) {
  const ttl = maxAgeMs == null ? 300 : maxAgeMs;
  const wantHints = !!(hints && hints.length);
  const c = _quizHostsCache;
  if (c.hosts && Date.now() - c.t < ttl && c.hints === wantHints) return c.hosts;
  const hosts = locateQuizHosts(hints);
  _quizHostsCache = { t: Date.now(), hosts, hints: wantHints };
  return hosts;
}
function invalidateQuizHostsCache() { _quizHostsCache = { t: 0, hosts: null, hints: false }; }

const PageHL = {
  items: new Map(),   // key → { question, answers[], tries, done }
  timer: 0,
  cssReady: false,
  // Scope = block câu hỏi ĐANG hiển thị + danh sách option của nó.
  // Cache lại theo "chữ ký" (qid + ind của từng option) để 1 pass chỉ quét DOM
  // 1 lần cho MỌI câu, và tự invalidate khi OLM chuyển câu.
  _scope: null,
  _scopeSig: '',
  _scopeT: 0,
  _obs: null,
  _obsRoot: null,
  _generation: 0,   // tăng mỗi lần license lock → run()/step() cũ tự dừng
  // [REMOTE-CONFIG] số vòng hồi sinh tối đa cho 1 câu (tinh chỉnh độ bền highlight).
  maxRearmCycles: 6,

  keyOf(question) {
    const qid = question && question.id != null ? String(question.id) : '';
    if (qid) return 'q' + qid;
    const oid = question && question._id != null ? String(question._id) : '';
    if (oid) return 'o' + oid;
    return 's' + normText(question?.title || question?.stem || '').slice(0, 80);
  },

  // ── Text thuần từ 1 <li> (hỗ trợ data-plain của các math span) ──
  plainOf(li) {
    try {
      // SECURITY: li nguồn từ panel (đã sanitize lúc render) nên clone an toàn.
      // Chỉ đọc textContent, không insert HTML.
      const clone = li.cloneNode(true);
      clone.querySelectorAll('[data-plain]').forEach(el => {
        if (el.parentElement && el.parentElement.closest('[data-plain]')) return;
        el.replaceWith(el.getAttribute('data-plain') || '');
      });
      return normText(clone.textContent || '');
    } catch (_) { return normText(li.textContent || ''); }
  },

  // ── Danh sách đáp án (text thuần, đã bỏ nhãn slot/marker) ──
  answersFrom(container) {
    if (!container) return [];
    let lis = [];
    try { lis = Array.from(container.querySelectorAll(':scope > li')); } catch (_) {}
    if (!lis.length) { try { lis = Array.from(container.querySelectorAll('li')); } catch (_) {} }

    const out = []; const seen = new Set();
    const push = (t) => {
      const v = normText(t);
      if (!v || v.length > 300 || seen.has(v)) return;
      seen.add(v); out.push(v);
    };
    const tfWords = new Set();

    for (const li of lis.slice(0, 40)) {
      const raw = this.plainOf(li);
      if (!raw) continue;
      // [✔ Đúng] / [✘ Sai] / [?] …
      const mk = /^\[([^\]]{0,12})\]\s*([\s\S]*)$/.exec(raw);
      let body = raw;
      if (mk) {
        const word = /[✔✘]\s*(Đúng|Sai)/.exec(mk[1]);
        if (word) tfWords.add(word[1]);
        body = normText(mk[2]);
      }
      // Bỏ nhãn slot: [slot.1] · [2] · Chỗ 1: · Câu 1:
      body = body
        .replace(/^\[?\s*slot\s*\.\s*\d+\s*\]?\s*/i, '')
        .replace(/^\[\s*\d+\s*\]\s*/, '')
        .replace(/^(chỗ|câu|blank|slot)\s*\d+\s*[:.]\s*/i, '')
        .trim();
      push(body);
    }
    // Đúng/Sai: chỉ thêm option word khi mọi dòng cùng 1 từ (tránh đánh dấu cả 2 nhánh)
    if (tfWords.size === 1) push(Array.from(tfWords)[0]);
    return out;
  },

  // ── Ghi nhận 1 block câu trả lời đã render ──
  offer(question, container) {
    if (!isLicenseActive()) return;
    if (!question || !container) return;
    const key = this.keyOf(question);
    const old = this.items.get(key);
    if (old && old.done) return;
    const answers = this.answersFrom(container);
    if (!answers.length) return;
    const merged = old ? Array.from(new Set(old.answers.concat(answers))) : answers;
    // FIX v1.3.2: lưu correctIndices (chỉ số gốc cho option shuffle).
    // FIX v1.3.6: correctIndexGroups theo từng sub-list (câu nhiều ý).
    let correctIndices = old && old.correctIndices ? old.correctIndices : [];
    let correctIndexGroups = old && old.correctIndexGroups ? old.correctIndexGroups : [];
    try {
      if (!correctIndexGroups.length) {
        const groups = getCorrectIndexGroups(question);
        if (groups && groups.length) correctIndexGroups = groups;
      }
      if (!correctIndices.length) {
        for (const g of correctIndexGroups) for (const v of g) if (!correctIndices.includes(v)) correctIndices.push(v);
      }
      if (!correctIndices.length) {
        const fresh = getCorrectOriginalIndices(question);
        if (fresh && fresh.length) correctIndices = fresh;
      }
    } catch (_) {}
    this.items.set(key, { question, answers: merged, correctIndices, correctIndexGroups, tries: old ? old.tries : 0, done: false, els: old ? old.els : [] });
    if (this.items.size > 300) {
      const first = this.items.keys().next().value;
      if (this.items.get(first)?.done) this.items.delete(first);
    }
    // schedule(0) = "câu mới vừa render, highlight ngay" (leading edge).
    // Các lần offer() liên tiếp vẫn được coalesce vì cùng 1 timer.
    this.schedule(0);
  },

  schedule(delay) {
    if (!isLicenseActive()) return;
    if (!RT.settings.highlightPage) return;
    clearTimeout(this.timer);
    const fire = () => { this.timer = 0; this.run(); };
    const d = delay == null ? 400 : delay;
    // Leading edge: khi không có pass nào đang chạy VÀ không có yêu cầu chờ
    // rõ ràng (d <= 50, tức offer() mới) thì chạy NGAY ở tick kế tiếp.
    // TUYỆT ĐỐI không áp dụng cho delay rõ ràng (300/3000/600): run() gọi
    // schedule(3000) lúc _running đã false, nếu ép chạy ngay sẽ thành busy
    // retry loop (tries tăng liên tục) — đúng thứ cần tránh.
    if (!this._running && d <= 50) {
      this.timer = safeTimeout(fire, 0);
      return;
    }
    this.timer = safeTimeout(fire, d);
  },

  ensureCss() {
    if (document.getElementById('olm-highlight-css')) { this.cssReady = true; return; }
    try {
      const s = document.createElement('style');
      s.id = 'olm-highlight-css';
      s.textContent = HIGHLIGHT_PAGE_CSS;
      (document.head || document.documentElement).appendChild(s);
      this.cssReady = true;
      // Chẩn đoán: nếu CSP chặn <style> thì sheet === null → không có glow từ CSS
      const rules = s.sheet ? s.sheet.cssRules.length : 0;
      if (!rules) L.warn('PageHL CSS KHÔNG được nạp (sheet=null) → chỉ còn highlight inline');
      else L.log('PageHL CSS nạp OK,', rules, 'rules');
    } catch (e) { L.warn('PageHL ensureCss lỗi:', e); }
  },

  // ── Giao diện MỚI của OLM render bài tập trong Shadow DOM ──
  // CSS của document KHÔNG xuyên qua shadow boundary → phải chèn <style>
  // vào từng shadow root chứa phần tử được đánh dấu.
  ensureShadowCss(sr) {
    try {
      if (!sr || !sr.appendChild) return;
      if (sr.querySelector && sr.querySelector('#olm-highlight-css')) return;
      const s = document.createElement('style');
      s.id = 'olm-highlight-css';
      s.textContent = HIGHLIGHT_PAGE_CSS;
      sr.appendChild(s);
    } catch (_) {}
  },

  invalidateScope() {
    this._scope = null;
    this._scopeSig = '';
    this._scopeT = 0;
    this._detachScopeObs();
    try { this._blkMiss.clear(); } catch (_) {}
    invalidateQuizHostsCache();
  },

  // ────────────────────────────────────────────────────────────────
  // CHUẨN HÓA ĐỂ SO KHỚP  (đây là chỗ gây bug nghiêm trọng nhất)
  // ────────────────────────────────────────────────────────────────
  // Bản cũ: loose() xóa MỌI ký tự không phải chữ/số, tức là xóa luôn
  //   | = ^ / + - và mọi khoảng trắng.
  // Hậu quả (đã tái hiện được trên olm.vn, câu "Khẳng định nào sau đây đúng?"):
  //   đáp án "Hàm số $y=|\tan x|$ là hàm số chẵn."  → loose "hàmsốytanxlàhàmsốchẵn"
  //   option trên trang "Hàm số y=tanx là hàm số chẵn." → loose "hàmsốytanxlàhàmsốchẵn"
  //   ⇒ HAI chuỗi BẰNG NHAU → score 3 → tô nhầm option của câu khác.
  // Nay: chỉ bỏ KHOẢNG TRẮNG và dấu câu cuối; GIỮ NGUYÊN toán tử.
  canon(s) {
    let t = String(s == null ? '' : s);
    if (!t) return '';
    try { t = t.normalize('NFKC'); } catch (_) {}
    t = t
      .replace(/[\u2010-\u2015\u2212\uFE58\uFE63\uFF0D]/g, '-')      // mọi kiểu gạch ngang → '-'
      .replace(/[\u2018\u2019\u201A\u201B\u2032\u02BC]/g, "'")
      .replace(/[\u201C\u201D\u201E\u201F]/g, '"')
      .replace(/[\u00a0\u2005\u2007\u2008\u2009\u200a\u202f\u200b\u2060\ufeff]/g, ' ')
      .toLowerCase()
      .replace(/\s+/g, '')                                          // BỎ TOÀN BỘ SPACE
      .replace(/^[a-z]\s*[.)]/, '')                                  // nhãn A. B. C. ở đầu
      .replace(/[.,;:!?"'`)\]]+$/, '')                              // dấu câu cuối
      .replace(/[.,;:!?"'`(\[]+/g, '');                              // dấu câu xen kẽ
    return t;
  },

  // "Chữ ký toán học": chuỗi số + số lượng toán tử cấu trúc.
  // Bắt buộc bằng nhau ở mọi so khớp "gần đúng", nếu không
  // "f(x)=|sin x|" sẽ khớp "f(x)=sin x".
  opsig(s) {
    const t = String(s == null ? '' : s);
    const digits = (t.match(/\d+/g) || []).join(',');
    const ops = (t.match(/[|=<>+\-*/^×÷±∞√]/g) || []).sort().join('');
    return digits + '|' + ops;
  },

  // Chuẩn hóa RIÊNG cho so khớp stem (câu hỏi). Ở đây được phép bỏ cả
  // ( ) [ ] { } / vì KaTeX render phân số chồng bằng <span> nên DOM không có
  // dấu phân cách: \dfrac{\pi}{3} → DOM "π3" còn latexToPlain → "(π)/(3)".
  // Stem luôn dài và đặc tính nên bỏ những ký tự này không gây trùng lẫn.
  canonStem(s) {
    return this.canon(s).replace(/[(){}\[\]/]/g, '');
  },

  // Score: 3 = khớp tuyệt đối (dùng cho mọi đường highlight).
  //        2 = khớp gần đúng, CHỈ chấp nhận khi gần như trùng (bù hạn chữ).
  //        0 = không khớp.
  // Bản cũ cho điểm 2 với điều kiện "includes" quá rộng → nguyên nhân tô nhầm.
  matchScore(c, aN, aL) {
    if (!c || !c.n || !aN) return 0;
    if (c.n === aN) return 3;
    if (aN.length < 2) return 0;
    const cL = c.l || c.n, aLoose = aL || aN;
    if (aLoose.length >= 2 && cL === aLoose) return 3;
    // Gần đúng: 1 chuỗi là tiền tố/nội dung của chuỗi kia, chênh lệch rất nhỏ
    // VÀ phải có cùng chữ ký toán học.
    const short = aN.length <= c.n.length ? aN : c.n;
    const long  = aN.length <= c.n.length ? c.n : aN;
    const delta = long.length - short.length;
    if (short.length >= 8 && delta <= 6 && long.includes(short) && this.opsig(aL || aN) === this.opsig(cL)) return 2;
    return 0;
  },

  // Chuẩn hóa 1 đáp án để đem đi so khớp.
  canonAnswer(a) {
    const n = this.canon(a);
    return { n, l: n };
  },

  prio(el) {
    const t = el.tagName;
    if (t === 'LABEL') return 6;
    const role = el.getAttribute && el.getAttribute('role');
    if (role === 'radio' || role === 'checkbox' || role === 'option') return 6;
    const cl = (el.getAttribute && el.getAttribute('class')) || '';
    if (/qselect|qcheck|qsign/i.test(cl)) return 6;
    if (/option|choice|answer|correct|selected|tf-row/i.test(cl)) return 5;
    if (t === 'LI' || t === 'TR') return 4;
    if (t === 'TD' || t === 'SPAN' || t === 'DIV') return 3;
    return 2;
  },

  // Element có thật sự hiển thị không? (tránh đánh dấu bản ẩn/clone của trang)
  // Dùng getClientRects() thay cho checkVisibility(): checkViewport() ép layout
  // toàn trang và rất chậm khi gọi hàng loạt trên trang đề lớn.
  visible(el) {
    try { return el.getClientRects().length > 0; } catch (_) { return true; }
  },

  // ── Chuẩn hóa option trong scope để so khớp ──
  prepOptions(scope) {
    if (!scope || scope._prepped) return scope;
    for (const o of scope.options) {
      const n = this.canon(o.text);
      o.n = n;
      o.l = n;
      o._sig = this.opsig(n);
      o._vis = this.visible(o.el);
    }
    scope._prepped = true;
    return scope;
  },

  // UI c��i: câu chỉ xuất hiện trên trang khi user mở tới nó, nên 8 lần thử
  // thường hết trước lúc user kịp chuyển câu. Hồi sinh thêm vài lần với
  // thời gian chờ giãn dần (tối đa 6 vòng ≈ 40s) để không bỏ sót.
  // Trả về true nếu có câu vừa được hồi sinh (cần chạy lại pass).
  rearmExhausted() {
    let any = false;
    for (const it of this.items.values()) {
      if (it.done || it.tries < 8) continue;
      const cycles = it._cycles || 0;
      if (cycles >= this.maxRearmCycles) continue;
      if (Date.now() - (it._rearmAt || 0) < 4000 + cycles * 1500) continue;
      it._cycles = cycles + 1;
      it._rearmAt = Date.now();
      it.tries = 0;
      any = true;
    }
    return any;
  },

  // Cache âm cho applyLegacy: mỗi pass sẽ gọi findQuestionBlockInPage cho
  // MỌI câu chưa tô (16 câu × ~19 selector) → rất nặng trên trang lớn, và
  // vô ích vì UI mới không có attribute id nào. TTL ngắn để vẫn bắt được câu
  // ngay khi user mở tới.
  _blkMiss: new Map(),

  // Stem của 1 khối câu hỏi (UI cũ không có .question-content).
  stemOf(box) {
    for (const b of [box, box && box.querySelector('#u_quiz'), box && box.querySelector('#u_correct')]) {
      if (!b) continue;
      const s = b.querySelector ? b.querySelector('p strong,strong,p,.question-content') : null;
      const t = s ? normText(s.textContent || '') : '';
      if (t) return t;
    }
    return '';
  },

  // Câu trong panel có ĐÚNG là câu đang hiển thị không? (dùng khi không có qid)
  // `loose` chỉ BẬT cho scope 'legacy'. Lý do rất quan trọng:
  //   · UI mới (mc/tf/chips): cổng so stem là hàng rào CHỐNG TÔ NHẦM giữa các
  //     câu — nới ra có thể tô đáp án của câu khác lên câu đang xem. Giữ nguyên
  //     so khớp TUYỆT ĐỐI như bản 1.3.7 (đã được kiểm chứng là chạy đúng).
  //   · UI cũ (#question không mang id câu): stem là cổng DUY NHẤT, mà OLM ghi
  //     stem hơi khác API (nbsp, dấu câu cuối) nên cần nới có kiểm soát.
  // Câu đầu vào bên API chứa LaTeX thô ($...$, \frac…); stem trên trang đã được
  // KaTeX render → chuẩn hóa CẢ HAI về cùng dạng rồi mới so. Khi nới: 1 chuỗi
  // phải là nội dung của chuỗi kia VÀ cùng chữ ký toán học (opsig).
  stemOk(item, sStemRaw, loose) {
    const sStem = this.canonStem(sStemRaw || '');
    if (!sStem) return false;
    const q = (item && item.question) || {};
    const cands = [];
    try { cands.push(extractStemTextFromLexical(tryParseQuestionJsonTree(q))); } catch (_) {}
    if (q.title) cands.push(q.title);
    for (const c of cands) {
      let stem;
      try { stem = this.canonStem(cleanMathText(c || '')) || this.canonStem(q.title); } catch (_) { stem = this.canonStem(q.title); }
      if (!stem) continue;
      if (stem === sStem) return true;
      if (loose && this.matchScore({ n: stem, l: stem }, sStem, sStem) >= 2) return true;
    }
    return false;
  },

  blockFor(question) {
    const q = question || {};
    const ids = [q.id, q._id].filter(v => v != null).map(String);
    if (!ids.length) return { el: null, byId: false, stem: '' };
    const key = ids.join('|');
    const m = this._blkMiss.get(key);
    if (m != null && Date.now() - m < 1500) return { el: null, byId: false, stem: '' };
    let b = null;
    try { b = findQuestionBlockInPage(question); } catch (_) {}
    if (b) { this._blkMiss.delete(key); return { el: b, byId: true, stem: '' }; }
    // UI cũ: #question là block của câu ĐANG XEM và không mang id câu, nên
    // findQuestionBlockInPage (dò data-id*) luôn trượt → thử #question.
    // byId=false ⇒ BẮT BUỘC phải so stem trước khi tô, vì không có id để
    // đối chiếu và mọi câu pending đều sẽ trỏ tới cùng 1 block.
    let stem = '';
    try {
      const qn = document.querySelector('#question');
      if (qn && qn.isConnected) { b = qn; stem = this.stemOf(qn); }
    } catch (_) {}
    if (b) return { el: b, byId: false, stem };
    if (this._blkMiss.size > 400) this._blkMiss.delete(this._blkMiss.keys().next().value);
    this._blkMiss.set(key, Date.now());
    return { el: null, byId: false, stem: '' };
  },

  // Gợi ý nhận diện dạng "xếp từ / xếp câu" cho locateQuizHosts(): lấy từ
  // các câu trong panel chưa tô được. Chỉ câu có ≥ 3 từ mới đáng thử.
  chipHints() {
    const out = [];
    for (const it of this.items.values()) {
      if (it.done) continue;
      const toks = chipTokensOf(it);
      if (toks.length < 3) continue;
      const q = it.question || {};
      const qid = q.id != null ? String(q.id) : (q._id != null ? String(q._id) : '');
      out.push({ qid, tokens: toks });
      if (out.length >= 24) break;
    }
    return out;
  },

  // ────────────────────────────────────────────────────────────────
  // SCOPE: xác định chính xác câu hỏi + option đang hiển thị
  // ────────────────────────────────────────────────────────────────
  // Nhận `hosts` từ bridge (MAIN world đọc được jsonQuestion.id của Lit host)
  // và ghép với node DOM tương ứng tìm được trong isolated world.
  async resolveScope() {
    const found = getQuizHosts(300, this.chipHints());
    if (!found.length) return null;
    let bridgeHosts = null;
    try { bridgeHosts = await pageContextAsync(400); } catch (_) {}
    const isVisible = (h) => h.options.some(o => {
      try { return o.el.getClientRects().length > 0; } catch (_) { return false; }
    });
    let pool = found.filter(isVisible);
    if (!pool.length) pool = found;
    // Ưu tiên host mà id câu hỏi nằm trong danh sách panel đang xử lý.
    // (Trang có thể render nhiều <default-root>: preview + list.)
    if (pool.length > 1 && Array.isArray(bridgeHosts) && bridgeHosts.length) {
      const known = new Set();
      for (const it of this.items.values()) {
        const q = it.question || {};
        if (q.id != null) known.add(String(q.id));
        if (q._id != null) known.add(String(q._id));
      }
      const pick = pool.find(h => {
        const qid = h.qid || (bridgeHosts.find(b => b && b.kind === h.kind && b.qid) || {}).qid;
        return qid && known.has(String(qid));
      });
      if (pick) pool = [pick];
    }
    const dom = pool[0];
    // Ghép qid từ bridge theo kind (id của Lit host chỉ đọc được ở MAIN world).
    // KHÔNG xoá qid đã tìm được sẵn ở locateQuizHosts (UI cũ lấy từ data-id*,
    // dạng chip lấy từ hint) — bản cũ gán đè bằng '' làm mất cả hai.
    let qid = dom.qid || '';
    if (!qid && Array.isArray(bridgeHosts)) {
      let match = bridgeHosts.find(h => h && h.kind === dom.kind && h.options && h.options.length);
      if (!match) match = bridgeHosts.find(h => h && h.qid);
      if (match && match.qid) qid = String(match.qid);
    }
    if (qid) dom.qid = qid;
    this.prepOptions(dom);
    dom._sig = dom.kind + '|' + qid + '|' + dom.options.map(o => o.ind == null ? '?' : o.ind).join(',');
    return dom;
  },

  scopeIfFresh() {
    // Cache scope trong 1.2s: OLM chuyển câu rồi mới render → cache ngắn tránh
    // quét lại DOM liên tục, nhưng vẫn kịp phản ứh khi user đổi câu.
    if (this._scope && Date.now() - this._scopeT < 1200) return this._scope;
    return null;
  },

  // Theo dõi thay đổi trong scope để invalidate cache (thay cho vòng poll 5s
  // quét toàn trang — nguyên nhân chính của "quét chậm").
  attachScopeObs(scope) {
    if (!scope || !scope.root || this._obsRoot === scope.root) return;
    this._detachScopeObs();
    try {
      const target = scope.root;
      const obs = new MutationObserver(() => {
        this._scope = null; this._scopeT = 0;
        // Câu đang hiển thị có thể vừa đổi → cho các item pending chạy lại.
        this.items.forEach(it => { if (!it.done) { it.tries = 0; } });
        this.schedule(120);
      });
      obs.observe(target, { childList: true, subtree: true, attributes: true, attributeFilter: ['class', 'ind', 'style'] });
      this._obs = obs;
      this._obsRoot = target;
    } catch (_) {}
  },

  _detachScopeObs() {
    try { this._obs?.disconnect(); } catch (_) {}
    this._obs = null;
    this._obsRoot = null;
  },

  // Option được highlight phải là phần tử "đủ lớn" (li/label/option/tr…)
  // thay vì span con nằm trong đó → ánh sáng phát ra rõ hơn.
  optionTarget(el) {
    try {
      const t = el.closest(
        'li,label,tr,[role="radio"],[role="checkbox"],[role="option"],' +
        '[class*="option"],[class*="choice"],[data-value],td,' +
        '.qselect,[class*="qselect"],[ind],.tf-row'
      );
      if (!t || t === el) return el;
      if (!this.visible(t)) return el;
      if (t.closest('#olm-answers-container,#olm-panel-root')) return el;
      if (t.classList.contains('olm-hl-block')) return el;
      // Không "trèo" ra container chung bọc cả danh sách option
      if ((t.textContent || '').trim().length > 400) return el;
      const inner = t.querySelectorAll(
        'li,label,[role="radio"],[role="checkbox"],[class*="option"],[class*="choice"],.qselect'
      );
      if (inner.length > 1) return el;
      return t;
    } catch (_) { return el; }
  },

  // ── Highlight INLINE (!important) — không phụ thuộc <style> trên trang ──
  // Sheet vẫn giữ vai trò animation/pulse; inline là lớp bảo hiểm thấy ngay.
  // Lưu ý: KHÔNG set box-shadow inline — important-author thắng animation,
  // nếu không pulse "phát sáng" sẽ không chạy.
  HL_INLINE: {
    hit: [
      ['background-color', 'rgba(var(--olm-hl1-rgb),.22)'],
      ['background-image', 'linear-gradient(180deg, rgba(var(--olm-hl1-rgb),.30), rgba(var(--olm-hl1-rgb),.15))'],
      ['outline', '3px solid rgba(var(--olm-hl1-rgb),.95)'],
      ['outline-offset', '2px'],
      ['border-radius', '8px'],
    ],
    input: [
      ['background-color', 'rgba(var(--olm-hl1-rgb),.20)'],
      ['outline', '3px dashed rgba(var(--olm-hl1-rgb),.95)'],
      ['outline-offset', '2px'],
    ],
    chip: [
      ['background-color', 'rgba(var(--olm-hl1-rgb),.24)'],
      ['background-image', 'linear-gradient(180deg, rgba(var(--olm-hl1-rgb),.34), rgba(var(--olm-hl1-rgb),.16))'],
      ['outline', '2px solid rgba(var(--olm-hl1-rgb),.92)'],
      ['outline-offset', '1px'],
    ],
  },

  markEl(el, kind = 'hit') {
    if (!el || !el.classList) return;
    const cls = kind === 'input' ? 'olm-hl-input' : 'olm-hl-hit';
    // Nếu phần tử nằm trong shadow DOM → chèn <style> vào shadow root đó
    // (document CSS không xuyên qua shadow boundary → animation/glow từ class
    // phải có sheet riêng trong shadow mới thấy)
    try {
      const rn = typeof el.getRootNode === 'function' ? el.getRootNode() : null;
      if (rn && rn !== document && rn.nodeType === 11) this.ensureShadowCss(rn);
    } catch (_) {}
    try { if (!el.classList.contains(cls)) el.classList.add(cls); } catch (_) {}
    try {
      el.setAttribute('data-olm-hl', kind);
      const props = this.HL_INLINE[kind] || this.HL_INLINE.hit;
      for (const p of props) el.style.setProperty(p[0], p[1], 'important');
    } catch (_) {}
  },

  // Chip (dạng xếp từ / xếp câu): sáng + badge số thứ tự đúng.
  markChipEl(el, ord) {
    if (!el || !el.classList) return;
    try {
      const rn = typeof el.getRootNode === 'function' ? el.getRootNode() : null;
      if (rn && rn !== document && rn.nodeType === 11) this.ensureShadowCss(rn);
    } catch (_) {}
    try {
      // Badge ::after cần position khác static. Chỉ ép khi trang đang để
      // static, và ghi nhớ đã ép để unmarkEl gỡ đúng (không phá layout gốc).
      if (!el.hasAttribute('data-olm-pos')) {
        let pos = '';
        try { pos = getComputedStyle(el).position || ''; } catch (_) {}
        if (!pos || pos === 'static') {
          el.style.setProperty('position', 'relative', 'important');
          el.setAttribute('data-olm-pos', '1');
        }
      }
      el.classList.add('olm-hl-chip');
      el.setAttribute('data-olm-hl', 'chip');
      el.setAttribute('data-olm-order', String(ord == null ? '' : ord));
      const props = this.HL_INLINE.chip || [];
      for (const p of props) el.style.setProperty(p[0], p[1], 'important');
    } catch (_) {}
  },

  unmarkEl(el) {
    if (!el || !el.style) return;
    try {
      const kind = el.getAttribute && el.getAttribute('data-olm-hl');
      if (kind) {
        el.removeAttribute('data-olm-hl');
        if (kind === 'chip') {
          el.removeAttribute('data-olm-order');
          if (el.getAttribute('data-olm-pos') === '1') el.style.removeProperty('position');
          el.removeAttribute('data-olm-pos');
        }
        const props = this.HL_INLINE[kind] || this.HL_INLINE.hit;
        for (const p of props) el.style.removeProperty(p[0]);
      }
      el.classList.remove('olm-hl-hit', 'olm-hl-input', 'olm-hl-chip');
    } catch (_) {}
  },

  // Đánh dấu block câu hỏi (cũng cần sheet trong shadow nếu block nằm trong đó)
  markBlockEl(b) {
    if (!b || !b.classList) return;
    try {
      const rn = typeof b.getRootNode === 'function' ? b.getRootNode() : null;
      if (rn && rn !== document && rn.nodeType === 11) this.ensureShadowCss(rn);
    } catch (_) {}
    try { b.classList.add('olm-hl-block'); } catch (_) {}
  },

  // ────────────────────────────────────────────────────────────────
  // applyOne — ưu tiên scope của câu đang hiển thị (UI mới),
  //           không có thì lùi về block theo id (UI cũ).
  // ────────────────────────────────────────────────────────────────
  applyOne(item, scope) {
    if (!isLicenseActive()) return false;
    const answers = item.answers || [];
    const markedEls = [];
    const markOne = (el) => {
      if (!el || !el.tagName) return;
      if (el.closest && el.closest('#olm-answers-container,#olm-panel-root,#olm-settings-modal')) return;
      const target = this.optionTarget(el);
      this.markEl(target, 'hit');
      if (!markedEls.includes(target)) markedEls.push(target);
    };

    const hasScope = !!(scope && scope.options && scope.options.length);
    let marked = 0;

    if (hasScope) {
      // (A) Đúng câu hỏi đang hiển thị không? — CHỐNG TÔ NHẦM SANG CÂU KHÁC.
      // Đây là bản vá trực tiếp cho lỗi "2 câu có đáp án gần giống → in cả 2
      // đáp án lên 1 trang": mọi câu trong panel dùng chung 1 khối DOM duy nhất
      // (component <type-quiz-x> chỉ render câu đang xem), nên không có "scope"
      // thì mọi câu đều có thể tô nhầm vào cùng 1 câu đang hiển thị.
      const qid = item.question && item.question.id != null ? String(item.question.id) : '';
      const oid = item.question && item.question._id != null ? String(item.question._id) : '';
      let scopeUsable = true;
      if (scope.qid) {
        if (!qid && !oid) scopeUsable = false;
        else if (scope.qid !== qid && scope.qid !== oid) scopeUsable = false;
      } else if (scope.stem) {
        // UI mới: giữ so khớp TUYỆT ĐỐI (hàng rào chống tô nhầm, đã chạy đúng
        // ở bản 1.3.7). UI cũ: nới có kiểm soát vì stem là cổng duy nhất.
        scopeUsable = this.stemOk(item, scope.stem, scope.kind === 'legacy');
      } else {
        scopeUsable = false;   // không xác định được câu nào → KHÔNG đoán, không tô
      }

      if (scopeUsable) {
        // (A2) Dạng xếp từ / xếp câu: scope.options chính là các chip, `ord`
        // là thứ tự đúng đã tính sẵn lúc dò. Không có ind gốc để dùng.
        if (scope.kind === 'chips') {
          for (const o of scope.options) {
            if (!o.el || !o.ord || !o._vis) continue;
            try {
              if (o.el.closest && o.el.closest('#olm-answers-container,#olm-panel-root,#olm-settings-modal')) continue;
            } catch (_) { continue; }
            this.markChipEl(o.el, o.ord);
            if (!markedEls.includes(o.el)) markedEls.push(o.el);
            marked++;
          }
        } else {
          // (B) ĐƯỜNG CHÍNH: khớp theo chỉ số option GỐC (ind).
          // OLM shuffle thứ tự hiển thị nhưng giữ `ind` = vị trí gốc, nên đường này
          // miễn nhiễm 100% với mọi sai lệch text do KaTeX render.
          const groups = (item.correctIndexGroups && item.correctIndexGroups.length)
            ? item.correctIndexGroups
            : (item.correctIndices && item.correctIndices.length ? [item.correctIndices] : null);
          if (groups) {
            // Chỉ giữ nhóm chỉ số nằm trong phạm vi option của câu đang hiển thị —
            // loại chỉ số vượt số option (trường hợp câu có nhiều olm-list).
            const n = scope.options.length;
            const valid = groups.filter(g => Array.isArray(g) && g.length
              && g.every(v => v != null && /^\d+$/.test(String(v)) && Number(v) < n));
            const useGroups = valid.length ? valid : groups;
            const wanted = new Set();
            for (const g of useGroups) for (const v of (g || [])) if (v != null) wanted.add(String(v));
            for (const o of scope.options) {
              if (o.ind == null || !wanted.has(String(o.ind))) continue;
              if (!o._vis) continue;
              markOne(o.el);
              marked++;
            }
            // TF: nếu trang KHÔNG set ind, suy ra từ class xcorrect do OLM render.
            if (!marked && scope.kind === 'tf') {
              for (const o of scope.options) {
                if (!o.correct || !o._vis) continue;
                markOne(o.el);
                marked++;
              }
            }
            // (C) Nếu trang đã tự đánh dấu (mode xem đáp án) mà `ind` không khớp
            // → dùng chính dấu hiệu của trang làm đường dự phòng.
            if (!marked) {
              for (const o of scope.options) {
                if (!o.correct || !o._vis) continue;
                markOne(o.el);
                marked++;
              }
            }
          }

          // (D) UI cũ / không có ind → so khớp TEXT, nhưng CHỈ trong scope này.
          if (!marked) {
            const targets = [];
            for (const a of answers) {
              const c = this.canonAnswer(a);
              if (c.n) targets.push(c);
            }
            for (const t of targets) {
              let best = null;
              for (const o of scope.options) {
                if (!o.n || !o._vis) continue;
                const sc = this.matchScore(o, t.n, t.l);
                if (!sc || sc < 3) continue;
                if (!best || sc > best.sc
                    || (sc === best.sc && this.prio(o.el) > this.prio(best.o.el))
                    || (sc === best.sc && this.prio(o.el) === this.prio(best.o.el) && o.n.length < best.o.n.length)) {
                  best = { o, sc };
                }
              }
              if (best) { markOne(best.o.el); marked++; }
            }
          }

          // (E) Câu điền từ: đáp án không xuất hiện dạng text → tô ô input TRONG SCOPE.
          if (!marked) {
            let inputs = [];
            try {
              inputs = Array.from((scope.block || scope.root).querySelectorAll('input,textarea'))
                .filter(inp => {
                  const tp = (inp.type || '').toLowerCase();
                  if (['hidden','radio','checkbox','submit','button'].includes(tp)) return false;
                  try { return inp.getClientRects().length > 0; } catch (_) { return false; }
                });
            } catch (_) {}
            if (inputs.length) {
              const limit = Math.max(1, Math.min(answers.length || 1, inputs.length));
              for (let i = 0; i < Math.min(limit, inputs.length); i++) {
                const inp = inputs[i];
                if (inp.closest('#olm-answers-container,#olm-panel-root,#olm-settings-modal')) continue;
                this.markEl(inp, 'input');
                if (!markedEls.includes(inp)) markedEls.push(inp);
                marked++;
              }
            }
          }

          // (E2) Câu nhiều từ (vd "xếp câu") mà OLM render chip bằng chính
          // class option: mỗi "option" là 1 từ của câu đúng. Đường (B)/(D)
          // không thể khớp vì không option nào chứa nguyên câu → dò lại bằng
          // cách khớp từ trên đúng tập option của scope này.
          if (!marked) {
            const toks = chipTokensOf(item);
            if (toks.length >= 3 && scope.options.length >= 3) {
              let idx = null;
              try { idx = indexChipElements(scope.options.map(o => o.el)); } catch (_) {}
              const hits = matchChipsIn(idx, toks);
              if (hits && hits.length) {
                for (const h of hits) {
                  const chip = h.el;
                  if (!chip || !chip.closest) continue;
                  if (chip.closest('#olm-answers-container,#olm-panel-root,#olm-settings-modal')) continue;
                  if (!this.visible(chip)) continue;
                  this.markChipEl(chip, h.ord);
                  if (!markedEls.includes(chip)) markedEls.push(chip);
                  marked++;
                }
              }
            }
          }
        }
      }
    }

    if (marked) {
      if (hasScope && scope.block) this.markBlockEl(scope.block);
      item.els = markedEls;
      L.log('PageHL →', hasScope ? scope.kind : '-', marked, 'hit(s) ::', (answers[0] || '').slice(0, 60));
      return true;
    }

    // (F) ĐƯỜNG DỰ PHÒNG — GIAO DIỆN CŨ.
    if (this.applyLegacy(item, markedEls)) {
      item.els = markedEls;
      L.log('PageHL → legacy', markedEls.length, 'hit(s) ::', (answers[0] || '').slice(0, 60));
      return true;
    }
    item.els = markedEls;
    return false;
  },

  // ────────────────────────────────────────────────────────────────
  // applyLegacy — GIAO DIỆN CŨ (UI pre-Lit của OLM)
  // ────────────────────────────────────────────────────────────────
  // UI cũ không có <default-root>/shadow DOM: mỗi câu là một block có
  // attribute chứa id (data-id, data-id-quiz, data-quiz, #question-<id>…).
  // Khớp chắc nhất là TÌM ĐÚNG BLOCK THEO ID rồi tô bên trong block đó:
  //   · không phụ thuộc thứ tự câu trên trang,
  //   · không cần so stem (stem bên API có LaTeX thô còn trên trang đã
  //     KaTeX render ⇒ so sánh stem luôn thất bại với câu có công thức —
  //     đây chính là lý do bản scope-only của v1.3.7 làm hỏng UI cũ).
  applyLegacy(item, markedEls) {
    const answers = item.answers || [];
    if (!answers.length) return 0;
    const found = this.blockFor(item.question);
    if (!found || !found.el || !found.el.isConnected) return 0;
    const block = found.el;
    // Block tìm theo id → tin được. Block rơi về fallback #question của UI cũ
    // thì KHÔNG có id để đối chiếu, phải so stem — nếu không cả 16 câu pending
    // đều tô chung 1 input của câu đang xem.
    if (!found.byId && !this.stemOk(item, found.stem, true)) return 0;
    // Block đang ẩn = user chưa mở tới câu này → giữ pending, đừng tô bừa.
    if (!this.blockShown(block)) return 0;

    const hits = new Set();
    const ok = (el) => {
      if (!el || !el.tagName) return false;
      try {
        if (el.closest && el.closest('#olm-answers-container,#olm-panel-root,#olm-settings-modal')) return false;
      } catch (_) { return false; }
      return true;
    };
    const markHit = (el) => {
      const t = this.optionTarget(el);
      if (!ok(t)) return false;
      this.markEl(t, 'hit');
      if (!markedEls.includes(t)) markedEls.push(t);
      hits.add(t);
      return true;
    };
    const markInput = (el) => {
      if (!ok(el)) return false;
      this.markEl(el, 'input');
      if (!markedEls.includes(el)) markedEls.push(el);
      hits.add(el);
      return true;
    };

    // (F1) Dạng xếp từ / xếp câu — các chip rời nằm trong block.
    const toks = chipTokensOf(item);
    if (toks.length >= 3) {
      let idx = null;
      try { idx = leafTextIndex(block); } catch (_) {}
      const chips = matchChipsIn(idx, toks);
      if (chips && chips.length) {
        for (const c of chips) {
          if (!ok(c.el)) continue;
          this.markChipEl(c.el, c.ord);
          if (!markedEls.includes(c.el)) markedEls.push(c.el);
          hits.add(c.el);
        }
        if (hits.size) { this.markBlockEl(block); return hits.size; }
      }
    }

    // (F2) Khớp theo chỉ số option GỐC (ind / data-ind) — ưu tiên cao nhất.
    const groups = (item.correctIndexGroups && item.correctIndexGroups.length)
      ? item.correctIndexGroups
      : (item.correctIndices && item.correctIndices.length ? [item.correctIndices] : null);
    if (groups) {
      const wanted = new Set();
      for (const g of groups) for (const v of (g || [])) if (v != null) wanted.add(String(v));
      if (wanted.size) {
        let opts = [];
        try { opts = Array.from(block.querySelectorAll('[ind],[data-ind]')); } catch (_) {}
        for (const el of opts.slice(0, 120)) {
          const ind = el.getAttribute('ind') != null ? el.getAttribute('ind') : el.getAttribute('data-ind');
          if (ind == null || !wanted.has(String(ind))) continue;
          if (!this.visible(el)) continue;
          markHit(el);
        }
        if (hits.size) { this.markBlockEl(block); return hits.size; }
      }
    }

    // (F3) Khớp TEXT — chỉ trong block này, chỉ khi khớp TUYỆT ĐỐI (score 3).
    let cands = [];
    try {
      cands = Array.from(block.querySelectorAll(
        'li,td,label,span.qsign,.qselect,[class*="option"],[class*="choice"],' +
        '[role="radio"],[role="checkbox"],[data-value],[ind]'
      )).slice(0, 200);
    } catch (_) {}
    const prepped = [];
    for (const el of cands) {
      if (!this.visible(el)) continue;
      const raw = (el.textContent || '').replace(/\s+/g, ' ').trim();
      if (!raw || raw.length > 400) continue;
      const n = this.canon(raw);
      if (!n) continue;
      // optionTarget() làm closest + querySelectorAll → chỉ gọi khi phần tử
      // CHƯA phải option; nếu đã là li/td/label/.qselect thì nó trả chính el.
      const looks = /^(LI|TD|LABEL|TR)$/.test(el.tagName)
        || /qselect|option|choice/i.test(String(el.className || ''));
      prepped.push({ el, n, l: n, target: looks ? el : this.optionTarget(el) });
    }
    for (const a of answers) {
      const c = this.canonAnswer(a);
      if (!c.n) continue;
      let best = null;
      for (const cd of prepped) {
        if (hits.has(cd.target) || hits.has(cd.el)) continue;
        const sc = this.matchScore(cd, c.n, c.l);
        if (!sc || sc < 3) continue;
        if (!best || sc > best.sc
            || (sc === best.sc && this.prio(cd.target) > this.prio(best.cd.target))) best = { cd, sc };
      }
      if (!best) continue;
      const t = best.cd.target;
      if (!ok(t)) continue;
      this.markEl(t, 'hit');
      if (!markedEls.includes(t)) markedEls.push(t);
      hits.add(t);
    }
    if (hits.size) { this.markBlockEl(block); return hits.size; }

    // (F4) Ô input cần điền (fill-in / word form) — trong block của câu này.
    let inputs = [];
    try {
      inputs = Array.from(block.querySelectorAll('input,textarea')).filter(inp => {
        const tp = (inp.type || '').toLowerCase();
        if (['hidden','radio','checkbox','submit','button'].includes(tp)) return false;
        try { return inp.getClientRects().length > 0; } catch (_) { return false; }
      }).slice(0, 20);
    } catch (_) {}
    if (inputs.length) {
      const limit = Math.max(1, Math.min(answers.length || 1, inputs.length));
      for (let i = 0; i < limit && i < inputs.length; i++) markInput(inputs[i]);
    }
    if (hits.size) { this.markBlockEl(block); return hits.size; }
    return 0;
  },

  // Block có đang hiển thị không? (user đang xem câu khác → rect 0×0)
  blockShown(block) {
    try {
      if (this.visible(block)) return true;
      const probes = block.querySelectorAll
        ? block.querySelectorAll('.qselect,li,td,input,textarea,[ind],[data-ind],[role="radio"],[role="checkbox"]')
        : [];
      for (const el of Array.from(probes).slice(0, 8)) {
        if (this.visible(el)) return true;
      }
    } catch (_) {}
    return false;
  },

  // ── Chạy 1 pass: resolve scope 1 lần, rồi áp cho các câu pending ──
  run() {
    if (!isLicenseActive()) { this.clear(); return; }
    if (!RT.settings.highlightPage) return;
    if (this._running) return;
    this._running = true;
    this.ensureCss();
    this.startRecheck();

    const self = this;
    // Capture generation: nếu license lock (hoặc clear do lock) xảy ra giữa chừng thì run này
    // phải dừng, không được quay lại tô DOM.
    const gen = this._generation;
    const stale = () => gen !== self._generation || !isLicenseActive();
    const bail = () => {
      if (!isLicenseActive()) { try { self.clear(); } catch (_) {} }
      if (gen === self._generation) self._running = false;
    };
    (async () => {
      let scope = null;
      try {
        const cached = self.scopeIfFresh();
        if (cached && cached._sig === self._scopeSig) scope = cached;
        else { scope = await self.resolveScope(); }
      } catch (_) { scope = null; }
      if (stale()) { bail(); return; }   // license có thể đã đổi trong lúc await resolveScope()
      if (scope) {
        if (scope._sig !== self._scopeSig) {
          // Câu đang hiển thị đã đổi → bỏ toàn bộ dấu cũ, cho mọi câu chạy lại.
          self.clear();
          self._scopeSig = scope._sig;
          self.items.forEach(it => { it.done = false; it.tries = 0; it.els = []; it._cycles = 0; it._rearmAt = 0; });
          self.attachScopeObs(scope);
        }
        self._scope = scope;
        self._scopeT = Date.now();
      }

      // UI cũ: câu chỉ xuất hiện trên trang khi user mở tới nó → hồi sinh các
      // câu đã hết lượt thử (giãn dần, tối đa 6 vòng) để bắt được lúc mở câu.
      const rearmed = self.rearmExhausted();

      const pending = [];
      for (const it of self.items.values()) if (!it.done && it.tries < 8) pending.push(it);
      if (!pending.length) { self._running = false; return; }

      let i = 0;
      const step = () => {
        if (stale()) { bail(); return; }
        const t0 = Date.now();
        while (i < pending.length && Date.now() - t0 < 8) {
          if (stale()) { bail(); return; }
          const it = pending[i++];
          it.tries++;
          try { if (self.applyOne(it, scope)) it.done = true; } catch (e) { L.warn('PageHL applyOne:', e); }
        }
        if (i < pending.length) { safeTimeout(step, 30); return; }
        self._running = false;
        const failed = pending.filter(x => !x.done && x.tries >= 8);
        if (failed.length) {
          L.log('PageHL: chưa tô được', failed.length, 'câu (không có trên trang / đáp án không khớp)');
        }
        // Retry nhẹ: chỉ khi còn câu pending VÀ scope vẫn tồn tại (user chưa
        // chuyển câu). Không quét lại toàn trang.
        if (rearmed || pending.some(x => !x.done && x.tries < 8)) self.schedule(2500);
      };
      step();
    })().catch(e => { if (gen === self._generation) self._running = false; L.warn('PageHL run:', e); });
  },

  // ── Vue/re-render có thể gỡ mất class đã đánh dấu → kiểm tra & đánh dấu lại ──
  startRecheck() {
    if (this._recheckId) return;
    this._recheckId = setInterval(() => {
      try {
        // Self-healing Highlight KHÔNG được chạy khi license không active.
        if (!isLicenseActive()) { this.clear(); return; }
        if (!RT.settings.highlightPage || !this.items.size) return;
        // Tab ẩn: user không nhìn thấy highlight, mà vòng check này ép layout
        // trên mọi option đã đánh dấu → bỏ qua cho tới khi tab hiện lại.
        if (document.hidden) return;
        // RẺ: chỉ xem các node đã đánh dấu (thường ≤ 10 node), không quét DOM.
        let need = false;
        for (const it of this.items.values()) {
          if (!it.done) continue;
          const alive = (it.els || []).some(el =>
            el.isConnected && el.getAttribute('data-olm-hl') &&
            (el.classList.contains('olm-hl-hit') || el.classList.contains('olm-hl-input')
              || el.classList.contains('olm-hl-chip')) &&
            this.visible(el));
          if (!alive) { it.done = false; it.tries = 0; need = true; }
        }
        if (this.rearmExhausted()) need = true;
        if (need) this.schedule(200);
      } catch (_) {}
    }, 4000);
  },
  stopRecheck() {
    if (this._recheckId) { clearInterval(this._recheckId); this._recheckId = null; }
    this._detachScopeObs();
  },

  clear() {
    // Quét document + các shadow root đã biết. KHÔNG quét toàn bộ cây shadow
    // (bản cũ gọi rootsFresh() → querySelectorAll('*') toàn trang mỗi lần clear).
    const scopes = [];
    try { scopes.push(document); } catch (_) {}
    if (this._scope && this._scope.root) scopes.push(this._scope.root);
    try {
      document.querySelectorAll(QUIZ_HOST_SEL).forEach(h => { if (h.shadowRoot) scopes.push(h.shadowRoot); });
    } catch (_) {}
    const seen = new Set();
    for (const r of scopes) {
      if (!r || seen.has(r)) continue;
      seen.add(r);
      try {
        r.querySelectorAll('[data-olm-hl]').forEach(el => this.unmarkEl(el));
        r.querySelectorAll('.olm-hl-hit,.olm-hl-input,.olm-hl-chip').forEach(el => this.unmarkEl(el));
        r.querySelectorAll('.olm-hl-block').forEach(el => el.classList.remove('olm-hl-block'));
      } catch (_) {}
    }
  },

  reset() {
    clearTimeout(this.timer);
    this.timer = 0;
    this.invalidateScope();
    this._scopeSig = '';
    this.items.clear();
    this.clear();
  },

  refreshHighlightCss() {
    this.cssReady = false;
    const old = document.getElementById('olm-highlight-css'); if (old) old.remove();
    this.ensureCss();
  },

  setEnabled(on) {
    const enabled = !!on;
    RT.settings.highlightPage = enabled;
    RT.settings.highlight = enabled;          // key cũ (v1.1) — giữ đồng bộ
    Store.saveSettings();
    const btn = document.getElementById('hl1-btn');
    if (btn) {
      btn.textContent = enabled ? 'Highlight 1 ●' : 'Highlight 1 ○';
      btn.classList.toggle('hl-on', enabled);
      btn.title = enabled
        ? 'Highlight 1 — đáp án trên TRANG: BẬT (bấm để tắt)'
        : 'Highlight 1 — đáp án trên TRANG: TẮT (bấm để bật)';
    }
    if (enabled) {
      this.ensureCss();
      this.startRecheck();
      // Bật lại → cho phép apply lại toàn bộ câu đã highlight trước đó
      this.items.forEach(it => { it.done = false; it.tries = 0; it.els = []; it._cycles = 0; it._rearmAt = 0; });
      this.invalidateScope();
      this.schedule(150);
    } else {
      clearTimeout(this.timer);
      this.stopRecheck();
      this.invalidateScope();
      this.clear();
    }
  },
};

// ============================================================
// PANEL CSS
// ============================================================
const PANEL_CSS = `
  /* ── OLM Panel by NTH v1.3 ── */
  :root {
    --olm-accent: #bf5fff;
    --olm-accent2: #d480ff;
    --olm-text: #e8c8ff;
    --olm-text-dim: rgba(var(--olm-text-rgb),.55);
    --olm-bg: #0d0a14;
    --olm-bg-deep: #08060f;
    --olm-bg-card: rgba(var(--olm-accent-rgb),.05);
    --olm-border: rgba(var(--olm-accent-rgb),.35);
    --olm-border-strong: #bf5fff;
    --olm-green: rgba(var(--olm-hl1-rgb),.6);
    --olm-green-dim: rgba(var(--olm-hl1-rgb),.2);
    --olm-radius: 10px;
    --olm-radius-sm: 6px;
    --olm-shadow: 0 8px 32px rgba(0,0,0,.7), 0 0 0 1px rgba(var(--olm-accent-rgb),.25), 0 0 40px rgba(var(--olm-accent-rgb),.12);
    --olm-trans: all .18s cubic-bezier(.4,0,.2,1);
  }

  /* ── Main container ── */
  #olm-answers-container {
    position: fixed;
    top: 14px;
    right: 14px;
    width: 26vw;
    min-width: 280px;
    max-width: 520px;
    max-height: 86vh;
    border-radius: var(--olm-radius);
    z-index: 2147483647;
    display: flex;
    flex-direction: column;
    font-family: 'JetBrains Mono','Fira Code','Consolas','Courier New', monospace;
    font-size: 12px;
    resize: both;
    overflow: hidden;
    background: var(--olm-bg);
    border: 1px solid var(--olm-border);
    box-shadow: var(--olm-shadow);
    transition: opacity .22s cubic-bezier(.4,0,.2,1), transform .22s cubic-bezier(.4,0,.2,1);
    color: var(--olm-text);
    isolation: isolate;
    will-change: transform;
    backdrop-filter: blur(2px);
    --olm-panel-bg-image: none;
    --olm-panel-bg-opacity: .18;
    --olm-panel-bg-blur: 0px;
  }
  #olm-answers-container::before {
    content: '';
    position: absolute;
    inset: 0;
    z-index: 0;
    pointer-events: none;
    background-image: var(--olm-panel-bg-image);
    background-size: cover;
    background-position: center;
    background-repeat: no-repeat;
    opacity: var(--olm-panel-bg-opacity);
    filter: blur(var(--olm-panel-bg-blur));
    transform: scale(1.02);
  }
  #olm-answers-container > * { position: relative; z-index: 1; }
  #olm-answers-container.hidden {
    opacity: 0;
    transform: scale(.96) translateY(-8px);
    pointer-events: none;
  }

  /* ── Header ── */
  .olm-answers-header {
    position: relative;
    z-index: 1;
    padding: 11px 14px 9px;
    background: color-mix(in srgb, var(--olm-bg-deep) 78%, transparent);
    border-bottom: 1px solid var(--olm-border);
    cursor: move;
    user-select: none;
    display: flex;
    align-items: center;
    gap: 8px;
    border-radius: var(--olm-radius) var(--olm-radius) 0 0;
  }
  .olm-header-drag-icon {
    display: flex;
    flex-direction: column;
    gap: 3px;
    opacity: .4;
    flex-shrink: 0;
  }
  .olm-header-drag-icon span {
    display: block;
    width: 16px;
    height: 2px;
    background: var(--olm-accent);
    border-radius: 2px;
  }
  .olm-header-info {
    flex: 1;
    min-width: 0;
    display: flex;
    flex-direction: column;
    gap: 2px;
  }
  .olm-header-title {
    font-size: 12px;
    font-weight: 700;
    letter-spacing: .6px;
    color: var(--olm-accent);
    text-shadow: 0 0 12px rgba(var(--olm-accent-rgb),.5);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .olm-header-sub {
    font-size: 9px;
    color: var(--olm-text-dim);
    letter-spacing: .3px;
  }
  .olm-header-hint {
    font-size: 8.5px;
    color: var(--olm-green-dim);
    letter-spacing: .2px;
    margin-top: 1px;
  }
  .olm-header-collapse-btn {
    flex-shrink: 0;
    width: 26px;
    height: 26px;
    border-radius: 50%;
    background: rgba(var(--olm-accent-rgb),.1);
    border: 1px solid var(--olm-border);
    color: var(--olm-accent);
    cursor: pointer;
    font-size: 13px;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: var(--olm-trans);
    line-height: 1;
    padding: 0;
  }
  .olm-header-collapse-btn:hover {
    background: rgba(var(--olm-accent-rgb),.22);
    border-color: var(--olm-accent);
    transform: scale(1.08);
  }

  /* ── Scale bar (below header) ── */
  .olm-scale-bar {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 5px 14px;
    background: rgba(var(--olm-accent-rgb),.04);
    border-bottom: 1px solid var(--olm-border);
    font-size: 10px;
    color: var(--olm-text-dim);
    flex-shrink: 0;
  }
  .olm-scale-bar label { white-space: nowrap; flex-shrink: 0; }
  .olm-scale-bar input[type=range] {
    flex: 1;
    height: 3px;
    accent-color: var(--olm-accent);
    cursor: pointer;
    min-width: 0;
  }
  .olm-scale-bar .olm-scale-val {
    min-width: 34px;
    text-align: right;
    color: var(--olm-accent);
    font-weight: 700;
    flex-shrink: 0;
  }

  /* ── Content area ── */
  #olm-answers-content {
    padding: 10px;
    margin: 0;
    flex-grow: 1;
    overflow-y: auto;
    background: color-mix(in srgb, var(--olm-bg) 78%, transparent);
    scrollbar-width: thin;
    scrollbar-color: var(--olm-accent) transparent;
  }
  #olm-answers-content::-webkit-scrollbar { width: 4px; }
  #olm-answers-content::-webkit-scrollbar-track { background: transparent; }
  #olm-answers-content::-webkit-scrollbar-thumb { background: rgba(var(--olm-accent-rgb),.4); border-radius: 4px; }
  #olm-answers-content::-webkit-scrollbar-thumb:hover { background: var(--olm-accent); }

  /* ── Batch ── */
  .olm-batch { margin-bottom: 12px; }
  .olm-batch-header-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 5px 8px;
    margin-bottom: 7px;
    background: var(--olm-green-dim);
    border-radius: var(--olm-radius-sm);
    font-size: 9.5px;
    color: var(--olm-green);
    letter-spacing: .3px;
  }

  /* ── Question card ── */
  .qa-block {
    padding: 9px 11px;
    border: 1px solid var(--olm-border);
    border-left: 3px solid var(--olm-border-strong);
    border-radius: var(--olm-radius-sm);
    margin-bottom: 8px;
    background: var(--olm-bg-card);
    transition: border-color .15s, background .15s;
  }
  .qa-block:hover {
    background: rgba(var(--olm-accent-rgb),.08);
    border-color: rgba(var(--olm-accent-rgb),.5);
  }
  .qa-block .question-content {
    font-weight: 500;
    color: #d4aaff;
    margin-bottom: 5px;
    font-size: 11px;
    line-height: 1.5;
  }

  /* ── Answer list ── */
  .olm-hack-answer-ul {
    list-style: none !important;
    margin: 0 !important;
    padding: 0 !important;
  }
  .olm-hack-answer-ul li {
    display: flex !important;
    align-items: baseline !important;
    gap: 7px !important;
    padding: 5px 9px !important;
    margin: 4px 0 !important;
    background: rgba(var(--olm-accent-rgb),.09) !important;
    border-radius: var(--olm-radius-sm) !important;
    border: none !important;
    border-left: 2px solid var(--olm-accent) !important;
    color: var(--olm-accent) !important;
    font-size: 11px !important;
    font-family: inherit !important;
    transition: background .14s !important;
    line-height: 1.4 !important;
  }
  .olm-hack-answer-ul li::before {
    content: '▸';
    font-size: 9px;
    opacity: .6;
    flex-shrink: 0;
  }
  .olm-hack-answer-ul li:hover {
    background: rgba(var(--olm-accent-rgb),.18) !important;
  }

  /* ── Highlight 2: tô sáng list đáp án trong PANEL (nút footer) ── */
  #olm-answers-container.olm-hl2-on .olm-hack-answer-ul li {
    background-image: linear-gradient(180deg, rgba(var(--olm-hl2-rgb),.20), rgba(var(--olm-hl2-rgb),.10)) !important;
    background-color: rgba(var(--olm-hl2-rgb),.14) !important;
    border-left: 3px solid rgba(var(--olm-hl2-rgb),.95) !important;
    color: rgb(var(--olm-hl2-rgb)) !important;
    font-weight: 600 !important;
    box-shadow: inset 0 0 0 1px rgba(var(--olm-hl2-rgb),.30), 0 0 10px rgba(var(--olm-hl2-rgb),.16) !important;
    text-shadow: 0 0 6px rgba(var(--olm-hl2-rgb),.35);
  }
  #olm-answers-container.olm-hl2-on .olm-hack-answer-ul li:hover {
    background-image: none !important;
    background-color: rgba(var(--olm-hl2-rgb),.26) !important;
    box-shadow: inset 0 0 0 1px rgba(var(--olm-hl2-rgb),.5), 0 0 16px rgba(var(--olm-hl2-rgb),.35) !important;
  }
  #olm-answers-container.olm-hl2-on .olm-hack-answer-ul li::before {
    content: '✔';
    color: rgba(var(--olm-hl2-rgb),.95);
    opacity: 1;
  }
  #olm-answers-container.olm-hl2-on .content-container[data-type="answer"] {
    border-top-color: rgba(var(--olm-hl2-rgb),.5);
    border-radius: 6px;
    box-shadow: 0 0 14px rgba(var(--olm-hl2-rgb),.12);
  }

  /* ── Flash: đáp án vừa render xong (kể cả khi lấy từ cache) ── */
  .content-container.olm-ans-pop {
    animation: olm-ans-in .95s cubic-bezier(.22,1,.36,1) 1;
  }
  @keyframes olm-ans-in {
    0%   { opacity: .2; transform: translateY(-6px); filter: brightness(2.4); }
    55%  { filter: brightness(1.4); }
    100% { opacity: 1; transform: none; filter: none; }
  }
  /* Từng dòng đáp án "nhảy" ra theo lượt — chỉ khi Highlight 2 BẬT */
  #olm-answers-container.olm-hl2-on .content-container.olm-ans-pop .olm-hack-answer-ul li {
    animation: olm-ans-li .8s ease-out both;
  }
  #olm-answers-container.olm-hl2-on .content-container.olm-ans-pop .olm-hack-answer-ul li:nth-child(1) { animation-delay: 0s; }
  #olm-answers-container.olm-hl2-on .content-container.olm-ans-pop .olm-hack-answer-ul li:nth-child(2) { animation-delay: .08s; }
  #olm-answers-container.olm-hl2-on .content-container.olm-ans-pop .olm-hack-answer-ul li:nth-child(3) { animation-delay: .16s; }
  #olm-answers-container.olm-hl2-on .content-container.olm-ans-pop .olm-hack-answer-ul li:nth-child(4) { animation-delay: .24s; }
  #olm-answers-container.olm-hl2-on .content-container.olm-ans-pop .olm-hack-answer-ul li:nth-child(n+5) { animation-delay: .32s; }
  @keyframes olm-ans-li {
    0%   { box-shadow: 0 0 0 7px rgba(var(--olm-hl2-rgb),.55); opacity: .3; }
    100% { box-shadow: inset 0 0 0 1px rgba(var(--olm-hl2-rgb),.3), 0 0 10px rgba(var(--olm-hl2-rgb),.16); opacity: 1; }
  }
  .olm-footer-btn.hl-on {
    background: rgba(var(--olm-hl2-rgb),.14) !important;
    border-color: rgba(var(--olm-hl2-rgb),.7) !important;
    color: rgb(var(--olm-hl2-rgb)) !important;
  }
  .olm-footer-btn.hl-on:hover {
    background: rgba(var(--olm-hl2-rgb),.24) !important;
    color: rgb(var(--olm-hl2-rgb)) !important;
  }

  /* ── MathType-style rendering (phân số / căn / lũy thừa) ── */
  .olm-math .olm-frac {
    display: inline-flex;
    flex-direction: column;
    vertical-align: -.45em;
    text-align: center;
    margin: 0 .16em;
    font-style: normal;
    line-height: 1.15;
  }
  .olm-math .olm-frac-n {
    border-bottom: 1px solid currentColor;
    padding: 0 .3em .05em;
    font-size: .9em;
  }
  .olm-math .olm-frac-sep { display: none; }
  .olm-math .olm-frac-d {
    padding: .05em .3em 0;
    font-size: .9em;
  }
  .olm-math .olm-sqrt {
    display: inline-flex;
    align-items: flex-start;
    font-style: normal;
    margin: 0 .1em;
  }
  .olm-math .olm-sqrt > .olm-sqrt-b {
    border-top: 1px solid currentColor;
    padding: 0 .18em;
    margin-top: .1em;
  }
  .olm-math .olm-plain { font-style: normal; }
  .olm-math .olm-over { border-top: 1px solid currentColor; }
  .olm-math sup, .olm-math sub { font-size: .74em; }

  /* ── Content container ── */
  .content-container {
    padding: 5px 0 0 0;
    border-top: 1px solid var(--olm-border);
    margin-top: 5px;
  }
  p.olm-not-found {
    margin: 0;
    font-style: italic;
    color: var(--olm-text-dim);
    font-size: 10px;
    padding: 2px 0;
  }

  /* ── Math inline span ── */
  .olm-math {
    color: var(--olm-accent2, #d480ff);
    font-style: italic;
    letter-spacing: .2px;
  }

  /* ── Question type badge ── */
  .olm-qtype-badge {
    display: inline-block;
    font-size: 8.5px;
    font-weight: 700;
    letter-spacing: .5px;
    padding: 1px 6px;
    border-radius: 3px;
    margin-bottom: 4px;
    text-transform: uppercase;
    opacity: .85;
  }
  .olm-qtype-mc     { background: rgba(0,191,255,.15); color: #00bfff; }
  .olm-qtype-tf     { background: rgba(var(--olm-hl1-rgb),.12);  color: #39ff14; }
  .olm-qtype-fill   { background: rgba(255,165,0,.15);  color: #ffa500; }
  .olm-qtype-match  { background: rgba(255,105,180,.15);color: #ff69b4; }
  .olm-qtype-order  { background: rgba(var(--olm-accent-rgb),.2);  color: #bf5fff; }
  .olm-qtype-essay  { background: rgba(150,150,150,.2); color: #aaa; }

  /* ── Footer ── */
  #olm-answers-footer {
    padding: 8px 10px;
    background: color-mix(in srgb, var(--olm-bg-deep) 78%, transparent);
    border-top: 1px solid var(--olm-border);
    border-radius: 0 0 var(--olm-radius) var(--olm-radius);
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    gap: 5px;
    flex-shrink: 0;
  }

  /* ── Buttons ── */
  .olm-btn-primary {
    padding: 6px 13px;
    background: var(--olm-accent);
    border: none;
    color: #0d0014;
    border-radius: var(--olm-radius-sm);
    cursor: pointer;
    font-weight: 700;
    font-size: 11px;
    font-family: inherit;
    letter-spacing: .4px;
    box-shadow: 0 2px 10px rgba(var(--olm-accent-rgb),.35);
    transition: var(--olm-trans);
    white-space: nowrap;
  }
  .olm-btn-primary:hover {
    background: var(--olm-accent2);
    box-shadow: 0 2px 18px rgba(var(--olm-accent-rgb),.55);
    transform: translateY(-1px);
  }
  .olm-btn-primary:active { transform: translateY(0); }

  .olm-footer-btn {
    padding: 6px 10px;
    background: rgba(var(--olm-accent-rgb),.07);
    border: 1px solid var(--olm-border);
    color: var(--olm-text-dim);
    border-radius: var(--olm-radius-sm);
    cursor: pointer;
    font-size: 10px;
    font-family: inherit;
    letter-spacing: .3px;
    transition: var(--olm-trans);
    white-space: nowrap;
    min-height: 30px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
  }
  .olm-footer-btn:hover {
    background: rgba(var(--olm-accent-rgb),.16);
    border-color: var(--olm-accent);
    color: var(--olm-accent);
    transform: translateY(-1px);
  }
  .olm-footer-btn:active { transform: translateY(0); }
  .olm-footer-btn.danger {
    border-color: rgba(255,68,68,.4);
    color: rgba(255,100,100,.8);
  }
  .olm-footer-btn.danger:hover {
    background: rgba(255,68,68,.12);
    border-color: #ff4444;
    color: #ff6666;
  }

  /* ── Night mode ── */
  #olm-answers-container.olm-night {
    --olm-bg: #04020a;
    --olm-bg-deep: #020108;
    --olm-bg-card: rgba(var(--olm-accent-rgb),.03);
  }

  /* ── Floating toggle button (collapsed state) ── */
  #olm-float-btn {
    position: fixed;
    z-index: 2147483647;
    width: 44px;
    height: 44px;
    border-radius: 50%;
    background: linear-gradient(135deg, #1a0d2e 0%, #0d0a14 100%);
    border: 2px solid var(--olm-accent);
    color: var(--olm-accent);
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 18px;
    box-shadow: 0 0 0 4px rgba(var(--olm-accent-rgb),.15), 0 4px 20px rgba(0,0,0,.6);
    transition: box-shadow .2s, transform .2s, border-color .2s;
    touch-action: none;
    user-select: none;
    -webkit-tap-highlight-color: transparent;
  }
  #olm-float-btn:hover {
    box-shadow: 0 0 0 6px rgba(var(--olm-accent-rgb),.25), 0 6px 28px rgba(0,0,0,.7);
    transform: scale(1.07);
    border-color: var(--olm-accent2);
  }
  #olm-float-btn:active { transform: scale(.96); }
  #olm-float-btn.olm-pulse {
    animation: olm-pulse-ring 1.8s ease-out infinite;
  }
  @keyframes olm-pulse-ring {
    0%   { box-shadow: 0 0 0 4px rgba(var(--olm-accent-rgb),.2), 0 4px 20px rgba(0,0,0,.6); }
    50%  { box-shadow: 0 0 0 8px rgba(var(--olm-accent-rgb),.06), 0 4px 20px rgba(0,0,0,.6); }
    100% { box-shadow: 0 0 0 4px rgba(var(--olm-accent-rgb),.2), 0 4px 20px rgba(0,0,0,.6); }
  }

  /* ── Settings modal ── */
  #olm-settings-modal {
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background: var(--olm-bg);
    border: 1px solid var(--olm-border);
    border-top: 3px solid var(--olm-accent);
    padding: 22px;
    z-index: 2147483648;
    width: min(90vw, 420px);
    border-radius: var(--olm-radius);
    box-shadow: 0 20px 60px rgba(0,0,0,.8), 0 0 0 1px rgba(var(--olm-accent-rgb),.2);
    color: var(--olm-text);
    font-family: 'JetBrains Mono','Fira Code','Consolas','Courier New', monospace;
    max-height: 90vh;
    overflow-y: auto;
  }
  #olm-settings-modal h3 {
    margin: 0 0 18px;
    color: var(--olm-accent);
    font-size: 13px;
    letter-spacing: .5px;
    display: flex;
    align-items: center;
    gap: 7px;
  }
  .olm-setting-row {
    margin: 12px 0;
  }
  .olm-setting-row label {
    display: block;
    color: var(--olm-text-dim);
    font-size: 10px;
    letter-spacing: .4px;
    margin-bottom: 5px;
    text-transform: uppercase;
  }
  .olm-setting-row input[type=range] {
    width: 100%;
    height: 4px;
    accent-color: var(--olm-accent);
    cursor: pointer;
    border-radius: 2px;
  }
  .olm-setting-row select {
    width: 100%;
    padding: 7px 10px;
    background: var(--olm-bg-deep);
    border: 1px solid var(--olm-border);
    color: var(--olm-accent);
    border-radius: var(--olm-radius-sm);
    font-family: inherit;
    font-size: 11px;
    cursor: pointer;
  }
  .olm-range-row {
    display: flex;
    align-items: center;
    gap: 10px;
  }
  .olm-range-row input[type=range] { flex: 1; }
  .olm-range-val {
    min-width: 38px;
    text-align: right;
    color: var(--olm-accent);
    font-size: 11px;
    font-weight: 700;
  }
  #olm-settings-modal .olm-btn-primary {
    width: 100%;
    margin-top: 16px;
    padding: 9px;
    font-size: 12px;
  }

  /* ── License Section ── */
  .olm-license-section {
    padding: 10px 12px;
    background: rgba(var(--olm-accent-rgb),.04);
    border-bottom: 1px solid var(--olm-border);
    flex-shrink: 0;
  }
  .olm-license-title {
    font-size: 9px;
    font-weight: 700;
    letter-spacing: .8px;
    color: var(--olm-text-dim);
    text-transform: uppercase;
    margin-bottom: 7px;
    display: flex;
    align-items: center;
    gap: 5px;
  }
  .olm-license-title::before {
    content: '';
    display: inline-block;
    width: 6px;
    height: 6px;
    border-radius: 50%;
    background: var(--olm-accent);
    opacity: .5;
  }
  .olm-license-input-row {
    display: flex;
    gap: 6px;
    align-items: stretch;
    margin-bottom: 6px;
  }
  .olm-license-input {
    flex: 1;
    min-width: 0;
    padding: 6px 9px;
    background: var(--olm-bg-deep);
    border: 1px solid var(--olm-border);
    color: var(--olm-text);
    border-radius: var(--olm-radius-sm);
    font-family: 'JetBrains Mono','Fira Code','Consolas','Courier New', monospace;
    font-size: 10px;
    outline: none;
    letter-spacing: .3px;
    transition: border-color .15s;
  }
  .olm-license-input:focus {
    border-color: var(--olm-accent);
    box-shadow: 0 0 0 2px rgba(var(--olm-accent-rgb),.15);
  }
  .olm-license-input::placeholder { color: rgba(var(--olm-text-rgb),.25); }
  .olm-activate-btn {
    padding: 6px 11px;
    background: var(--olm-accent);
    border: none;
    color: #0d0014;
    border-radius: var(--olm-radius-sm);
    cursor: pointer;
    font-weight: 700;
    font-size: 10px;
    font-family: inherit;
    letter-spacing: .4px;
    white-space: nowrap;
    transition: var(--olm-trans);
    display: flex;
    align-items: center;
    gap: 5px;
    flex-shrink: 0;
  }
  .olm-activate-btn:hover:not(:disabled) {
    background: var(--olm-accent2);
    transform: translateY(-1px);
    box-shadow: 0 2px 12px rgba(var(--olm-accent-rgb),.4);
  }
  .olm-activate-btn:disabled {
    opacity: .55;
    cursor: not-allowed;
  }
  .olm-activate-btn.loading::after {
    content: '';
    width: 10px;
    height: 10px;
    border: 2px solid rgba(13,0,20,.4);
    border-top-color: #0d0014;
    border-radius: 50%;
    animation: olm-spin .6s linear infinite;
    flex-shrink: 0;
  }
  @keyframes olm-spin { to { transform: rotate(360deg); } }
  .olm-license-status {
    font-size: 9.5px;
    padding: 4px 8px;
    border-radius: var(--olm-radius-sm);
    display: flex;
    align-items: center;
    gap: 5px;
    margin-bottom: 6px;
    font-weight: 600;
    letter-spacing: .2px;
  }
  .olm-license-status::before {
    content: '';
    width: 6px;
    height: 6px;
    border-radius: 50%;
    flex-shrink: 0;
  }
  .olm-status-not-activated {
    background: rgba(var(--olm-text-rgb),.05);
    color: var(--olm-text-dim);
    border: 1px solid rgba(var(--olm-text-rgb),.1);
  }
  .olm-status-not-activated::before { background: rgba(var(--olm-text-rgb),.3); }
  .olm-status-activated {
    background: rgba(var(--olm-hl1-rgb),.08);
    color: rgba(var(--olm-hl1-rgb),.9);
    border: 1px solid rgba(var(--olm-hl1-rgb),.2);
  }
  .olm-status-activated::before { background: rgba(var(--olm-hl1-rgb),.8); box-shadow: 0 0 5px rgba(var(--olm-hl1-rgb),.5); }
  .olm-status-invalid-key, .olm-status-expired, .olm-status-device-limit-reached {
    background: rgba(255,68,68,.08);
    color: rgba(255,100,100,.9);
    border: 1px solid rgba(255,68,68,.2);
  }
  .olm-status-invalid-key::before,
  .olm-status-expired::before,
  .olm-status-device-limit-reached::before { background: #ff4444; }
  .olm-status-network-error {
    background: rgba(255,165,0,.08);
    color: rgba(255,180,50,.9);
    border: 1px solid rgba(255,165,0,.2);
  }
  .olm-status-network-error::before { background: orange; }
  .olm-device-id-row {
    font-size: 8.5px;
    color: var(--olm-text-dim);
    display: flex;
    align-items: center;
    gap: 5px;
    flex-wrap: wrap;
    margin-top: 2px;
  }
  .olm-device-id-label { flex-shrink: 0; opacity: .6; }
  .olm-device-id-value {
    color: rgba(var(--olm-accent-rgb),.7);
    font-family: inherit;
    font-size: 8px;
    letter-spacing: .3px;
    word-break: break-all;
    cursor: pointer;
    transition: color .15s;
  }
  .olm-device-id-value:hover { color: var(--olm-accent); }

  /* ── Mobile responsive ── */
  @media (max-width: 600px) {
    #olm-answers-container {
      width: calc(100vw - 20px) !important;
      max-width: calc(100vw - 20px) !important;
      right: 10px !important;
      left: 10px !important;
      top: 10px !important;
      max-height: 70vh;
      font-size: 13px;
      resize: none;
    }
    .olm-footer-btn, .olm-btn-primary {
      padding: 8px 10px !important;
      font-size: 12px !important;
      min-height: 36px !important;
    }
    .olm-hack-answer-ul li {
      font-size: 12px !important;
      padding: 7px 10px !important;
    }
    .olm-scale-bar input[type=range] { height: 5px; }
    #olm-float-btn { width: 50px; height: 50px; font-size: 20px; }
  }
`;

// ============================================================
// PANEL UI
// ============================================================
const Panel = {
  container: null,
  header: null,
  contentArea: null,
  floatBtn: null,
  isCollapsed: false,
  dragState: { isDragging:false, startX:0, startY:0, initialX:0, initialY:0 },
  floatDragState: { isDragging:false, hasMoved:false, startX:0, startY:0, initialX:0, initialY:0 },

  // ── localStorage keys for UI state ──
  LS: {
    collapsed:   'olm_v11_collapsed',
    panelX:      'olm_v11_panel_x',
    panelY:      'olm_v11_panel_y',
    floatX:      'olm_v11_float_x',
    floatY:      'olm_v11_float_y',
    scale:       'olm_v11_scale',
  },

  _lsGet(k, fallback) {
    try { const v = localStorage.getItem(k); return v !== null ? JSON.parse(v) : fallback; } catch (_) { return fallback; }
  },
  _lsSet(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (_) {} },

  // ── License Section ──────────────────────────────────────────
  _createLicenseSection() {
    const sec = document.createElement('div');
    sec.className = 'olm-license-section';
    sec.id = 'olm-license-section';

    // Title
    const title = document.createElement('div');
    title.className = 'olm-license-title';
    title.textContent = 'License';

    // Input row
    const inputRow = document.createElement('div');
    inputRow.className = 'olm-license-input-row';

    const input = document.createElement('input');
    input.type = 'text';
    input.className = 'olm-license-input';
    input.id = 'olm-license-input';
    input.placeholder = 'Nhập License Key...';
    input.autocomplete = 'off';
    input.spellcheck = false;
    // RT.license.key đã được load bởi LM.load() trước khi Panel.init() chạy
    // nên an toàn để dùng trực tiếp ở đây
    if (RT.license.key) input.value = RT.license.key;

    const activateBtn = document.createElement('button');
    activateBtn.className = 'olm-activate-btn';
    activateBtn.id = 'olm-activate-btn';
    activateBtn.textContent = 'Activate';
    activateBtn.addEventListener('click', async () => {
      const key = input.value.trim();
      activateBtn.disabled = true;
      activateBtn.textContent = '';
      activateBtn.classList.add('loading');
      const status = await LM.activate(key);
      activateBtn.classList.remove('loading');
      activateBtn.disabled = false;
      activateBtn.textContent = 'Activate';
      this._updateLicenseStatus(status);
      // Xóa gate và reset flag nếu vừa activated thành công
      if (status === LICENSE_STATUS.ACTIVATED) {
        this._licenseGateShown = false;
        const gate = this.contentArea?.querySelector('.olm-license-gate');
        if (gate) gate.remove();
      }
    });

    inputRow.append(input, activateBtn);

    // Status badge
    const statusEl = document.createElement('div');
    statusEl.id = 'olm-license-status';
    this._renderStatusBadge(statusEl, RT.license.status);

    // Device ID row
    const deviceRow = document.createElement('div');
    deviceRow.className = 'olm-device-id-row';

    const deviceLabel = document.createElement('span');
    deviceLabel.className = 'olm-device-id-label';
    deviceLabel.textContent = 'Device ID:';

    const deviceVal = document.createElement('span');
    deviceVal.className = 'olm-device-id-value';
    deviceVal.id = 'olm-device-id-value';
    deviceVal.title = 'Click để copy';
    deviceVal.textContent = RT.license.deviceId || 'Generating...';
    deviceVal.addEventListener('click', () => {
      const id = deviceVal.textContent;
      if (id && id !== 'Generating...') {
        navigator.clipboard?.writeText(id).catch(() => {});
        const orig = deviceVal.textContent;
        deviceVal.textContent = '✓ Copied!';
        safeTimeout(() => { deviceVal.textContent = orig; }, 1500);
      }
    });

    // Load device ID async
    LM.getDeviceId().then(id => {
      if (id) deviceVal.textContent = id;
    });

    deviceRow.append(deviceLabel, deviceVal);
    sec.append(title, inputRow, statusEl, deviceRow);
    return sec;
  },

  // Render badge trạng thái
  _renderStatusBadge(el, status) {
    const text = LICENSE_STATUS_TEXT[status] || status;
    const cssClass = 'olm-status-' + (status || 'not-activated').replace(/_/g, '-');
    el.className = 'olm-license-status ' + cssClass;
    el.textContent = 'Status: ' + text;
  },

  // Cập nhật badge sau khi activate
  _updateLicenseStatus(status) {
    const el = document.getElementById('olm-license-status');
    if (el) this._renderStatusBadge(el, status);
  },

  applyPanelBackground() {
    if (!this.container) return;
    const bg=RT.settings.panelBackground; let image='none';
    const key=bg==='default'?'default':(typeof bg==='string'&&bg.startsWith('builtin:')?bg.slice(8):null);
    if(key&&BUILTIN_BACKGROUNDS[key]) { try { image=`url("${chrome.runtime.getURL(BUILTIN_BACKGROUNDS[key].path)}")`; } catch(_){} }
    // SECURITY: chỉ chấp nhận data:image hợp lệ (png/jpeg/gif/webp), giới hạn size.
    // Không chấp nhận data:text/html hay scheme lạ để chặn CSS/URL injection.
    else if(typeof bg==='string'&&/^data:image\/(png|jpeg|jpg|gif|webp);base64,/i.test(bg) && bg.length < 4500000) image=`url("${bg}")`;
    this.container.style.setProperty('--olm-panel-bg-image',image);
    // SECURITY: clamp opacity/blur về range hợp lệ trước khi set CSS.
    const op = Number(RT.settings.panelBgOpacity ?? 0.18);
    const bl = Number(RT.settings.panelBgBlur ?? 0);
    this.container.style.setProperty('--olm-panel-bg-opacity',String(Math.min(0.55, Math.max(0, isFinite(op) ? op : 0.18))));
    this.container.style.setProperty('--olm-panel-bg-blur',`${Math.min(12, Math.max(0, isFinite(bl) ? bl : 0))}px`);
  },

  setPanelBackground(dataUrl) {
    // SECURITY: validate trước khi lưu vào settings (chặn storage poisoning).
    if (dataUrl !== 'none' && dataUrl !== 'default' && typeof dataUrl === 'string' && dataUrl.startsWith('builtin:')) {
      const k = dataUrl.slice(8);
      if (!BUILTIN_BACKGROUNDS[k]) return;
    } else if (typeof dataUrl === 'string' && dataUrl.startsWith('data:')) {
      if (!/^data:image\/(png|jpeg|jpg|gif|webp);base64,/i.test(dataUrl) || dataUrl.length > 4500000) return;
    } else if (dataUrl !== 'none' && dataUrl !== 'default' && dataUrl != null) {
      return;
    }
    RT.settings.panelBackground = dataUrl || 'none';
    this.applyPanelBackground();
    Store.saveSettings();
  },

  async readBackgroundFile(file) {
    // SECURITY: chỉ nhận file ảnh thật, giới hạn size, output luôn là
    // image/jpeg từ canvas (không giữ nguyên data URL gốc có thể chứa SVG/HTML).
    if (!file || typeof file.type !== 'string' || !/^image\/(png|jpeg|jpg|gif|webp)$/i.test(file.type)) return;
    if (file.size && file.size > 8_000_000) { alert('Ảnh quá lớn. Hãy chọn ảnh nhỏ hơn.'); return; }
    const dataUrl = await new Promise((resolve, reject) => {
      const r = new FileReader();
      r.onload = () => resolve(r.result);
      r.onerror = reject;
      r.readAsDataURL(file);
    });
    const optimized = await new Promise((resolve) => {
      const img = new Image();
      img.onload = () => {
        const maxW = 1400, maxH = 900;
        const scale = Math.min(1, maxW / img.naturalWidth, maxH / img.naturalHeight);
        const c = document.createElement('canvas');
        c.width = Math.max(1, Math.round(img.naturalWidth * scale));
        c.height = Math.max(1, Math.round(img.naturalHeight * scale));
        c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
        resolve(c.toDataURL('image/jpeg', .78));
      };
      img.onerror = () => resolve(dataUrl);
      img.src = dataUrl;
    });
    if (String(optimized).length > 4_500_000) {
      alert('Ảnh quá lớn sau khi nén. Hãy chọn ảnh nhỏ hơn.');
      return;
    }
    this.setPanelBackground(optimized);
  },

  _hexToRgb(hex) {
    const m=String(hex||'').trim().replace('#','');
    if(!/^[0-9a-fA-F]{6}$/.test(m)) return '57,255,20';
    return `${parseInt(m.slice(0,2),16)},${parseInt(m.slice(2,4),16)},${parseInt(m.slice(4,6),16)}`;
  },
  applyHighlightColors() {
    const h1=RT.settings.highlightPageColor||'#39ff14', h2=RT.settings.highlightPanelColor||'#39ff14';
    document.documentElement.style.setProperty('--olm-hl1-rgb',this._hexToRgb(h1));
    document.documentElement.style.setProperty('--olm-hl2-rgb',this._hexToRgb(h2));
    if(this.container){this.container.style.setProperty('--olm-hl1-rgb',this._hexToRgb(h1));this.container.style.setProperty('--olm-hl2-rgb',this._hexToRgb(h2));}
  },

  applyTheme(name) {
    const colors = COLORS[name] || COLORS.purple;
    let ts = document.getElementById('olm-theme-style');
    if (!ts) {
      ts = document.createElement('style');
      ts.id = 'olm-theme-style';
      (document.head || document.documentElement).appendChild(ts);
    }
    ts.textContent = `
      :root {
        --olm-accent-rgb: ${this._hexToRgb(colors.main)};
        --olm-text-rgb: ${this._hexToRgb(colors.text)};
      }
      #olm-answers-container {
        --olm-accent: ${colors.main};
        --olm-accent2: ${colors.accent};
        --olm-text: ${colors.text};
        --olm-bg: ${colors.bg};
        --olm-bg-deep: ${colors.bg};
        --olm-border-strong: ${colors.main};
        --olm-border: ${colors.main}55;
         --olm-accent-rgb: ${this._hexToRgb(colors.main)};
         --olm-text-rgb: ${this._hexToRgb(colors.text)};
      }
      #olm-float-btn { border-color: ${colors.main}; color: ${colors.main}; }
    `;
    RT.settings.theme = name;
    this.applyHighlightColors();
    Store.saveSettings();
  },

  init() {
    // Guard: nếu container đã tồn tại trong DOM → không init lại (tránh double menu)
    if (this.container && document.body?.contains(this.container)) {
      L.warn('Panel.init() called but panel already mounted — skip');
      return;
    }
    // Reset state nếu container cũ bị xóa khỏi DOM
    this.container = null;
    this.floatBtn  = null;

    // ── Inject CSS ──
    if (!document.getElementById('olm-panel-css')) {
      const style = document.createElement('style');
      style.id = 'olm-panel-css';
      style.textContent = PANEL_CSS;
      (document.head || document.documentElement).appendChild(style);
    }

    // ── Restore UI state from localStorage ──
    this.isCollapsed = this._lsGet(this.LS.collapsed, false);
    const savedScale = this._lsGet(this.LS.scale, RT.settings.zoom);
    RT.settings.zoom = savedScale;

    // ── Main container ──
    this.container = document.createElement('div');
    this.container.id = 'olm-answers-container';
    this.container.setAttribute('data-olm-managed', 'true');

    // Apply size/scale from settings
    this.container.style.width = RT.settings.panelWidth + 'vw';
    this.container.style.maxHeight = RT.settings.panelHeight + 'vh';
    this.container.style.fontSize = (RT.settings.zoom / 100) + 'em';
    if (RT.settings.nightMode) this.container.classList.add('olm-night');

    // Restore panel position
    const px = this._lsGet(this.LS.panelX, null);
    const py = this._lsGet(this.LS.panelY, null);
    if (px !== null && py !== null) {
      this.container.style.right = 'auto';
      this.container.style.left = px + 'px';
      this.container.style.top  = py + 'px';
      RT.panelPos = { x: px, y: py };
    }

    // Hide if collapsed (panel itself hidden, float btn shown)
    if (this.isCollapsed) this.container.style.display = 'none';

    // ── Header ──
    this.header = document.createElement('div');
    this.header.className = 'olm-answers-header';
    this.header.innerHTML = `
      <div class="olm-header-drag-icon">
        <span></span><span></span><span></span>
      </div>
      <div class="olm-header-info">
        <div class="olm-header-title">⚡ OLM Panel by NTH</div>
        <div class="olm-header-sub">v1.3 · author: Quan Ngọc Thành</div>
        <div class="olm-header-hint">[Ctrl+Shift+H] ẩn/hiện · [Ctrl+E] export · [Ctrl+F] tìm</div>
      </div>
    `;
    const collapseBtn = document.createElement('button');
    collapseBtn.className = 'olm-header-collapse-btn';
    collapseBtn.title = 'Thu nhỏ panel';
    collapseBtn.textContent = '−';
    collapseBtn.addEventListener('click', (e) => { e.stopPropagation(); this.collapse(); });
    this.header.appendChild(collapseBtn);

    // ── Scale bar ──
    const scaleBar = document.createElement('div');
    scaleBar.className = 'olm-scale-bar';
    // SECURITY: zoom từ storage có thể bị sửa — clamp về số trong range.
    const _zoomInit = (() => { const n = Number(RT.settings.zoom); return isFinite(n) ? Math.min(150, Math.max(50, n)) : 100; })();
    scaleBar.innerHTML = `
      <label>Scale</label>
      <div class="olm-range-row" style="flex:1;display:flex;align-items:center;gap:8px;">
        <input type="range" id="olm-scale-slider" min="50" max="150" step="5" value="${_zoomInit}">
        <span class="olm-scale-val" id="olm-scale-val">${_zoomInit}%</span>
      </div>
    `;

    // ── Content area ──
    this.contentArea = document.createElement('div');
    this.contentArea.id = 'olm-answers-content';

    // ── Footer ──
    const footer = document.createElement('div');
    footer.id = 'olm-answers-footer';

    const mk = (text, id, cls) => {
      const b = document.createElement('button');
      b.textContent = text;
      b.className = cls || 'olm-footer-btn';
      if (id) b.id = id;
      return b;
    };

    const exportBtn = mk('↓ TXT', 'export-btn', 'olm-btn-primary');
    exportBtn.addEventListener('click', () => this.exportToTxt());

    const clearBtn = mk('🗑 Xóa', 'clear-btn', 'olm-footer-btn danger');
    clearBtn.addEventListener('click', () => {
      this.contentArea.innerHTML = '';
      RT.seenQids.clear();
      RT.questionCounter = 0;
      RT.batchCount = 0;
      Store.clearCache();
      PageHL.reset();
    });

    const cacheBtn = mk('Cache', 'cache-btn', 'olm-footer-btn');
    cacheBtn.addEventListener('click', () => {
      Store.clearCache();
      cacheBtn.textContent = '✓ OK';
      safeTimeout(() => { cacheBtn.textContent = 'Cache'; }, 1500);
    });

    const nightBtn = mk(RT.settings.nightMode ? '☀' : '🌙', 'night-btn', 'olm-footer-btn');
    nightBtn.title = 'Night mode';
    nightBtn.addEventListener('click', () => {
      RT.settings.nightMode = !RT.settings.nightMode;
      this.container.classList.toggle('olm-night', RT.settings.nightMode);
      nightBtn.textContent = RT.settings.nightMode ? '☀' : '🌙';
      Store.saveSettings();
    });

    const filterBtn = mk('🔍', 'filter-btn', 'olm-footer-btn');
    filterBtn.title = 'Tìm kiếm câu';
    filterBtn.addEventListener('click', () => {
      const kw = prompt('Tìm kiếm câu (trống để xóa):');
      if (kw !== null) this.filterAnswers(kw);
    });

    const settingsBtn = mk('⚙', 'settings-btn', 'olm-footer-btn');
    settingsBtn.title = 'Settings';
    settingsBtn.addEventListener('click', () => this.openSettings());

    // ── Highlight 1: phát sáng đáp án đúng TRÊN TRANG olm.vn ──
    const hl1On = !!RT.settings.highlightPage;
    const hl1Btn = mk(hl1On ? 'Highlight 1 ●' : 'Highlight 1 ○', 'hl1-btn',
      'olm-footer-btn' + (hl1On ? ' hl-on' : ''));
    hl1Btn.title = hl1On
      ? 'Highlight 1 — đáp án trên TRANG: BẬT (bấm để tắt)'
      : 'Highlight 1 — đáp án trên TRANG: TẮT (bấm để bật)';
    hl1Btn.addEventListener('click', () => this.toggleHighlightPage());

    // ── Highlight 2: tô sáng list đáp án TRONG PANEL ──
    const hl2On = !!RT.settings.highlightPanel;
    const hl2Btn = mk(hl2On ? 'Highlight 2 ●' : 'Highlight 2 ○', 'hl2-btn',
      'olm-footer-btn' + (hl2On ? ' hl-on' : ''));
    hl2Btn.title = hl2On
      ? 'Highlight 2 — đáp án trong PANEL: BẬT (bấm để tắt)'
      : 'Highlight 2 — đáp án trong PANEL: TẮT (bấm để bật)';
    hl2Btn.addEventListener('click', () => this.toggleHighlightPanel());

    footer.append(exportBtn, clearBtn, cacheBtn, nightBtn, hl1Btn, hl2Btn, filterBtn, settingsBtn);

    // ── License Section ──
    const licenseSection = this._createLicenseSection();

    // ── Assemble ──
    this.container.append(this.header, licenseSection, scaleBar, this.contentArea, footer);
    this.applyTheme(RT.settings.theme);
    this.applyHighlightColors();
    this.applyPanelBackground();

    // ── Highlight state: HL1 = trang, HL2 = panel (độc lập nhau) ──
    this.container.classList.toggle('olm-hl2-on', !!RT.settings.highlightPanel);
    if (RT.settings.highlightPage) PageHL.ensureCss();

    // ── Scale slider listener ──
    scaleBar.querySelector('#olm-scale-slider').addEventListener('input', (e) => {
      const v = +e.target.value;
      RT.settings.zoom = v;
      scaleBar.querySelector('#olm-scale-val').textContent = v + '%';
      this.container.style.fontSize = (v / 100) + 'em';
      this._lsSet(this.LS.scale, v);
      Store.saveSettings();
    });

    // ── Drag (mouse + touch) ──
    this.header.addEventListener('mousedown', (e) => this._dragStart(e));
    this.header.addEventListener('touchstart', (e) => this._touchDragStart(e), { passive: false });

    // ── Float button ──
    this._createFloatBtn();

    // ── Mount ──
    const mount = () => {
      document.body.appendChild(this.container);
      // Float button vẫn append vào DOM (cần cho drag logic) nhưng luôn ẩn
      // User dùng Ctrl+Shift+H để toggle, không dùng float button nữa
      document.body.appendChild(this.floatBtn);
      this.floatBtn.style.display = 'none';
    };
    if (document.body) mount();
    else document.addEventListener('DOMContentLoaded', mount, { once: true });

    // ── Keyboard ──
    // ── Keyboard — dùng capture:true để không bị trang web chặn ──
    window.addEventListener('keydown', (e) => this.onKeyDown(e), true); // capture phase

    // License đang bị khoá lúc mount (boot / panel bị hồi sinh) → hiện Gate ngay.
    if (!isLicenseActive()) {
      this._licenseGateShown = false;
      if (this.isCollapsed) this._gatePending = true;   // hiện khi mở lại
      else this._showLicenseGate();
    }
  },

  // ── Floating toggle button ──
  _createFloatBtn() {
    this.floatBtn = document.createElement('button');
    this.floatBtn.id = 'olm-float-btn';
    this.floatBtn.title = 'Mở OLM Panel';
    this.floatBtn.innerHTML = '⚡';
    this.floatBtn.style.display = 'none';

    // Restore float btn position
    const fx = this._lsGet(this.LS.floatX, null);
    const fy = this._lsGet(this.LS.floatY, null);
    if (fx !== null && fy !== null) {
      this.floatBtn.style.left = fx + 'px';
      this.floatBtn.style.top  = fy + 'px';
      this.floatBtn.style.right = 'auto';
      this.floatBtn.style.bottom = 'auto';
    } else {
      this.floatBtn.style.right = '14px';
      this.floatBtn.style.top   = '14px';
    }

    // Click = expand (only if not dragged)
    this.floatBtn.addEventListener('click', () => {
      if (this.floatDragState.hasMoved) return;
      this.expand();
    });

    // Mouse drag
    this.floatBtn.addEventListener('mousedown', (e) => this._floatDragStart(e));
    // Touch drag
    this.floatBtn.addEventListener('touchstart', (e) => this._floatTouchStart(e), { passive: false });
  },

  collapse() {
    this.isCollapsed = true;
    this._lsSet(this.LS.collapsed, true);
    // Tàng hình hoàn toàn — không hiện float button
    this.container.style.display = 'none';
    if (this.floatBtn) this.floatBtn.style.display = 'none';
    RT.isVisible = false;
  },

  expand() {
    this.isCollapsed = false;
    this._lsSet(this.LS.collapsed, false);
    this.container.style.display = 'flex';
    // Float button vẫn ẩn — chỉ dùng phím tắt để toggle
    if (this.floatBtn) this.floatBtn.style.display = 'none';
    RT.isVisible = true;
    // License bị khoá lúc panel đang thu gọn → hiện Gate ngay khi mở lại.
    if (this._gatePending && !isLicenseActive()) { this._gatePending = false; this._showLicenseGate(); }
    // Smooth entry
    this.container.style.opacity = '0';
    this.container.style.transform = 'scale(.97) translateY(-6px)';
    requestAnimationFrame(() => {
      this.container.style.transition = 'opacity .22s ease, transform .22s ease';
      this.container.style.opacity = '1';
      this.container.style.transform = '';
      safeTimeout(() => { this.container.style.transition = ''; }, 250);
    });
  },

  // ── Panel drag (mouse) ──
  _dragStart(e) {
    if (e.target.closest('button') || e.target.closest('input')) return;
    e.preventDefault();
    const rect = this.container.getBoundingClientRect();
    this.container.style.right = 'auto';
    this.container.style.bottom = 'auto';
    this.container.style.left = rect.left + 'px';
    this.container.style.top  = rect.top + 'px';
    RT.panelPos = { x: rect.left, y: rect.top };
    this.dragState = { isDragging: true, startX: e.clientX, startY: e.clientY, initialX: rect.left, initialY: rect.top };
    const onMove = (ev) => {
      if (!this.dragState.isDragging) return;
      ev.preventDefault();
      const nx = this.dragState.initialX + (ev.clientX - this.dragState.startX);
      const ny = this.dragState.initialY + (ev.clientY - this.dragState.startY);
      this.container.style.left = nx + 'px';
      this.container.style.top  = ny + 'px';
      RT.panelPos = { x: nx, y: ny };
    };
    const onUp = () => {
      this.dragState.isDragging = false;
      this._lsSet(this.LS.panelX, RT.panelPos.x);
      this._lsSet(this.LS.panelY, RT.panelPos.y);
      window.removeEventListener('mousemove', onMove);
      window.removeEventListener('mouseup', onUp);
    };
    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onUp);
  },

  // ── Panel drag (touch) ──
  _touchDragStart(e) {
    if (e.target.closest('button') || e.target.closest('input')) return;
    const t = e.touches[0];
    const rect = this.container.getBoundingClientRect();
    this.container.style.right = 'auto';
    this.container.style.bottom = 'auto';
    this.container.style.left = rect.left + 'px';
    this.container.style.top  = rect.top + 'px';
    const ds = { isDragging: true, startX: t.clientX, startY: t.clientY, initialX: rect.left, initialY: rect.top };
    const onMove = (ev) => {
      if (!ds.isDragging || !ev.touches[0]) return;
      ev.preventDefault();
      const tc = ev.touches[0];
      const nx = ds.initialX + (tc.clientX - ds.startX);
      const ny = ds.initialY + (tc.clientY - ds.startY);
      this.container.style.left = nx + 'px';
      this.container.style.top  = ny + 'px';
      RT.panelPos = { x: nx, y: ny };
    };
    const onEnd = () => {
      ds.isDragging = false;
      this._lsSet(this.LS.panelX, RT.panelPos.x);
      this._lsSet(this.LS.panelY, RT.panelPos.y);
      this.container.removeEventListener('touchmove', onMove);
      this.container.removeEventListener('touchend', onEnd);
    };
    this.container.addEventListener('touchmove', onMove, { passive: false });
    this.container.addEventListener('touchend', onEnd);
  },

  // ── Float button drag (mouse) ──
  _floatDragStart(e) {
    e.preventDefault();
    const rect = this.floatBtn.getBoundingClientRect();
    this.floatDragState = { isDragging: true, hasMoved: false, startX: e.clientX, startY: e.clientY, initialX: rect.left, initialY: rect.top };
    this.floatBtn.style.right = 'auto';
    this.floatBtn.style.bottom = 'auto';
    const onMove = (ev) => {
      if (!this.floatDragState.isDragging) return;
      const dx = ev.clientX - this.floatDragState.startX;
      const dy = ev.clientY - this.floatDragState.startY;
      if (Math.abs(dx) > 3 || Math.abs(dy) > 3) this.floatDragState.hasMoved = true;
      const nx = Math.max(0, Math.min(window.innerWidth - 50,  this.floatDragState.initialX + dx));
      const ny = Math.max(0, Math.min(window.innerHeight - 50, this.floatDragState.initialY + dy));
      this.floatBtn.style.left = nx + 'px';
      this.floatBtn.style.top  = ny + 'px';
    };
    const onUp = () => {
      this.floatDragState.isDragging = false;
      this._lsSet(this.LS.floatX, parseFloat(this.floatBtn.style.left));
      this._lsSet(this.LS.floatY, parseFloat(this.floatBtn.style.top));
      window.removeEventListener('mousemove', onMove);
      window.removeEventListener('mouseup', onUp);
      safeTimeout(() => { this.floatDragState.hasMoved = false; }, 50);
    };
    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onUp);
  },

  // ── Float button drag (touch) ──
  _floatTouchStart(e) {
    const t = e.touches[0];
    const rect = this.floatBtn.getBoundingClientRect();
    this.floatBtn.style.right = 'auto';
    this.floatBtn.style.bottom = 'auto';
    const ds = { hasMoved: false, startX: t.clientX, startY: t.clientY, initialX: rect.left, initialY: rect.top };
    const onMove = (ev) => {
      const tc = ev.touches[0]; if (!tc) return;
      ev.preventDefault();
      const dx = tc.clientX - ds.startX;
      const dy = tc.clientY - ds.startY;
      if (Math.abs(dx) > 5 || Math.abs(dy) > 5) ds.hasMoved = true;
      const nx = Math.max(0, Math.min(window.innerWidth - 50,  ds.initialX + dx));
      const ny = Math.max(0, Math.min(window.innerHeight - 50, ds.initialY + dy));
      this.floatBtn.style.left = nx + 'px';
      this.floatBtn.style.top  = ny + 'px';
    };
    const onEnd = () => {
      this._lsSet(this.LS.floatX, parseFloat(this.floatBtn.style.left));
      this._lsSet(this.LS.floatY, parseFloat(this.floatBtn.style.top));
      if (!ds.hasMoved) this.expand();
      this.floatBtn.removeEventListener('touchmove', onMove);
      this.floatBtn.removeEventListener('touchend', onEnd);
    };
    this.floatBtn.addEventListener('touchmove', onMove, { passive: false });
    this.floatBtn.addEventListener('touchend', onEnd);
  },

  onKeyDown(e) {
    // Ctrl+Shift+H — toggle tàng hình hoàn toàn (capture phase nên không bị trang chặn)
    if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.code === 'KeyH') {
      e.preventDefault(); e.stopPropagation();
      if (this.isCollapsed) this.expand(); else this.collapse();
      return;
    }
    // ShiftRight — giữ lại cho tương thích
    if (e.code === 'ShiftRight' && !e.ctrlKey && !e.metaKey && !e.altKey) {
      e.preventDefault(); e.stopPropagation();
      if (this.isCollapsed) this.expand(); else this.collapse();
      return;
    }
    if (!e.ctrlKey && !e.metaKey) return;
    switch (e.key.toLowerCase()) {
      case 'e': e.preventDefault(); this.exportToTxt(); break;
      case 'f': e.preventDefault(); document.getElementById('filter-btn')?.click(); break;
      case 'l': e.preventDefault(); document.getElementById('night-btn')?.click(); break;
    }
  },

  toggleHighlightPage() {
    PageHL.setEnabled(!RT.settings.highlightPage);
  },

  toggleHighlightPanel() {
    const on = !RT.settings.highlightPanel;
    RT.settings.highlightPanel = on;
    try { this.container?.classList.toggle('olm-hl2-on', on); } catch (_) {}
    const btn = document.getElementById('hl2-btn');
    if (btn) {
      btn.textContent = on ? 'Highlight 2 ●' : 'Highlight 2 ○';
      btn.classList.toggle('hl-on', on);
      btn.title = on
        ? 'Highlight 2 — đáp án trong PANEL: BẬT (bấm để tắt)'
        : 'Highlight 2 — đáp án trong PANEL: TẮT (bấm để bật)';
    }
    Store.saveSettings();
  },

  filterAnswers(keyword) {
    const blocks = this.contentArea?.querySelectorAll('.qa-block') || [];
    if (!keyword || !keyword.trim()) { blocks.forEach(b => b.style.display = ''); return; }
    const k = keyword.toLowerCase();
    let count = 0;
    blocks.forEach(block => {
      const q = block.querySelector('.question-content')?.textContent || '';
      const a = block.querySelector('.content-container')?.textContent || '';
      const match = q.toLowerCase().includes(k) || a.toLowerCase().includes(k);
      block.style.display = match ? '' : 'none';
      if (match) count++;
    });
    L.log(`Filter: ${count} matches for "${keyword}"`);
  },

  applyAnswerListStyles(ul) {
    if (!ul || ul.tagName !== 'UL') return;
    ul.classList.add('olm-hack-answer-ul');
    ul.style.cssText = 'list-style:none;margin:0;padding:0;';
    ul.querySelectorAll(':scope > li').forEach(li => {
      li.style.cssText = 'border-left:2px solid var(--olm-accent,#bf5fff);padding:5px 9px;margin:4px 0;background:rgba(var(--olm-accent-rgb),.09);border-radius:6px;color:var(--olm-accent,#bf5fff);font-size:11px;';
    });
  },

  // Đánh dấu "đáp án vừa hiện ra" → flash phát sáng 1 lần (xem CSS .olm-ans-pop)
  markAnswerShown(cc) {
    if (!cc) return;
    try {
      cc.classList.remove('olm-ans-pop');
      void cc.offsetWidth;   // reflow để animation chạy lại mỗi lần
      cc.classList.add('olm-ans-pop');
      safeTimeout(() => { try { cc.classList.remove('olm-ans-pop'); } catch (_) {} }, 1500);
    } catch (_) {}
  },

  openSettings() {
    if (document.getElementById('olm-settings-modal')) return;
    const themes = Object.keys(COLORS);
    // SECURITY: settings lưu trong storage có thể bị sửa ngoài — clamp/validate
    // trước khi interpolate vào modal.innerHTML (tránh self-XSS qua storage).
    const secNum = (v, d, lo, hi) => {
      const n = Number(v);
      if (!isFinite(n)) return d;
      return Math.min(hi, Math.max(lo, n));
    };
    const secHex = (v, d) => (/^#[0-9a-fA-F]{6}$/.test(String(v || '')) ? String(v) : d);
    const sW = secNum(RT.settings.panelWidth, 25, 15, 80);
    const sH = secNum(RT.settings.panelHeight, 80, 30, 95);
    const sZ = secNum(RT.settings.zoom, 100, 50, 150);
    const sOp = secNum(RT.settings.panelBgOpacity ?? 0.18, 0.18, 0, 0.55);
    const sBl = secNum(RT.settings.panelBgBlur ?? 0, 0, 0, 12);
    const sHl1 = secHex(RT.settings.highlightPageColor, '#39ff14');
    const sHl2 = secHex(RT.settings.highlightPanelColor, '#39ff14');
    const sTheme = COLORS[RT.settings.theme] ? RT.settings.theme : 'purple';
    const modal = document.createElement('div');
    modal.id = 'olm-settings-modal';
    modal.innerHTML = `
      <h3>⚙ Panel Settings</h3>
      <div class="olm-setting-row">
        <label>Width (vw)</label>
        <div class="olm-range-row">
          <input type="range" id="s-w" min="15" max="80" value="${sW}">
          <span class="olm-range-val" id="s-w-v">${sW}vw</span>
        </div>
      </div>
      <div class="olm-setting-row">
        <label>Height (vh)</label>
        <div class="olm-range-row">
          <input type="range" id="s-h" min="30" max="95" value="${sH}">
          <span class="olm-range-val" id="s-h-v">${sH}vh</span>
        </div>
      </div>
      <div class="olm-setting-row">
        <label>Scale (50–150%)</label>
        <div class="olm-range-row">
          <input type="range" id="s-z" min="50" max="150" step="5" value="${sZ}">
          <span class="olm-range-val" id="s-z-v">${sZ}%</span>
        </div>
      </div>
      <div class="olm-setting-row">
        <label>Theme</label>
        <select id="s-t">
          ${themes.map(t => `<option value="${t}" ${sTheme===t?'selected':''}>${t}</option>`).join('')}
        </select>
      </div>
      <div class="olm-setting-row">
        <label>Panel Background</label>
        <div style="display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:6px;">
          <button id="s-bg-default" class="olm-btn-primary" style="margin-top:0;">🌟 Nhân vật vàng</button>
          <button id="s-bg-cherry" class="olm-btn-primary" style="margin-top:0;">🌸 Hoa anh đào</button>
          <button id="s-bg-cosmic" class="olm-btn-primary" style="margin-top:0;">🌍 Địa cầu vũ trụ</button>
          <button id="s-bg-starry" class="olm-btn-primary" style="margin-top:0;">🌌 Đêm sao</button>
          <button id="s-bg-warrior" class="olm-btn-primary" style="margin-top:0;">⚔️ Chiến thần</button>
          <button id="s-bg-upload" class="olm-btn-primary" style="margin-top:0;">🖼 Chọn ảnh</button>
          <button id="s-bg-none" class="olm-btn-primary" style="margin-top:0;grid-column:1/-1;">Tắt nền</button>
        </div>
        <input id="s-bg-file" type="file" accept="image/*" style="display:none">
      </div>
      <div class="olm-setting-row">
        <label>Background opacity</label>
        <div class="olm-range-row">
          <input type="range" id="s-bg-opacity" min="0" max="0.55" step="0.01" value="${sOp}">
          <span class="olm-range-val" id="s-bg-opacity-v">${Math.round(sOp*100)}%</span>
        </div>
      </div>
      <div class="olm-setting-row">
        <label>Background blur</label>
        <div class="olm-range-row">
          <input type="range" id="s-bg-blur" min="0" max="12" step="1" value="${sBl}">
          <span class="olm-range-val" id="s-bg-blur-v">${sBl}px</span>
        </div>
      </div>
      <div class="olm-setting-row">
        <label>Highlight 1 — trên trang</label>
        <div style="display:flex;gap:6px;align-items:center;">
          <select id="s-hl1" style="flex:1;">${Object.entries(HIGHLIGHT_COLORS).map(([k,v]) => `<option value="${v.hex}" ${sHl1===v.hex?'selected':''}>${v.label}</option>`).join('')}</select>
          <input id="s-hl1-custom" type="color" value="${sHl1}" title="Màu tùy chỉnh" style="width:42px;height:32px;padding:2px;">
        </div>
      </div>
      <div class="olm-setting-row">
        <label>Highlight 2 — trong panel</label>
        <div style="display:flex;gap:6px;align-items:center;">
          <select id="s-hl2" style="flex:1;">${Object.entries(HIGHLIGHT_COLORS).map(([k,v]) => `<option value="${v.hex}" ${sHl2===v.hex?'selected':''}>${v.label}</option>`).join('')}</select>
          <input id="s-hl2-custom" type="color" value="${sHl2}" title="Màu tùy chỉnh" style="width:42px;height:32px;padding:2px;">
        </div>
      </div>
      <button id="s-close" class="olm-btn-primary">✕ Đóng</button>
    `;
    document.body.appendChild(modal);

    const apply = () => {
      const w = +modal.querySelector('#s-w').value;
      const h = +modal.querySelector('#s-h').value;
      const z = +modal.querySelector('#s-z').value;
      modal.querySelector('#s-w-v').textContent = w + 'vw';
      modal.querySelector('#s-h-v').textContent = h + 'vh';
      modal.querySelector('#s-z-v').textContent = z + '%';
      RT.settings.panelWidth = w;
      RT.settings.panelHeight = h;
      RT.settings.zoom = z;
      if (this.container) {
        this.container.style.width = w + 'vw';
        this.container.style.maxHeight = h + 'vh';
        this.container.style.fontSize = (z / 100) + 'em';
      }
      // Sync scale slider in panel
      const ss = document.getElementById('olm-scale-slider');
      const sv = document.getElementById('olm-scale-val');
      if (ss) ss.value = z;
      if (sv) sv.textContent = z + '%';
      this._lsSet(this.LS.scale, z);
      Store.saveSettings();
    };

    ['s-w','s-h','s-z'].forEach(id => modal.querySelector('#' + id).addEventListener('input', apply));
    modal.querySelector('#s-t').addEventListener('change', e => this.applyTheme(e.target.value));
    modal.querySelector('#s-bg-default').addEventListener('click', () => this.setPanelBackground('default'));
    modal.querySelector('#s-bg-cherry').addEventListener('click', () => this.setPanelBackground('builtin:cherry'));
    modal.querySelector('#s-bg-cosmic').addEventListener('click', () => this.setPanelBackground('builtin:cosmic'));
    modal.querySelector('#s-bg-starry').addEventListener('click', () => this.setPanelBackground('builtin:starry'));
    modal.querySelector('#s-bg-warrior').addEventListener('click', () => this.setPanelBackground('builtin:warrior'));
    modal.querySelector('#s-bg-none').addEventListener('click', () => this.setPanelBackground('none'));
    modal.querySelector('#s-bg-upload').addEventListener('click', () => modal.querySelector('#s-bg-file').click());
    modal.querySelector('#s-bg-file').addEventListener('change', e => this.readBackgroundFile(e.target.files?.[0]));
    const bgOpacity = modal.querySelector('#s-bg-opacity');
    const bgOpacityVal = modal.querySelector('#s-bg-opacity-v');
    bgOpacity.addEventListener('input', () => {
      RT.settings.panelBgOpacity = +bgOpacity.value;
      bgOpacityVal.textContent = Math.round(RT.settings.panelBgOpacity * 100) + '%';
      this.applyPanelBackground();
      Store.saveSettings();
    });
    const bgBlur = modal.querySelector('#s-bg-blur');
    const bgBlurVal = modal.querySelector('#s-bg-blur-v');
    bgBlur.addEventListener('input', () => {
      RT.settings.panelBgBlur = +bgBlur.value;
      bgBlurVal.textContent = RT.settings.panelBgBlur + 'px';
      this.applyPanelBackground();
      Store.saveSettings();
    });
    const hl1=modal.querySelector('#s-hl1'), hl1c=modal.querySelector('#s-hl1-custom');
    const hl2=modal.querySelector('#s-hl2'), hl2c=modal.querySelector('#s-hl2-custom');
    const setHL1=v=>{RT.settings.highlightPageColor=v;hl1c.value=v;this.applyHighlightColors();this.refreshHighlightCss();Store.saveSettings();};
    const setHL2=v=>{RT.settings.highlightPanelColor=v;hl2c.value=v;this.applyHighlightColors();this.refreshHighlightCss();Store.saveSettings();};
    hl1.addEventListener('change',()=>setHL1(hl1.value)); hl1c.addEventListener('input',()=>setHL1(hl1c.value));
    hl2.addEventListener('change',()=>setHL2(hl2.value)); hl2c.addEventListener('input',()=>setHL2(hl2c.value));
    modal.querySelector('#s-close').addEventListener('click', () => modal.remove());
    modal.addEventListener('click', e => { if (e.target === modal) modal.remove(); });
  },

  exportToTxt() {
    if (!isLicenseActive()) { handleLicenseLocked('exportToTxt'); return; }
    let txt = `OLM Panel by NTH v1.3\nXuất lúc: ${new Date().toLocaleString('vi-VN')}\n${'='.repeat(50)}\n`;
    this.contentArea?.querySelectorAll('.qa-block').forEach((block, i) => {
      const q = block.querySelector('.question-content')?.textContent || '';
      const a = block.querySelector('.content-container')?.textContent || '';
      const type = block.querySelector('.content-container')?.dataset?.type || 'answer';
      const label = type === 'solution' ? 'Hướng dẫn giải' : type === 'not-found' ? '(chưa có đáp án)' : 'Đáp án';
      txt += `---\nCâu ${i+1}\n${q.trim()}\n--> ${label}: ${a.trim()}\n\n`;
    });
    const blob = new Blob([txt], { type: 'text/plain;charset=utf-8' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `dap-an-olm-${Date.now()}.txt`;
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    URL.revokeObjectURL(a.href);
  },

  scheduleDomAnswerEnrichment(responseContainer, list) {
    // Chỉ observe responseContainer (không phải toàn body) để tránh lag
    // subtree:true trên document.body với mọi mutation của trang → crash
    const tryFill = (isFinal = false) => {
      if (!isLicenseActive()) return;   // timer/observer có thể chạy sau khi license bị khoá
      // Cache 1 lần cho cả vòng poll: locateQuizHosts() quét document + mọi
      // shadow root, gọi lại cho từng câu là O(N) lần dư thừa (đề 16 câu ×
      // 4 vòng poll + MutationObserver = hàng trăm lượt quét toàn trang).
      let domScanned = false, domResult = null;
      const domAnswers = () => {
        if (!domScanned) { domScanned = true; domResult = extractAnswersFromDomForQuestion(list[0]); }
        return domResult;
      };
      list.forEach((question, qi) => {
        const qid = question.id != null ? String(question.id) : '';
        if (!qid) return;
        const row = responseContainer.querySelector(`[data-olm-qid="${CSS.escape(qid)}"]`);
        if (!row) return;
        const cc = row.querySelector('.content-container');
        if (!cc || cc.dataset.type !== 'not-found') return;

        let fromDom = extractAnswersFromPlainApiFields(question)
          || (domAnswers() || extractAnswersFromDomForQuestion(question));
        if (!fromDom) {
          const dec = decodeSync(question.content || '');
          if (dec && !isGarbageText(dec)) {
            // SECURITY: detached parse only; clone vào panel phải sanitize.
            const tempDiv = document.createElement('div'); tempDiv.innerHTML = dec;
            const correctEls = tempDiv.querySelectorAll(ANSWER_DOM_SELECTORS);
            if (correctEls.length) {
              const ul = document.createElement('ul');
              correctEls.forEach(ans => { const li = document.createElement('li'); ans.childNodes.forEach(n => { const sc = sanitizeClone(n); if (sc) li.appendChild(sc); }); sanitizeSubtree(li); ul.appendChild(li); });
              fromDom = ul;
            }
          }
        }
        if (fromDom) {
          cc.innerHTML = '';
          cc.dataset.type = 'answer';
          cc.style.cssText = 'font-weight:500;color:var(--olm-accent,#bf5fff);padding:5px 0 0 0;border-top:1px solid var(--olm-green-dim,rgba(var(--olm-hl1-rgb),.2));margin-top:5px;';
          this.applyAnswerListStyles(fromDom);
          // SECURITY: fromDom đã được sanitize tại nguồn (extract/sanitizeClone),
          // sanitize lại 1 lần trước khi mount để chặn cache/DOM lạ.
          try { sanitizeSubtree(fromDom); } catch (_) {}
          cc.appendChild(fromDom);
          PageHL.offer(question, cc);
          this.markAnswerShown(cc);
          Store.setCache(qid, { type: 'answer', html: cc.innerHTML });
          return;
        }
        if (isFinal) {
          const dec = decodeSync(question.content || '');
          const sol = getSolutionAsDOM(dec);
          if (sol) {
            cc.dataset.type = 'solution';
            cc.style.cssText = 'padding:5px 0 0 0;border-top:1px solid var(--olm-border,rgba(var(--olm-accent-rgb),.35));margin-top:5px;color:#c89aff;';
            cc.innerHTML = '<div style="font-size:9.5px;color:rgba(var(--olm-accent-rgb),.7);margin-bottom:5px;font-weight:700;letter-spacing:.5px;">// SOLUTION</div>';
            cc.appendChild(sol);
            Store.setCache(qid, { type: 'solution', html: cc.innerHTML });
          } else {
            cc.innerHTML = '<p class="olm-not-found">› null — no answer or solution found.</p>';
          }
        }
      });
    };

    // Giảm số lần poll: 3 lần thay vì 4, interval dài hơn
    [200, 1500, 4000].forEach((ms, idx) => safeTimeout(() => tryFill(idx === 2), ms));

    // Observer chỉ watch trang web (không phải panel) tìm DOM đáp án mới render
    // Dùng subtree:false + chỉ observe PHẦN THÂN TRANG, không observe body toàn bộ
    let debounce_timer;
    const obs = new MutationObserver(() => {
      clearTimeout(debounce_timer);
      debounce_timer = setTimeout(() => tryFill(false), 600);
    });
    // Tìm main content area của trang (không phải panel)
    const pageMain = document.querySelector('main, #app, #root, .content, [role="main"]')
      || document.body;
    if (pageMain && pageMain !== this.container) {
      // childList only (không subtree) → nhẹ hơn rất nhiều
      obs.observe(pageMain, { childList: true, subtree: false });
      const obsName = 'enrich_' + Date.now();
      RT.observers.set(obsName, obs);
      safeTimeout(() => { obs.disconnect(); RT.observers.delete(obsName); }, 12000);
    }
  },

  // Gỡ gate khi license quay lại activated (vd expired → activated sau khi gia hạn trên server)
  _hideLicenseGate() {
    this._licenseGateShown = false;
    try { this.contentArea?.querySelector('.olm-license-gate')?.remove(); } catch (_) {}
    // Điểm móc duy nhất để nạp lại remote tunables khi gate vừa được gỡ.
    // Hàm này chạy ở cả hai nhánh lock/unlock; loadRemoteConfigTunables() tự gate
    // theo isLicenseActive() nên khi license đang khoá thì đây là no-op.
    // Đặt hook ở đây (tầng Panel) để KHỐNG chạm vào khối code License của v1.3.12.
    if (!RC.applied) safeTimeout(() => loadRemoteConfigTunables(), 0);
  },

  // Hiện thông báo yêu cầu license khi chưa activated
  _showLicenseGate() {
    if (!this.contentArea) return;
    // Không hiện gate khi panel đang collapsed (tránh hiện panel bất ngờ)
    if (this.isCollapsed) return;
    // Chỉ render 1 lần — kiểm tra cả class lẫn flag tránh spam
    if (this._licenseGateShown) return;
    if (this.contentArea.querySelector('.olm-license-gate')) return;
    this._licenseGateShown = true;
    this.contentArea.innerHTML = '';
    const gate = document.createElement('div');
    gate.className = 'olm-license-gate';
    gate.style.cssText = `
      padding: 24px 16px;
      text-align: center;
      color: var(--olm-text-dim);
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 10px;
    `;
    // Gate hiển thị đúng trạng thái thực tế (không hard-code "Chưa kích hoạt").
    const st = RT.license.status;
    const title = (LICENSE_STATUS_TEXT[st] || 'License Required').replace(/^[^A-Za-z]+/, '');
    const GATE_SUB = {
      not_activated:        'Nhập License Key ở trên để sử dụng tính năng',
      invalid_key:          'Key không hợp lệ — kiểm tra lại hoặc nhập key khác ở trên',
      expired:              'Key đã hết hạn — gia hạn hoặc nhập key khác ở trên',
      device_limit_reached: 'Key đã đạt giới hạn thiết bị',
      network_error:        'Không xác thực được license — sẽ tự thử lại khi có mạng',
    };
    const icon = document.createElement('div');
    icon.style.fontSize = '28px'; icon.textContent = '🔒';
    const t = document.createElement('div');
    t.style.cssText = 'font-size:12px;font-weight:700;color:var(--olm-text)'; t.textContent = title;
    const sub = document.createElement('div');
    sub.style.cssText = 'font-size:10px;opacity:.7;line-height:1.5'; sub.textContent = GATE_SUB[st] || 'Cần License hợp lệ để sử dụng tính năng';
    gate.append(icon, t, sub);
    this.contentArea.appendChild(gate);
  },

  async renderData(data) {
    // ── License gate ──
    if (!isLicenseActive()) {
      this._showLicenseGate();
      return;
    }
    this._licenseGateShown = false;

    let list = data;
    if (!Array.isArray(list)) {
      list = (data && (data.list || data.data || data.questions || data.items)) || null;
    }
    if (!Array.isArray(list) || !list.length) return;

    const newList = list.filter(q => {
      const qid = q.id != null ? String(q.id) : null;
      if (!qid) return true;
      if (RT.seenQids.has(qid)) return false;
      RT.seenQids.add(qid); return true;
    });
    if (!newList.length) return;

    if (this.isCollapsed) {
      // Panel đang ẩn — không làm gì, data vẫn được xử lý bình thường
    }

    const responseContainer = document.createElement('div');
    RT.batchCount++;
    responseContainer.className = 'olm-batch';

    const batchHeader = document.createElement('div');
    batchHeader.className = 'olm-batch-header-row';
    batchHeader.innerHTML = `<span>batch_${RT.batchCount} · ${newList.length} câu · ${new Date().toLocaleTimeString()}</span>`;
    const delBtn = document.createElement('button');
    delBtn.textContent = '✕';
    delBtn.className = 'olm-footer-btn danger';
    delBtn.style.cssText = 'padding:2px 7px;font-size:10px;min-height:22px;';
    delBtn.addEventListener('click', () => {
      responseContainer.querySelectorAll('[data-olm-qid]').forEach(el => RT.seenQids.delete(el.dataset.olmQid));
      responseContainer.remove();
    });
    batchHeader.appendChild(delBtn);
    responseContainer.appendChild(batchHeader);

    // ── BƯỚC 1: Dựng skeleton DOM ngay — không await gì cả ──
    const skeletons = [];
    for (const question of newList) {
      RT.questionCounter++;
      const qid = question.id != null ? String(question.id) : null;
      const cached = qid ? Store.getCache(qid) : null;
      const jsonTree = tryParseQuestionJsonTree(question);
      const stemFromJson = extractStemTextFromLexical(jsonTree);

      const questionDiv = document.createElement('div');
      questionDiv.className = 'qa-block';
      if (qid) questionDiv.setAttribute('data-olm-qid', qid);

      const qtype = detectQuestionType(question, jsonTree);
      const qtypeMeta = QTYPE_LABEL[qtype] || QTYPE_LABEL.unknown;
      const numBadge = document.createElement('div');
      numBadge.style.cssText = 'font-size:9px;color:rgba(var(--olm-accent-rgb),.5);margin-bottom:3px;font-weight:700;letter-spacing:.8px;display:flex;align-items:center;gap:5px;flex-wrap:wrap;';
      numBadge.innerHTML = `<span style="background:rgba(var(--olm-accent-rgb),.12);padding:1px 6px;border-radius:4px;">CÂU ${RT.questionCounter}</span><span class="olm-qtype-badge ${qtypeMeta.cls}">${qtypeMeta.text}</span>${cached ? '<span style="color:rgba(var(--olm-hl1-rgb),.5);font-size:8px;">[cache]</span>' : ''}`;

      const questionDisplayContainer = document.createElement('div');
      questionDisplayContainer.className = 'question-content';
      if (stemFromJson && stemFromJson.length >= 8) {
        questionDisplayContainer.textContent = stemFromJson;
        questionDisplayContainer.style.whiteSpace = 'pre-wrap';
      } else if (question.title) {
        questionDisplayContainer.innerHTML = escapeHtml(question.title);
      } else {
        questionDisplayContainer.innerHTML = '<span style="color:rgba(var(--olm-accent-rgb),.3);font-size:10px;">đang giải mã...</span>';
      }

      const contentContainer = document.createElement('div');
      contentContainer.className = 'content-container';
      if (cached && cached.val && typeof cached.val.html === 'string') {
        contentContainer.dataset.type = cached.val.type || 'answer';
        // SECURITY: cache trong storage có thể bị sửa ngoài → sanitize khi restore.
        // RAW (cached) → sanitizeHTML → SAFE → DOM. Giữ formatting/bảng/ảnh.
        setSafeInnerHTML(contentContainer, cached.val.html || '');
        if (contentContainer.dataset.type === 'answer') {
          PageHL.offer(question, contentContainer);
          this.markAnswerShown(contentContainer);
        }
      } else {
        contentContainer.dataset.type = 'not-found';
        contentContainer.innerHTML = '<p class="olm-not-found">› đang tải...</p>';
        skeletons.push({ qid, question, jsonTree, stemFromJson, questionDisplayContainer, contentContainer });
      }

      questionDiv.append(numBadge, questionDisplayContainer, contentContainer);
      responseContainer.appendChild(questionDiv);
    }

    // Mount vào DOM ngay — user thấy danh sách câu < 1ms
    if (this.contentArea) this.contentArea.prepend(responseContainer);

    // ── BƯỚC 2: Decode + fill đáp án song song, batch 5 câu ──
    if (skeletons.length > 0) {
      const CHUNK = 5;
      for (let i = 0; i < skeletons.length; i += CHUNK) {
        await Promise.all(skeletons.slice(i, i + CHUNK).map(sk => this._fillSkeleton(sk)));
        if (!isLicenseActive()) { handleLicenseLocked('renderData'); return; }
        await new Promise(r => setTimeout(r, 0)); // nhường thread giữa batch
        if (!isLicenseActive()) { handleLicenseLocked('renderData'); return; }
      }
      if (!isLicenseActive()) { handleLicenseLocked('renderData'); return; }
      this.scheduleDomAnswerEnrichment(responseContainer, skeletons.map(s => s.question));
    }
  },

  async _fillSkeleton({ qid, question, jsonTree, stemFromJson, questionDisplayContainer, contentContainer }) {
    try {
      let decodedContent = '';
      try { decodedContent = await decodeQuestionContent(question.content || ''); } catch (_) {}
      if (!isLicenseActive()) return;   // license có thể hết hạn trong lúc await decode
      const htmlUsable = decodedContent && !isGarbageText(decodedContent);
      const hasRichMath = htmlUsable && htmlLooksLikeHasMath(decodedContent);

      // Cập nhật nội dung câu hỏi nếu lúc đầu chỉ có "đang giải mã"
      if (!stemFromJson && htmlUsable) {
        const tempDiv = document.createElement('div');
        tempDiv.innerHTML = decodedContent;
        tempDiv.querySelectorAll('ol.quiz-list,ul.quiz-list,.interaction,.form-group,.loigiai,.huong-dan-giai,.explain,.solution,#solution,.guide,.exp').forEach(el => el.remove());
        stripQuestionDisplayElements(tempDiv);
        tempDiv.querySelectorAll('script,style,link,iframe,object,embed,form').forEach(el => el.remove());
        tempDiv.querySelectorAll('*').forEach(el => { Array.from(el.attributes).forEach(attr => { if (/^on/i.test(attr.name)) el.removeAttribute(attr.name); }); });
        // SECURITY: RAW HTML (từ OLM) → sanitizeHTML allowlist → SAFE → DOM.
        // Giữ định dạng/bảng/công thức/hình ảnh, chặn script/iframe/event handler
        // và validate img src/srcset/href scheme.
        sanitizeSubtree(tempDiv);
        questionDisplayContainer.innerHTML = '';
        while (tempDiv.firstChild) questionDisplayContainer.appendChild(tempDiv.firstChild);
      }

      // Extract đáp án
      const answersElement = await getAnswersAsDOM(question, htmlUsable ? decodedContent : '')
        || extractAnswersFromDomForQuestion(question);
      if (!isLicenseActive()) return;   // ... hoặc trong lúc await getAnswersAsDOM
      const solutionElement = !answersElement && htmlUsable ? getSolutionAsDOM(decodedContent) : null;

      if (answersElement) {
        contentContainer.innerHTML = '';
        contentContainer.dataset.type = 'answer';
        contentContainer.style.cssText = 'font-weight:500;color:var(--olm-accent,#bf5fff);padding:5px 0 0 0;border-top:1px solid var(--olm-green-dim,rgba(var(--olm-hl1-rgb),.2));margin-top:5px;';
        this.applyAnswerListStyles(answersElement);
        // SECURITY: sanitize trước khi mount (defense-in-depth, giữ UI).
        try { sanitizeSubtree(answersElement); } catch (_) {}
        contentContainer.appendChild(answersElement);
        if (!isLicenseActive()) return;   // chốt cuối ngay trước khi tạo Highlight
        PageHL.offer(question, answersElement);
        this.markAnswerShown(contentContainer);
        if (qid) Store.setCache(qid, { type: 'answer', html: contentContainer.innerHTML });
      } else if (solutionElement) {
        contentContainer.dataset.type = 'solution';
        contentContainer.style.cssText = 'padding:5px 0 0 0;border-top:1px solid var(--olm-border,rgba(var(--olm-accent-rgb),.35));margin-top:5px;color:#c89aff;';
        contentContainer.innerHTML = '<div style="font-size:9.5px;color:rgba(var(--olm-accent-rgb),.7);margin-bottom:4px;font-weight:700;">// SOLUTION</div>';
        // SECURITY: solution từ decoded HTML (untrusted) đã sanitize tại nguồn,
        // sanitize lại trước khi mount.
        try { sanitizeSubtree(solutionElement); } catch (_) {}
        contentContainer.appendChild(solutionElement);
        if (qid) Store.setCache(qid, { type: 'solution', html: contentContainer.innerHTML });
      } else {
        contentContainer.dataset.type = 'not-found';
        contentContainer.innerHTML = '<p class="olm-not-found">› null — no answer found.</p>';
      }
    } catch (e) {
      L.err('_fillSkeleton:', e);
      contentContainer.innerHTML = '<p class="olm-not-found">› lỗi giải mã</p>';
    }
  },
};

// ============================================================
// SELF-HEALING
// ============================================================
const Healer = {
  verifyRoot() {
    const panelOk = Panel.container && document.body && document.body.contains(Panel.container);
    const floatOk = Panel.floatBtn && document.body && document.body.contains(Panel.floatBtn);
    if (panelOk && floatOk) return;
    L.log('Panel missing, resurrecting...');
    document.getElementById('olm-answers-container')?.remove();
    document.getElementById('olm-float-btn')?.remove();
    Panel.container = null;
    Panel.floatBtn = null;
    Panel.init();
  },
  setupBodyWatcher() {
    const obs = new MutationObserver(mutations => {
      for (const m of mutations) {
        if (m.type !== 'childList') continue;
        for (const removed of m.removedNodes) {
          if (removed.id === 'olm-answers-container' || removed.contains?.(Panel.container)) {
            safeTimeout(() => this.verifyRoot(), 50); return;
          }
        }
      }
    });
    if (document.body) obs.observe(document.body, { childList: true, subtree: false });
    RT.observers.set('body-watcher', obs);
  },
  startWatchdog() {
    const id = setInterval(() => {
      this.verifyRoot();
      if (!document.getElementById('olm-panel-css')) {
        const s = document.createElement('style'); s.id = 'olm-panel-css'; s.textContent = PANEL_CSS;
        (document.head || document.documentElement).appendChild(s);
      }
    }, 15000); // 15s thay vì 5s — ít overhead hơn
    RT.intervals.set('watchdog', id);
  },
};

// ============================================================
// MAIN INIT
// ============================================================
async function olmMain() {
  L.log('Content script starting (isolated world, document_start)...');

  // Kill switch "olm off" (chỉ dừng panel + highlight, KHÔNG đụng license).
  // Thiếu key = mặc định BẬT → không ảnh hưởng user đang dùng bản cũ.
  let extEnabled = true;
  try {
    const en = await chrome.storage.local.get('olm_enabled');
    if (en && en.olm_enabled === false) extEnabled = false;
  } catch (_) {}

  // Load settings & cache
  try {
    const stored = await Store.loadAll();
    if (stored[LS_SETTINGS_KEY]) RT.settings = { ...DEFAULT_SETTINGS, ...stored[LS_SETTINGS_KEY] };
    if (stored[LS_CACHE_KEY]) RT.cache = stored[LS_CACHE_KEY];
    // Migrate cài đặt cũ (v1.1 chỉ có 1 cờ `highlight` chung) → 2 cờ riêng
    const old = stored[LS_SETTINGS_KEY];
    if (old && typeof old.highlightPage !== 'boolean') RT.settings.highlightPage = old.highlight !== false;
    if (old && typeof old.highlightPanel !== 'boolean') RT.settings.highlightPanel = old.highlight !== false;
    RT.settings.highlight = RT.settings.highlightPage;
  } catch (e) { L.err('Storage load failed:', e); }

  // Load license state (đọc từ storage, không lộ key ở log)
  await LM.load();
  L.log('License status:', RT.license.status);

  // Setup bridge TRƯỚC khi bất kỳ thứ gì khác
  // injected.js đã chạy ở document_start → sẽ gửi OLM_INJECTED_READY sớm
  // content.js cũng document_start nhưng ISOLATED chạy song song với MAIN
  setupBridge();

  // Mount panel
  const mountPanel = () => { Panel.init(); L.log('Panel mounted.'); };
  if (!extEnabled) {
    // Extension bị tắt bằng "olm off": vẫn giữ bridge + license, chỉ không dựng UI.
    L.log('Disabled via "olm off" — panel/highlight skipped (license state kept).');
  } else if (document.body) mountPanel();
  else document.addEventListener('DOMContentLoaded', mountPanel, { once: true });

  // Self-healing
  if (document.body) Healer.setupBodyWatcher();
  else document.addEventListener('DOMContentLoaded', () => Healer.setupBodyWatcher(), { once: true });
  safeTimeout(() => Healer.startWatchdog(), 3000);

  // Ping background
  try { chrome.runtime.sendMessage({ type: 'OLM_PING' }); } catch (_) {}

  // Nạp remote config SAU khi panel đã lên: không chặn khởi động.
  // Built-in default đã có hiệu lực ngay từ đầu, nên config đến muộn vẫn an toàn.
  if (extEnabled) safeTimeout(() => loadRemoteConfigTunables(), 300);

  L.log('Init complete. Waiting for API data...');
}

olmMain().catch(e => L.err('Fatal:', e));
