'use strict';
// Trang điều khiển (extension page). Chỉ đọc/ghi qua message API của Service Worker.
// TUYỆT ĐỐI không hiển thị license key đầy đủ, device id đầy đủ, hay secret nào.

const $ = (id) => document.getElementById(id);

function fmt(ts) {
  if (!ts) return '—';
  try { return new Date(ts).toLocaleString(); } catch (_) { return String(ts); }
}

function logLine(s) {
  const el = $('log');
  el.style.display = 'block';
  el.textContent += s + '\n';
}

function send(msg) {
  return new Promise((resolve) => {
    try {
      chrome.runtime.sendMessage(msg, (res) => {
        if (chrome.runtime.lastError) resolve({ error: chrome.runtime.lastError.message });
        else resolve(res || {});
      });
    } catch (e) { resolve({ error: String(e && e.message) }); }
  });
}

const LICENSE_TEXT = {
  not_activated: 'Chưa kích hoạt',
  activated: 'Đã kích hoạt',
  invalid_key: 'Key không hợp lệ',
  expired: 'Key đã hết hạn',
  device_limit_reached: 'Đã đạt giới hạn thiết bị',
  network_error: 'Lỗi mạng / chưa xác nhận',
};

async function refresh() {
  const st = await send({ type: 'OLM_RC_STATUS' });
  if (!st || st.error) {
    $('state').textContent = 'Service Worker chưa sẵn sàng — thử tải lại trang';
    return;
  }
  $('extv').textContent = st.extensionVersion || '—';
  $('schema').textContent = 'v' + (st.schemaVersion ?? '—');
  $('cfgv').textContent = st.activeVersion || '—';
  $('cfgsrc').textContent = ({
    active: 'cache local (đã xác thực)',
    previous: 'cache local (bản trước)',
    builtin: 'built-in default trong gói extension',
  })[st.source] || st.source;
  $('latest').textContent = st.lastKnownVersion || '—';
  $('prev').textContent = st.previousVersion || '— (chưa có)';
  $('state').textContent = st.state + (st.stale ? '  ⚠ config đã quá hạn, vẫn dùng bản cached' : '');
  $('lastchk').textContent = fmt(st.lastCheckedAt);
  $('lastok').textContent = fmt(st.lastSuccessAt);
  $('exp').textContent = st.expiresAt ? st.expiresAt + (st.stale ? '  (đã quá hạn)' : '') : '—';
  $('err').textContent = st.lastError || '—';

  const en = await chrome.storage.local.get('olm_enabled');
  $('enabled').textContent = (en && en.olm_enabled === false)
    ? 'TẮT (olm off) — panel/highlight không chạy'
    : 'BẬT';

  const li = await send({ type: 'OLM_RC_LICENSE_INFO' });
  if (li && !li.error) {
    const t = LICENSE_TEXT[li.status] || li.status;
    $('lic').textContent = t;
    $('lic').className = li.status === 'activated' ? 'ok' : 'bad';
    $('key').textContent = li.hasKey ? li.maskedKey : '— (chưa nhập)';
    $('dev').textContent = li.deviceId || '—';
    $('vat').textContent = li.verifiedAt ? fmt(li.verifiedAt) : '—';
  } else {
    $('lic').textContent = 'Không đọc được (service worker chưa sẵn sàng)';
  }
}

$('btn-check').addEventListener('click', async () => {
  $('btn-check').disabled = true;
  logLine('Đang kiểm tra cập nhật…');
  const r = await send({ type: 'OLM_RC_UPDATE' });
  logLine('Kết quả: ' + JSON.stringify(r));
  $('btn-check').disabled = false;
  await refresh();
});

$('btn-rollback').addEventListener('click', async () => {
  $('btn-rollback').disabled = true;
  const r = await send({ type: 'OLM_RC_ROLLBACK' });
  logLine('Rollback: ' + JSON.stringify(r));
  $('btn-rollback').disabled = false;
  await refresh();
});

// Kết quả được index.js truyền qua hash sau khi chạy lệnh omnibox.
function showHashResult() {
  const m = /#result=(.*)$/.exec(location.hash || '');
  if (!m) return;
  try { logLine('Kết quả lệnh omnibox: ' + JSON.stringify(JSON.parse(decodeURIComponent(m[1])))); }
  catch (_) { logLine('Kết quả lệnh omnibox: ' + decodeURIComponent(m[1])); }
}

showHashResult();
refresh();
